import React, { useState, useEffect, useMemo } from 'react';
import { 
  FileText, 
  Plus, 
  Search, 
  Filter, 
  Youtube, 
  Instagram, 
  Video, 
  Linkedin, 
  Twitter, 
  Calendar, 
  Eye, 
  Heart, 
  MessageSquare, 
  Share2, 
  TrendingUp, 
  Trash2, 
  ExternalLink, 
  CheckCircle2, 
  Clock, 
  Sparkles, 
  RefreshCw,
  ArrowLeft,
  DollarSign
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { creatorService } from '../../services/api';
import { ContentItem } from '../../types/auth';

interface ContentPageProps {
  onNavigate: (page: string) => void;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const ContentPage: React.FC<ContentPageProps> = ({ onNavigate, onShowToast }) => {
  const { user } = useAuth();
  const [contentList, setContentList] = useState<ContentItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPlatform, setSelectedPlatform] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'published' | 'scheduled' | 'draft'>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form state for creating content
  const [title, setTitle] = useState('');
  const [platform, setPlatform] = useState<'youtube' | 'instagram' | 'tiktok' | 'linkedin' | 'x'>('youtube');
  const [type, setType] = useState<'video' | 'reel' | 'post' | 'article' | 'short'>('video');
  const [status, setStatus] = useState<'published' | 'scheduled' | 'draft'>('published');
  const [scheduledDate, setScheduledDate] = useState('');

  const fetchContent = async () => {
    setIsLoading(true);
    try {
      const res = await creatorService.getContent(
        selectedPlatform === 'all' ? undefined : selectedPlatform,
        statusFilter === 'all' ? undefined : statusFilter
      );
      if (res.success && Array.isArray(res.content)) {
        setContentList(res.content);
      }
    } catch (err: any) {
      console.warn('Failed to fetch content items:', err);
      onShowToast?.('Failed to load content items from server', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchContent();
  }, [selectedPlatform, statusFilter]);

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setIsSubmitting(true);
    try {
      const res = await creatorService.createContent({
        title: title.trim(),
        platform,
        type,
        status,
        scheduledDate: status === 'scheduled' ? scheduledDate : undefined
      });

      if (res.success) {
        onShowToast?.(`Content "${title}" successfully recorded!`, 'success');
        setShowAddModal(false);
        setTitle('');
        setScheduledDate('');
        await fetchContent();
      }
    } catch (err: any) {
      onShowToast?.(err.message || 'Failed to create content item', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeletePost = async (id: number) => {
    if (!confirm('Are you sure you want to remove this content post?')) return;
    try {
      const res = await creatorService.deleteContent(id);
      if (res.success) {
        onShowToast?.('Content post removed.', 'info');
        setContentList(prev => prev.filter(item => item.id !== id));
      }
    } catch (err: any) {
      onShowToast?.(err.message || 'Failed to delete content', 'error');
    }
  };

  // Filtered by search query
  const filteredContent = useMemo(() => {
    if (!searchQuery.trim()) return contentList;
    const q = searchQuery.toLowerCase();
    return contentList.filter(item => 
      item.title.toLowerCase().includes(q) || 
      item.platform.toLowerCase().includes(q) ||
      (item.type && item.type.toLowerCase().includes(q))
    );
  }, [contentList, searchQuery]);

  // Aggregate metrics
  const totalViews = useMemo(() => contentList.reduce((sum, item) => sum + (item.views || 0), 0), [contentList]);
  const totalLikes = useMemo(() => contentList.reduce((sum, item) => sum + (item.likes || 0), 0), [contentList]);
  const totalComments = useMemo(() => contentList.reduce((sum, item) => sum + (item.comments || 0), 0), [contentList]);
  const avgEngagement = useMemo(() => {
    if (contentList.length === 0) return 0;
    const sum = contentList.reduce((acc, item) => acc + (item.engagementRate || 0), 0);
    return Number((sum / contentList.length).toFixed(2));
  }, [contentList]);

  const getPlatformIcon = (plt: string) => {
    switch (plt.toLowerCase()) {
      case 'youtube': return <Youtube className="w-4 h-4 text-red-600" />;
      case 'instagram': return <Instagram className="w-4 h-4 text-pink-600" />;
      case 'tiktok': return <Video className="w-4 h-4 text-slate-800" />;
      case 'linkedin': return <Linkedin className="w-4 h-4 text-sky-700" />;
      case 'x':
      case 'twitter': return <Twitter className="w-4 h-4 text-slate-700" />;
      default: return <FileText className="w-4 h-4 text-purple-600" />;
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-12">
      {/* Top Header & Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-purple-100">
        <div>
          <button
            onClick={() => onNavigate('dashboard')}
            className="inline-flex items-center space-x-1.5 text-xs font-bold text-slate-500 hover:text-purple-700 transition-colors mb-2 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Dashboard</span>
          </button>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">Content Performance &amp; Library</h1>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-100 text-purple-800">
              {user?.role?.toUpperCase()}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Track multi-platform posts, view counts, engagement rates, and scheduled releases.
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={fetchContent}
            disabled={isLoading}
            className="p-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 text-xs font-semibold transition-colors disabled:opacity-50 cursor-pointer"
            title="Refresh content list from database"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold transition-all shadow-md flex items-center space-x-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Post</span>
          </button>
        </div>
      </div>

      {/* Aggregate Overview Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-purple-100 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Total Posts</span>
            <span className="p-2 rounded-xl bg-purple-50 text-purple-700">
              <FileText className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">{contentList.length}</div>
          <div className="text-[11px] text-slate-400 mt-1">Published &amp; scheduled items</div>
        </div>

        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-purple-100 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Total Views</span>
            <span className="p-2 rounded-xl bg-sky-50 text-sky-600">
              <Eye className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">
            {totalViews > 1000000 ? `${(totalViews / 1000000).toFixed(1)}M` : totalViews.toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-600 font-semibold mt-1">Across all connected platforms</div>
        </div>

        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-purple-100 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Total Interactions</span>
            <span className="p-2 rounded-xl bg-pink-50 text-pink-600">
              <Heart className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">
            {(totalLikes + totalComments).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">{totalLikes.toLocaleString()} likes &bull; {totalComments.toLocaleString()} comments</div>
        </div>

        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-purple-100 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Avg Engagement</span>
            <span className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-emerald-600 mt-2">{avgEngagement}%</div>
          <div className="text-[11px] text-slate-400 mt-1">High conversion benchmark</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-purple-100 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute inset-y-0 left-3 my-auto pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search posts by title or platform..."
            className="w-full pl-9 pr-3.5 py-2 rounded-xl border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>

        {/* Status Pills */}
        <div className="flex items-center space-x-1.5 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          {(['all', 'published', 'scheduled', 'draft'] as const).map(st => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer whitespace-nowrap ${
                statusFilter === st
                  ? 'bg-purple-700 text-white shadow-xs'
                  : 'text-slate-600 bg-slate-50 hover:bg-slate-100'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        {/* Platform Filter */}
        <div className="w-full md:w-auto">
          <select
            value={selectedPlatform}
            onChange={(e) => setSelectedPlatform(e.target.value)}
            className="w-full md:w-44 px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500"
          >
            <option value="all">All Platforms</option>
            <option value="youtube">YouTube</option>
            <option value="instagram">Instagram</option>
            <option value="tiktok">TikTok</option>
            <option value="linkedin">LinkedIn</option>
            <option value="x">X (Twitter)</option>
          </select>
        </div>
      </div>

      {/* Posts Table / Grid */}
      {isLoading ? (
        <div className="bg-white rounded-3xl p-12 border border-purple-100 shadow-xs text-center">
          <RefreshCw className="w-8 h-8 text-purple-600 animate-spin mx-auto mb-3" />
          <p className="text-xs font-bold text-slate-700">Loading content posts from database...</p>
        </div>
      ) : filteredContent.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 border border-purple-100 shadow-xs text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center mx-auto">
            <FileText className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">No content found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            {searchQuery 
              ? `No content matches your search "${searchQuery}". Try modifying your filters.`
              : 'You have not added any posts for this platform yet. Click "+ Add New Post" to log your first content deliverable.'}
          </p>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create First Post</span>
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-purple-100 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-purple-50/60 text-[10px] uppercase font-bold text-purple-900 border-b border-purple-100">
                <tr>
                  <th className="py-3 px-4">Content &amp; Platform</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Views</th>
                  <th className="py-3 px-4">Engagement</th>
                  <th className="py-3 px-4">Published / Date</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {filteredContent.map((item) => {
                  const isPub = item.status === 'published';
                  const isSched = item.status === 'scheduled';

                  return (
                    <tr key={item.id} className="hover:bg-purple-50/30 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 shrink-0">
                            {getPlatformIcon(item.platform)}
                          </div>
                          <div>
                            <div className="font-extrabold text-slate-900 max-w-sm sm:max-w-md truncate" title={item.title}>
                              {item.title}
                            </div>
                            <div className="text-[10px] text-slate-400 capitalize mt-0.5">
                              {item.platform} &bull; {item.url ? (
                                <a href={item.url} target="_blank" rel="noreferrer" className="text-purple-600 hover:underline inline-flex items-center space-x-0.5">
                                  <span>View Post</span>
                                  <ExternalLink className="w-2.5 h-2.5 ml-0.5" />
                                </a>
                              ) : 'Internal draft'}
                            </div>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 capitalize font-semibold text-slate-600">
                        {item.type || 'post'}
                      </td>

                      <td className="py-3.5 px-4">
                        {isPub ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Published</span>
                          </span>
                        ) : isSched ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                            <Clock className="w-3 h-3" />
                            <span>Scheduled</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600">
                            <span>Draft</span>
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                        {item.views ? item.views.toLocaleString() : '—'}
                      </td>

                      <td className="py-3.5 px-4">
                        {item.engagementRate ? (
                          <span className="font-bold text-emerald-600 font-mono">
                            {item.engagementRate}%
                          </span>
                        ) : '—'}
                      </td>

                      <td className="py-3.5 px-4 font-mono text-[11px] text-slate-500">
                        {item.publishedAt 
                          ? new Date(item.publishedAt).toLocaleDateString()
                          : item.scheduledDate 
                          ? `Sched: ${new Date(item.scheduledDate).toLocaleDateString()}`
                          : 'Not scheduled'}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => handleDeletePost(item.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                          title="Delete content record"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add New Content Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-md w-full border border-purple-100 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-purple-100">
              <h3 className="text-base font-black text-slate-900 tracking-tight flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-purple-600" />
                <span>Add Content Item</span>
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCreatePost} className="space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Content Title <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  placeholder="e.g. 5 AI Coding Workflows You Must Know in 2026"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Platform
                  </label>
                  <select
                    value={platform}
                    onChange={(e) => setPlatform(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-medium text-slate-800 focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="youtube">YouTube</option>
                    <option value="instagram">Instagram</option>
                    <option value="tiktok">TikTok</option>
                    <option value="linkedin">LinkedIn</option>
                    <option value="x">X (Twitter)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Format / Type
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-medium text-slate-800 focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="video">Full Video</option>
                    <option value="short">Short / Reel</option>
                    <option value="post">Image / Text Post</option>
                    <option value="article">Long Article</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-medium text-slate-800 focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="published">Published</option>
                    <option value="scheduled">Scheduled</option>
                    <option value="draft">Draft</option>
                  </select>
                </div>

                {status === 'scheduled' && (
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                      Scheduled Date
                    </label>
                    <input
                      type="date"
                      value={scheduledDate}
                      onChange={(e) => setScheduledDate(e.target.value)}
                      required
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-900 focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold transition-all shadow-md flex items-center space-x-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Saving...</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" />
                      <span>Save Post</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
