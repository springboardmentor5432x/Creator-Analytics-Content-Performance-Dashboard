import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  ArrowLeft, 
  Calendar, 
  TrendingUp, 
  Users, 
  DollarSign, 
  ShieldCheck, 
  Sparkles,
  BarChart2,
  CheckCircle2,
  Share2
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface ReportsPageProps {
  onNavigate: (page: string) => void;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const ReportsPage: React.FC<ReportsPageProps> = ({ onNavigate, onShowToast }) => {
  const { user } = useAuth();
  const [selectedQuarter, setSelectedQuarter] = useState<'Q4 2026' | 'Q3 2026' | 'Q2 2026'>('Q4 2026');

  const getRoleReports = () => {
    switch (user?.role) {
      case 'marketing':
        return [
          {
            tag: 'ROAS Audit',
            title: 'Q4 Influencer Marketing Attribution & ROAS Analysis',
            description: 'Comprehensive cross-platform analysis of customer conversions, click-through-rates, and blended Return on Ad Spend.',
            filename: 'Marketing_ROAS_Attribution_Q4_2026.pdf',
            type: 'PDF'
          },
          {
            tag: 'Creator Comparison',
            title: 'Creator Partnership Cost-per-Acquisition (CPA) Report',
            description: 'Comparative performance matrix evaluating delivered impressions, engagement rate, and direct checkout conversions.',
            filename: 'Creator_CPA_Performance_Matrix.pdf',
            type: 'PDF'
          },
          {
            tag: 'Raw Data',
            title: 'Campaign Conversion Raw Click Stream (CSV)',
            description: 'All campaign release timestamps, tracking UTM parameters, verified clicks, conversion tags, and influencer attribution.',
            filename: 'Campaign_ClickStream_Q4_2026.csv',
            type: 'CSV'
          }
        ];
      case 'agency':
        return [
          {
            tag: 'Revenue Statement',
            title: 'Talent Roster Monthly Earnings & Commission Split',
            description: 'Detailed revenue statement for represented creators, agency commission splits, sponsor brand payouts, and withholding tax.',
            filename: 'Agency_Roster_Commission_Q4_2026.pdf',
            type: 'PDF'
          },
          {
            tag: 'Deliverables Audit',
            title: 'Brand Partnership Deliverable & SLA Compliance',
            description: 'Audit tracking sponsor video releases, contract deliverable deadlines, review revisions, and client sign-offs.',
            filename: 'Deliverable_SLA_Compliance_Report.pdf',
            type: 'PDF'
          },
          {
            tag: 'Roster Metrics',
            title: 'Aggregate Talent Roster Metrics & Media Kit (CSV)',
            description: 'Full spreadsheet export of creator handles, follower counts, verified 30-day reach, and active collaboration statuses.',
            filename: 'Agency_Talent_Roster_Metrics.csv',
            type: 'CSV'
          }
        ];
      case 'admin':
        return [
          {
            tag: 'Security Audit',
            title: 'System Access, Authentication & RBAC Audit',
            description: 'Platform-wide security log of administrative actions, user role modifications, session durations, and IP verifications.',
            filename: 'Platform_Security_RBAC_Audit_2026.pdf',
            type: 'PDF'
          },
          {
            tag: 'System Health',
            title: 'Social Media API Rate Limits & Webhook Sync Log',
            description: 'Summary of connected platform health, YouTube API quota consumption, token expiration alerts, and error metrics.',
            filename: 'API_Health_and_Sync_Report.pdf',
            type: 'PDF'
          },
          {
            tag: 'User Activity',
            title: 'Complete User Activity & Session History (CSV)',
            description: 'All user records, registered roles, verified email statuses, login timestamps, and recorded session lengths.',
            filename: 'System_Users_Activity_Export.csv',
            type: 'CSV'
          }
        ];
      case 'creator':
      default:
        return [
          {
            tag: 'Monthly Statement',
            title: 'October 2026 Creator Performance & Reach Statement',
            description: 'Comprehensive 30-day breakdown of reach, follower growth rate, organic interactions, and estimated platform earnings.',
            filename: 'Creator_Statement_October_2026.pdf',
            type: 'PDF'
          },
          {
            tag: 'Sponsorship Kit',
            title: 'Official Brand Pitch & Media Kit (PDF)',
            description: 'Audience demographics, verified multi-platform engagement rate, past campaign case studies, and standard rate card.',
            filename: 'Creator_Brand_MediaKit_2026.pdf',
            type: 'PDF'
          },
          {
            tag: 'Raw Data',
            title: 'Raw Multi-Platform Post Metrics (CSV)',
            description: 'Complete data export with release timestamps, view counts, like ratios, comments, and engagement formulas.',
            filename: 'Creator_Post_Metrics_Export.csv',
            type: 'CSV'
          }
        ];
    }
  };

  const reports = getRoleReports();

  const handleDownload = (report: any) => {
    // Generate simple downloadable file blob
    const content = `CreatorIQ Performance Summary Report\nRole: ${user?.role?.toUpperCase()}\nUser: ${user?.name} (${user?.email})\nReport: ${report.title}\nQuarter: ${selectedQuarter}\nGenerated At: ${new Date().toISOString()}\n\nVerified by CreatorIQ Unified Platform.`;
    const blob = new Blob([content], { type: report.type === 'CSV' ? 'text/csv' : 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = report.filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    onShowToast?.(`Exported "${report.title}" successfully!`, 'success');
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-purple-100">
        <div>
          <button
            onClick={() => onNavigate('dashboard')}
            className="inline-flex items-center space-x-1.5 text-xs font-bold text-slate-500 hover:text-purple-700 transition-colors mb-2 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Dashboard</span>
          </button>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">Performance Reports &amp; Exports</h1>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-100 text-purple-800">
              {user?.role?.toUpperCase()}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Download certified executive statements, sponsor media kits, and CSV data summaries.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <select
            value={selectedQuarter}
            onChange={(e) => setSelectedQuarter(e.target.value as any)}
            className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-700 focus:ring-2 focus:ring-purple-500"
          >
            <option value="Q4 2026">Q4 2026 (Current)</option>
            <option value="Q3 2026">Q3 2026</option>
            <option value="Q2 2026">Q2 2026</option>
          </select>

          <button
            onClick={() => handleDownload(reports[0])}
            className="px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold transition-all shadow-md flex items-center space-x-2 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Export Executive Summary</span>
          </button>
        </div>
      </div>

      {/* Reports Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {reports.map((rep, idx) => (
          <div 
            key={idx}
            className="p-5 sm:p-6 rounded-3xl bg-white border border-purple-100 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-purple-600 bg-purple-50 px-2.5 py-0.5 rounded-full">
                  {rep.tag}
                </span>
                <span className="text-[10px] font-mono font-bold text-slate-400">
                  {rep.type}
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-900 mt-2.5">
                {rep.title}
              </h3>
              <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                {rep.description}
              </p>
            </div>

            <button
              onClick={() => handleDownload(rep)}
              className="mt-6 pt-3.5 border-t border-slate-100 text-xs font-bold text-purple-700 hover:text-purple-900 flex items-center justify-between group cursor-pointer"
            >
              <span className="group-hover:underline">Download {rep.type}</span>
              <Download className="w-3.5 h-3.5 group-hover:translate-y-0.5 transition-transform" />
            </button>
          </div>
        ))}
      </div>

      {/* Notice Banner */}
      <div className="p-4 rounded-2xl bg-purple-50/70 border border-purple-100 text-xs flex items-center space-x-3 text-purple-900">
        <Sparkles className="w-4 h-4 text-purple-600 shrink-0" />
        <div>
          <strong>Verified Reporting Engine:</strong> All metrics in these exports are verified against recorded database snapshots and connected platform APIs.
        </div>
      </div>
    </div>
  );
};
