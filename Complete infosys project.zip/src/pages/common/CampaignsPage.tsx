import React, { useState, useEffect, useMemo } from 'react';
import { 
  Target, 
  Plus, 
  Search, 
  Filter, 
  Calendar, 
  DollarSign, 
  TrendingUp, 
  Users, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ArrowLeft, 
  RefreshCw, 
  Sparkles,
  ExternalLink,
  ChevronRight,
  BarChart2
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { marketingService, agencyService } from '../../services/api';
import { Campaign } from '../../types/auth';

interface CampaignsPageProps {
  onNavigate: (page: string) => void;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const CampaignsPage: React.FC<CampaignsPageProps> = ({ onNavigate, onShowToast }) => {
  const { user } = useAuth();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'completed' | 'draft'>('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // New Campaign Form
  const [newTitle, setNewTitle] = useState('');
  const [newBrand, setNewBrand] = useState(user?.name || 'Brand Studio');
  const [newBudget, setNewBudget] = useState(60000);
  const [newPlatform, setNewPlatform] = useState('YouTube & Instagram');
  const [newStatus, setNewStatus] = useState<'active' | 'draft'>('active');

  const fetchCampaigns = async () => {
    setIsLoading(true);
    try {
      if (user?.role === 'agency') {
        const res = await agencyService.getDashboard();
        if (res.success && res.data?.campaigns) {
          setCampaigns(res.data.campaigns);
        }
      } else {
        const res = await marketingService.getDashboard();
        if (res.success && res.data?.campaigns) {
          setCampaigns(res.data.campaigns);
        }
      }
    } catch (err: any) {
      console.warn('Failed to load campaigns:', err);
      onShowToast?.('Failed to load campaigns from server', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCampaigns();
  }, [user?.role]);

  const handleCreateCampaign = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    setIsSubmitting(true);
    try {
      const payload = {
        title: newTitle.trim(),
        clientOrBrand: newBrand.trim(),
        brand: newBrand.trim(),
        budget: Number(newBudget),
        platform: newPlatform,
        status: newStatus
      };

      const res = user?.role === 'agency' 
        ? await agencyService.createCampaign(payload) 
        : await marketingService.createCampaign(payload);

      if (res.success) {
        onShowToast?.(`Campaign "${newTitle}" created successfully!`, 'success');
        setShowCreateModal(false);
        setNewTitle('');
        await fetchCampaigns();
      }
    } catch (err: any) {
      onShowToast?.(err.message || 'Failed to create campaign', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filtered campaigns
  const filteredCampaigns = useMemo(() => {
    return campaigns.filter(c => {
      const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q || 
        c.title.toLowerCase().includes(q) || 
        (c.clientOrBrand && c.clientOrBrand.toLowerCase().includes(q)) ||
        (c.platform && c.platform.toLowerCase().includes(q));
      return matchesStatus && matchesSearch;
    });
  }, [campaigns, statusFilter, searchQuery]);

  // Aggregate stats
  const totalBudget = useMemo(() => campaigns.reduce((s, c) => s + (c.budget || 0), 0), [campaigns]);
  const totalSpend = useMemo(() => campaigns.reduce((s, c) => s + (c.hasSpendData ? (c.spend || 0) : 0), 0), [campaigns]);
  const activeCount = useMemo(() => campaigns.filter(c => c.status === 'active').length, [campaigns]);
  const totalReach = useMemo(() => campaigns.reduce((s, c) => s + (c.reach || 0), 0), [campaigns]);

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-purple-100">
        <div>
          <button
            onClick={() => onNavigate('dashboard')}
            className="inline-flex items-center space-x-1.5 text-xs font-bold text-slate-500 hover:text-purple-700 transition-colors mb-2 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Dashboard</span>
          </button>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">Campaign Hub &amp; Progress</h1>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-100 text-purple-800">
              {user?.role?.toUpperCase()}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Track influencer marketing campaigns, deliverable milestones, budget allocation, and ROAS.
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={fetchCampaigns}
            disabled={isLoading}
            className="p-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 transition-colors cursor-pointer disabled:opacity-50"
            title="Refresh campaigns from database"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={() => setShowCreateModal(true)}
            className="px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold transition-all shadow-md flex items-center space-x-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>New Campaign</span>
          </button>
        </div>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-purple-100 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Total Campaigns</span>
            <span className="p-2 rounded-xl bg-purple-50 text-purple-700">
              <Target className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">{campaigns.length}</div>
          <div className="text-[11px] text-emerald-600 font-bold mt-1">{activeCount} active in market</div>
        </div>

        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-purple-100 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Allocated Budget</span>
            <span className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <DollarSign className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">
            ₹{totalBudget.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">₹{totalSpend.toLocaleString()} deployed to date</div>
        </div>

        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-purple-100 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Total Campaign Reach</span>
            <span className="p-2 rounded-xl bg-sky-50 text-sky-600">
              <Users className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">
            {totalReach > 1000000 ? `${(totalReach / 1000000).toFixed(1)}M` : totalReach.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Combined influencer audience</div>
        </div>

        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-purple-100 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Average ROAS</span>
            <span className="p-2 rounded-xl bg-pink-50 text-pink-600">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-emerald-600 mt-2">3.2x</div>
          <div className="text-[11px] text-slate-400 mt-1">Return on Ad Spend</div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-2xl p-4 border border-purple-100 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute inset-y-0 left-3 my-auto pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search campaigns by name or brand..."
            className="w-full pl-9 pr-3.5 py-2 rounded-xl border border-slate-200 text-xs text-slate-900 focus:ring-2 focus:ring-purple-500"
          />
        </div>

        <div className="flex items-center space-x-1.5 w-full md:w-auto">
          {(['all', 'active', 'completed', 'draft'] as const).map(st => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                statusFilter === st
                  ? 'bg-purple-700 text-white shadow-xs'
                  : 'text-slate-600 bg-slate-50 hover:bg-slate-100'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Campaign List */}
      {isLoading ? (
        <div className="bg-white rounded-3xl p-12 border border-purple-100 shadow-xs text-center">
          <RefreshCw className="w-8 h-8 text-purple-600 animate-spin mx-auto mb-3" />
          <p className="text-xs font-bold text-slate-700">Loading campaign records...</p>
        </div>
      ) : filteredCampaigns.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 border border-purple-100 shadow-xs text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center mx-auto">
            <Target className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">No campaigns found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            {searchQuery 
              ? `No campaigns matched "${searchQuery}".` 
              : 'Start your first influencer partnership or marketing campaign.'}
          </p>
          <button
            onClick={() => setShowCreateModal(true)}
            className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create Campaign</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredCampaigns.map(camp => {
            const isAct = camp.status === 'active';
            const isComp = camp.status === 'completed';
            const spend = camp.hasSpendData ? (camp.spend || 0) : 0;
            const budget = camp.budget || 50000;
            const spendPct = budget > 0 ? Math.min(100, Math.round((spend / budget) * 100)) : 0;

            return (
              <div 
                key={camp.id} 
                className="p-5 sm:p-6 rounded-3xl bg-white border border-purple-100 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-purple-600">
                      {camp.clientOrBrand || 'Brand Studio'}
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      isAct ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                      isComp ? 'bg-purple-50 text-purple-700 border border-purple-200' :
                      'bg-slate-100 text-slate-600 border border-slate-200'
                    }`}>
                      {camp.status}
                    </span>
                  </div>

                  <h3 className="text-base font-black text-slate-900 tracking-tight mt-1">
                    {camp.title}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Platform: <strong className="text-slate-700">{camp.platform || 'Multi-Platform'}</strong>
                  </p>

                  {/* Budget & Spend Progress */}
                  <div className="mt-4 space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500">Spend Progress:</span>
                      <span className="font-mono font-bold text-slate-900">
                        {camp.hasSpendData ? `₹${spend.toLocaleString()} / ₹${budget.toLocaleString()}` : `₹${budget.toLocaleString()} (Pending Spend)`}
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div 
                        className="bg-purple-600 h-2 rounded-full transition-all"
                        style={{ width: `${camp.hasSpendData ? spendPct : 0}%` }}
                      />
                    </div>
                  </div>

                  {/* Assigned Creators */}
                  {camp.assignedCreatorNames && camp.assignedCreatorNames.length > 0 && (
                    <div className="mt-4 pt-3 border-t border-slate-100">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                        Assigned Talent ({camp.assignedCreatorNames.length})
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {camp.assignedCreatorNames.map((name, i) => (
                          <span key={i} className="px-2 py-0.5 rounded-lg bg-purple-50 border border-purple-100 text-purple-900 text-[10px] font-semibold">
                            {name}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Bottom Metrics Bar */}
                <div className="pt-3 border-t border-slate-100 grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="p-2 rounded-xl bg-slate-50">
                    <div className="font-extrabold text-slate-900 font-mono">
                      {camp.reach ? (camp.reach > 1000 ? `${(camp.reach / 1000).toFixed(0)}K` : camp.reach) : '—'}
                    </div>
                    <div className="text-[10px] text-slate-400">Reach</div>
                  </div>

                  <div className="p-2 rounded-xl bg-slate-50">
                    <div className="font-extrabold text-slate-900 font-mono">
                      {camp.clicks ? camp.clicks.toLocaleString() : '—'}
                    </div>
                    <div className="text-[10px] text-slate-400">Clicks</div>
                  </div>

                  <div className="p-2 rounded-xl bg-emerald-50">
                    <div className="font-extrabold text-emerald-700 font-mono">
                      {camp.roas ? `${camp.roas}x` : '—'}
                    </div>
                    <div className="text-[10px] text-emerald-600">ROAS</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* New Campaign Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-md w-full border border-purple-100 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-purple-100">
              <h3 className="text-base font-black text-slate-900 tracking-tight flex items-center space-x-2">
                <Target className="w-4 h-4 text-purple-600" />
                <span>Launch New Campaign</span>
              </h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCreateCampaign} className="space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Campaign Title <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  required
                  placeholder="e.g. Q4 Flagship Tech Launch"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-900 focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Brand / Client Name
                </label>
                <input
                  type="text"
                  value={newBrand}
                  onChange={(e) => setNewBrand(e.target.value)}
                  placeholder="e.g. Synthetix AI"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-900 focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Budget (₹)
                  </label>
                  <input
                    type="number"
                    value={newBudget}
                    onChange={(e) => setNewBudget(Number(e.target.value))}
                    min={1000}
                    step={5000}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-900 focus:ring-2 focus:ring-purple-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Platform Target
                  </label>
                  <select
                    value={newPlatform}
                    onChange={(e) => setNewPlatform(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-medium text-slate-800 focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="YouTube & Instagram">YouTube &amp; Instagram</option>
                    <option value="YouTube Only">YouTube Only</option>
                    <option value="Instagram & TikTok">Instagram &amp; TikTok</option>
                    <option value="LinkedIn & X">LinkedIn &amp; X</option>
                    <option value="All Platforms">All Platforms</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold transition-all shadow-md flex items-center space-x-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Creating...</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" />
                      <span>Create Campaign</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
