import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  ArrowLeft, 
  Shield, 
  Bell, 
  Globe, 
  Lock, 
  Sliders, 
  CheckCircle2, 
  Sparkles, 
  Save, 
  Building, 
  Target, 
  Palette, 
  RefreshCw,
  KeyRound,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types/auth';

interface SettingsPageProps {
  onNavigate: (page: string) => void;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ onNavigate, onShowToast }) => {
  const { user, switchWorkspace } = useAuth();
  const [activeTab, setActiveTab] = useState<'workspaces' | 'notifications' | 'security' | 'platforms' | 'preferences'>('workspaces');
  const [isSwitching, setIsSwitching] = useState(false);

  // Preference states
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [viralSpikes, setViralSpikes] = useState(true);
  const [campaignMilestones, setCampaignMilestones] = useState(true);
  const [twoFactorAuth, setTwoFactorAuth] = useState(false);
  const [defaultCurrency, setDefaultCurrency] = useState<'INR' | 'USD'>('INR');
  const [defaultDateRange, setDefaultDateRange] = useState<'30d' | '90d' | '7d'>('30d');

  const userRoles: UserRole[] = (user?.roles && user.roles.length) 
    ? (user.roles as UserRole[]) 
    : (user?.role ? [user.role] : ['creator']);

  const handleRoleToggle = async (targetRole: UserRole) => {
    if (user?.role === targetRole) {
      onShowToast?.(`Already in ${targetRole.toUpperCase()} workspace.`, 'info');
      return;
    }

    setIsSwitching(true);
    try {
      const res = await switchWorkspace(targetRole);
      if (res.success) {
        onShowToast?.(`Switched active workspace to ${targetRole.toUpperCase()}!`, 'success');
        onNavigate('dashboard');
      } else {
        onShowToast?.(res.message || 'Workspace switch failed', 'error');
      }
    } catch (err: any) {
      onShowToast?.(err.message || 'Failed to switch workspace', 'error');
    } finally {
      setIsSwitching(false);
    }
  };

  const handleSavePreferences = (e: React.FormEvent) => {
    e.preventDefault();
    onShowToast?.('Application settings saved successfully!', 'success');
  };

  const getRoleConfig = (r: UserRole) => {
    switch (r) {
      case 'creator':
        return {
          title: 'Creator Workspace',
          badge: 'Creator',
          desc: 'Individual content performance, channel metrics, post scheduling, and brand pitch media kit.',
          icon: Palette,
          color: 'text-purple-600 bg-purple-50 border-purple-200'
        };
      case 'agency':
        return {
          title: 'Growth Agency Workspace',
          badge: 'Agency',
          desc: 'Talent roster management, creator discovery, brand contract tracking, and commission splits.',
          icon: Building,
          color: 'text-indigo-600 bg-indigo-50 border-indigo-200'
        };
      case 'marketing':
        return {
          title: 'Marketing Team Workspace',
          badge: 'Marketing',
          desc: 'Influencer campaign hub, conversion tracking, customer acquisition, ROAS, and ad spend monitoring.',
          icon: Target,
          color: 'text-sky-600 bg-sky-50 border-sky-200'
        };
      case 'admin':
        return {
          title: 'System Administrator Workspace',
          badge: 'Admin',
          desc: 'Platform-wide user management, RBAC role assignment, system health monitoring, and security audit logs.',
          icon: Shield,
          color: 'text-purple-800 bg-purple-100 border-purple-300'
        };
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-purple-100">
        <div>
          <button
            onClick={() => onNavigate('dashboard')}
            className="inline-flex items-center space-x-1.5 text-xs font-bold text-slate-500 hover:text-purple-700 transition-colors mb-2 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Dashboard</span>
          </button>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">Application Settings</h1>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-100 text-purple-800">
              {user?.role?.toUpperCase()}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Configure workspace switching, alert preferences, security rules, and platform integrations.
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-200 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('workspaces')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'workspaces' ? 'bg-purple-700 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>1. Assigned Workspaces ({userRoles.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('notifications')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'notifications' ? 'bg-purple-700 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          <span>2. Notifications &amp; Alerts</span>
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'security' ? 'bg-purple-700 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>3. Security &amp; Credentials</span>
        </button>

        <button
          onClick={() => setActiveTab('platforms')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'platforms' ? 'bg-purple-700 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Globe className="w-3.5 h-3.5" />
          <span>4. Connected APIs</span>
        </button>

        <button
          onClick={() => setActiveTab('preferences')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'preferences' ? 'bg-purple-700 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <SlidersIcon className="w-3.5 h-3.5" />
          <span>5. Preferences</span>
        </button>
      </div>

      {/* Tab 1: Workspaces & Role Switcher */}
      {activeTab === 'workspaces' && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-purple-100 shadow-xs space-y-5 animate-in fade-in">
          <div>
            <h2 className="text-base font-black text-slate-900 tracking-tight flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-purple-600" />
              <span>Multi-Role Workspace Switcher</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Your account (<strong className="text-purple-700">{user?.email}</strong>) is authorized for the workspaces below. Click any workspace to switch active permissions immediately.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {(user?.role === 'admin' || user?.roles?.includes('admin')
              ? (['creator', 'admin', 'agency', 'marketing'] as UserRole[])
              : userRoles
            ).map((rId) => {
              const cfg = getRoleConfig(rId);
              const RoleIcon = cfg.icon;
              const isActive = user?.role === rId;

              return (
                <div 
                  key={rId}
                  className={`p-5 rounded-2xl border transition-all flex flex-col justify-between ${
                    isActive 
                      ? 'bg-purple-50/70 border-purple-300 ring-2 ring-purple-500/20 shadow-xs' 
                      : 'bg-white border-slate-200 hover:border-purple-200 hover:shadow-xs'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2.5">
                        <div className={`p-2 rounded-xl ${cfg.color}`}>
                          <RoleIcon className="w-4 h-4" />
                        </div>
                        <h3 className="text-sm font-black text-slate-900">{cfg.title}</h3>
                      </div>
                      {isActive && (
                        <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-700 text-white">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Active Now</span>
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 mt-2.5 leading-relaxed">{cfg.desc}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[10px] font-mono text-slate-400">Permissions: RBAC Active</span>
                    {isActive ? (
                      <span className="text-xs font-bold text-purple-700">Currently viewing this dashboard</span>
                    ) : (
                      <button
                        onClick={() => handleRoleToggle(rId)}
                        disabled={isSwitching}
                        className="px-3.5 py-1.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold transition-all shadow-xs flex items-center space-x-1.5 cursor-pointer disabled:opacity-50"
                      >
                        {isSwitching ? (
                          <RefreshCw className="w-3 h-3 animate-spin" />
                        ) : (
                          <span>Switch to {cfg.badge} &rarr;</span>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: Notifications */}
      {activeTab === 'notifications' && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-purple-100 shadow-xs space-y-5 animate-in fade-in">
          <div>
            <h2 className="text-base font-black text-slate-900 tracking-tight flex items-center space-x-2">
              <Bell className="w-4 h-4 text-purple-600" />
              <span>Email &amp; In-App Notification Alerts</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Control which system alerts and real-time triggers send notifications.
            </p>
          </div>

          <div className="space-y-3">
            <label className="flex items-start space-x-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-100 cursor-pointer">
              <input
                type="checkbox"
                checked={viralSpikes}
                onChange={(e) => setViralSpikes(e.target.checked)}
                className="mt-0.5 w-4 h-4 rounded text-purple-600 focus:ring-purple-500"
              />
              <div>
                <div className="text-xs font-bold text-slate-900">Viral Engagement Spikes</div>
                <div className="text-[11px] text-slate-500">Alert me when a post passes 10,000 views or 7% engagement rate.</div>
              </div>
            </label>

            <label className="flex items-start space-x-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-100 cursor-pointer">
              <input
                type="checkbox"
                checked={campaignMilestones}
                onChange={(e) => setCampaignMilestones(e.target.checked)}
                className="mt-0.5 w-4 h-4 rounded text-purple-600 focus:ring-purple-500"
              />
              <div>
                <div className="text-xs font-bold text-slate-900">Brand Partnership &amp; Campaign Milestones</div>
                <div className="text-[11px] text-slate-500">Notify me about new campaign offers, contract signings, and client review feedback.</div>
              </div>
            </label>

            <label className="flex items-start space-x-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-100 cursor-pointer">
              <input
                type="checkbox"
                checked={emailAlerts}
                onChange={(e) => setEmailAlerts(e.target.checked)}
                className="mt-0.5 w-4 h-4 rounded text-purple-600 focus:ring-purple-500"
              />
              <div>
                <div className="text-xs font-bold text-slate-900">Weekly Performance Digest</div>
                <div className="text-[11px] text-slate-500">Receive a weekly summary email with follower growth, revenue earned, and top posts.</div>
              </div>
            </label>
          </div>
        </div>
      )}

      {/* Tab 3: Security & Credentials */}
      {activeTab === 'security' && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-purple-100 shadow-xs space-y-5 animate-in fade-in">
          <div>
            <h2 className="text-base font-black text-slate-900 tracking-tight flex items-center space-x-2">
              <Lock className="w-4 h-4 text-purple-600" />
              <span>Authentication &amp; Security Controls</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Manage your password, Firebase session credentials, and two-factor authentication.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-purple-50/60 border border-purple-100 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <KeyRound className="w-5 h-5 text-purple-700" />
              <div>
                <div className="text-xs font-bold text-slate-900">Account Password</div>
                <div className="text-[11px] text-slate-500">Update your login password securely via genuine email verification.</div>
              </div>
            </div>
            <button
              onClick={() => onNavigate('reset-password')}
              className="px-3.5 py-1.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
            >
              Reset Password
            </button>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-slate-900">Two-Factor Authentication (2FA)</div>
              <div className="text-[11px] text-slate-500">Require an additional security code when signing into administrative endpoints.</div>
            </div>
            <button
              onClick={() => setTwoFactorAuth(!twoFactorAuth)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                twoFactorAuth ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'
              }`}
            >
              {twoFactorAuth ? 'Enabled' : 'Disabled'}
            </button>
          </div>
        </div>
      )}

      {/* Tab 4: Connected Platforms Shortcut */}
      {activeTab === 'platforms' && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-purple-100 shadow-xs space-y-5 animate-in fade-in">
          <div className="flex items-center justify-between pb-3 border-b border-purple-50">
            <div>
              <h2 className="text-base font-black text-slate-900 tracking-tight flex items-center space-x-2">
                <Globe className="w-4 h-4 text-purple-600" />
                <span>Connected Social Platform Accounts</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Manage OAuth and API connections across YouTube, Instagram, TikTok, and X.
              </p>
            </div>
            <button
              onClick={() => onNavigate('social-accounts')}
              className="text-xs font-bold text-purple-700 hover:text-purple-900 cursor-pointer flex items-center space-x-1"
            >
              <span>Manage Platforms</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>

          <p className="text-xs text-slate-600">
            Click "Manage Platforms" above to open the full Platform Integrations manager, synchronize metrics, or input official developer keys.
          </p>
        </div>
      )}

      {/* Tab 5: Preferences */}
      {activeTab === 'preferences' && (
        <form onSubmit={handleSavePreferences} className="bg-white rounded-3xl p-6 sm:p-7 border border-purple-100 shadow-xs space-y-5 animate-in fade-in">
          <div>
            <h2 className="text-base font-black text-slate-900 tracking-tight flex items-center space-x-2">
              <SlidersIcon className="w-4 h-4 text-purple-600" />
              <span>Display &amp; Localization Preferences</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Customize default date filters, currency formats, and interface units.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                Default Currency Format
              </label>
              <select
                value={defaultCurrency}
                onChange={(e) => setDefaultCurrency(e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-purple-500"
              >
                <option value="INR">₹ INR (Indian Rupee)</option>
                <option value="USD">$ USD (US Dollar)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                Default Dashboard Date Range
              </label>
              <select
                value={defaultDateRange}
                onChange={(e) => setDefaultDateRange(e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-purple-500"
              >
                <option value="7d">Last 7 Days</option>
                <option value="30d">Last 30 Days (Standard)</option>
                <option value="90d">Last 90 Days</option>
              </select>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold transition-all shadow-md flex items-center space-x-2 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Preferences</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};

function SlidersIcon(props: { className?: string }) {
  return (
    <svg className={props.className || 'w-4 h-4'} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
    </svg>
  );
}
