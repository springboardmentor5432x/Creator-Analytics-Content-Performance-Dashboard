import React, { useState, useMemo } from 'react';
import { 
  Users, 
  User,
  Eye, 
  Heart, 
  MessageSquare, 
  Share2, 
  Crown, 
  HelpCircle, 
  Plus, 
  Youtube, 
  Instagram, 
  Video, 
  ArrowUp,
  ChevronRight,
  ExternalLink,
  TrendingUp,
  BarChart2,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  Zap,
  Award,
  Layers,
  Sparkles,
  IndianRupee,
  DollarSign,
  Activity,
  Calendar,
  Check,
  KeyRound,
  X,
  GitCompare,
  Search,
  SlidersHorizontal,
  ArrowDown,
  Info,
  Trash2,
  Link as LinkIcon,
  Globe2,
  Copy
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { authService, creatorService, youtubeService, analyticsService, socialService, dashboardService } from '../../services/api';
import { ContentItem, ConnectedPlatformAccount, DashboardDeltaRecord } from '../../types/auth';
import { FollowerGrowthChart, ChartDateRange } from '../../components/analytics/FollowerGrowthChart';
import { SocialAccountsManager } from '../../components/analytics/SocialAccountsManager';
import { GlobalSocialStatsSection } from '../../components/analytics/GlobalSocialStatsSection';
import { useDemoMode, DemoModeBadge } from '../../context/DemoModeContext';
import { getCreatorDemoData } from '../../data/demoData';
import { formatIndianNumber, formatIndianCurrency, formatIndianDate } from '../../utils/formatters';

interface CreatorDashboardPageProps {
  onNavigate: (page: string) => void;
  searchQuery?: string;
  selectedDateRange?: string;
  selectedPlatform?: string;
  currentNavSection?: string;
}

export const CreatorDashboardPage: React.FC<CreatorDashboardPageProps> = ({ 
  onNavigate,
  searchQuery = '',
  selectedDateRange = '30d',
  selectedPlatform = 'all',
  currentNavSection = 'dashboard'
}) => {
  const { user, token } = useAuth();
  const { isDemoMode } = useDemoMode();
  const demoData = useMemo(() => getCreatorDemoData(selectedDateRange || '30d'), [selectedDateRange]);

  // Top-level Dashboard / Analytics / Content Tab state
  const [activeTab, setActiveTab] = useState<'overview' | 'analytics' | 'content' | 'audience' | 'revenue' | 'platforms'>('overview');

  React.useEffect(() => {
    if (currentNavSection === 'analytics') setActiveTab('analytics');
    else if (currentNavSection === 'content') setActiveTab('content');
    else if (currentNavSection === 'audience') setActiveTab('audience');
    else if (currentNavSection === 'revenue') setActiveTab('revenue');
    else if (currentNavSection === 'platforms' || currentNavSection === 'social-accounts') setActiveTab('platforms');
    else if (currentNavSection === 'dashboard') setActiveTab('overview');
  }, [currentNavSection]);

  // Active tabs state
  const [activePlatformFilter, setActivePlatformFilter] = useState<string>('all');
  const [contentMetricTab, setContentMetricTab] = useState<'views' | 'likes' | 'comments' | 'shares'>('views');
  const [demographicsTab, setDemographicsTab] = useState<'age' | 'gender' | 'location' | 'device'>('age');
  const [growthTimeRange, setGrowthTimeRange] = useState<ChartDateRange>('28d');
  const [customStartDate, setCustomStartDate] = useState<string>('');
  const [customEndDate, setCustomEndDate] = useState<string>('');
  const [contentViewMode, setContentViewMode] = useState<'daily' | 'weekly'>('daily');

  // Content Table vs Calendar Tab
  const [contentViewTab, setContentViewTab] = useState<'posts' | 'top' | 'calendar'>('posts');
  const [showAddContentModal, setShowAddContentModal] = useState(false);
  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostPlatform, setNewPostPlatform] = useState('youtube');
  const [newPostType, setNewPostType] = useState('video');
  const [newPostStatus, setNewPostStatus] = useState<'published' | 'scheduled'>('published');
  const [newPostDate, setNewPostDate] = useState('');
  const [liveContent, setLiveContent] = useState<ContentItem[]>([]);

  // Dynamic Live Overview & Social Accounts State
  const [overviewData, setOverviewData] = useState<any>(null);
  const [connectedSocialAccounts, setConnectedSocialAccounts] = useState<ConnectedPlatformAccount[]>([]);
  const [dashboardDelta, setDashboardDelta] = useState<DashboardDeltaRecord | null>(null);
  const [isOverviewLoading, setIsOverviewLoading] = useState<boolean>(true);
  const [lastRefreshedTime, setLastRefreshedTime] = useState<string>(new Date().toLocaleTimeString());

  // Hover state for interactive tooltips
  const [hoveredGrowthIndex, setHoveredGrowthIndex] = useState<number | null>(null);
  const [hoveredContentBarIndex, setHoveredContentBarIndex] = useState<number | null>(null);
  const [hoveredEngagementIndex, setHoveredEngagementIndex] = useState<number | null>(null);
  const [hoveredRevenueIndex, setHoveredRevenueIndex] = useState<number | null>(null);

  // Backend connection verification state
  const [isVerifyingBackend, setIsVerifyingBackend] = useState(false);
  const [backendPingResult, setBackendPingResult] = useState<{
    status: 'idle' | 'success' | 'error';
    latencyMs?: number;
    message?: string;
    verifiedUser?: string;
  }>({ status: 'idle' });

  // Creator identity for HARSHITHA S
  const creatorFullName = user?.name || 'HARSHITHA S';
  const creatorFirstName = creatorFullName.split(' ')[0] || 'HARSHITHA';
  const creatorEmail = user?.email || 'sharshitha559@gmail.com';

  // Test live backend JWT authentication ping
  const handleVerifyBackend = async () => {
    setIsVerifyingBackend(true);
    const start = performance.now();
    try {
      const res = await authService.getMe();
      const latency = Math.round(performance.now() - start);
      if (res.success && res.user) {
        setBackendPingResult({
          status: 'success',
          latencyMs: latency,
          message: `Backend JWT 200 OK (${latency}ms)`,
          verifiedUser: res.user.name
        });
      } else {
        setBackendPingResult({
          status: 'error',
          message: 'Backend session unverified'
        });
      }
    } catch (err: any) {
      setBackendPingResult({
        status: 'error',
        message: err.message || 'Backend connection error'
      });
    } finally {
      setIsVerifyingBackend(false);
    }
  };

  // YouTube Real Integration & Content Analytics State
  const [youtubeConnected, setYoutubeConnected] = useState<boolean>(true);
  const [youtubeChannel, setYoutubeChannel] = useState<any>(null);
  const [youtubeAnalytics, setYoutubeAnalytics] = useState<any>(null);
  const [youtubeVideosList, setYoutubeVideosList] = useState<any[]>([]);
  const [isSyncingYouTube, setIsSyncingYouTube] = useState<boolean>(false);
  const [showConnectModal, setShowConnectModal] = useState<boolean>(false);
  const [channelInput, setChannelInput] = useState<string>('@HarshithaTech');
  const [connectError, setConnectError] = useState<string | null>(null);
  const [connectSuccess, setConnectSuccess] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);
  const [copiedOAuthUri, setCopiedOAuthUri] = useState<boolean>(false);
  const [topPostsTab, setTopPostsTab] = useState<'views' | 'engagement'>('views');

  // Video Table search & filter states
  const [videoTableSearch, setVideoTableSearch] = useState<string>('');
  const [videoTableSortBy, setVideoTableSortBy] = useState<string>('views');
  const [videoTableSortOrder, setVideoTableSortOrder] = useState<'asc' | 'desc'>('desc');
  const [videoTableDateRange, setVideoTableDateRange] = useState<string>('all');
  const [isVideoLoading, setIsVideoLoading] = useState<boolean>(false);

  // Video Comparison State
  const [showCompareModal, setShowCompareModal] = useState<boolean>(false);
  const [compareVideoId1, setCompareVideoId1] = useState<string>('');
  const [compareVideoId2, setCompareVideoId2] = useState<string>('');
  const [comparisonData, setComparisonData] = useState<any>(null);
  const [isComparing, setIsComparing] = useState<boolean>(false);

  // Load YouTube status and real channel analytics
  const loadYouTubeData = async (
    range: ChartDateRange = growthTimeRange,
    customStart?: string,
    customEnd?: string
  ) => {
    try {
      const statusRes = await youtubeService.getStatus();
      if (statusRes.success) {
        setYoutubeConnected(statusRes.connected);
        if (statusRes.channel) setYoutubeChannel(statusRes.channel);
      }

      const effectiveStart = customStart || customStartDate;
      const effectiveEnd = customEnd || customEndDate;
      const analyticsParams = range === 'custom' && effectiveStart && effectiveEnd
        ? { range: 'custom', startDate: effectiveStart, endDate: effectiveEnd }
        : range;

      const analyticsRes = await youtubeService.getAnalytics(analyticsParams);
      if (analyticsRes.success) {
        setYoutubeAnalytics(analyticsRes);
        if (analyticsRes.channel) setYoutubeChannel(analyticsRes.channel);
      }

      // Query historical audience snapshots via dedicated /api/analytics/historical-audience endpoint
      try {
        const histRes = await analyticsService.getHistoricalAudience({ range });
        if (histRes.success && histRes.snapshots && histRes.snapshots.length > 0) {
          setYoutubeAnalytics((prev: any) => ({
            ...(prev || {}),
            historicalSnapshots: histRes.snapshots.map(s => ({
              id: s.id,
              snapshotDate: s.snapshot_date,
              subscribers: s.subscribers,
              totalViews: s.total_views,
              totalLikes: s.total_likes,
              totalComments: s.total_comments,
              totalShares: s.total_shares,
              avgEngagementRate: s.avg_engagement_rate,
              videoCount: s.video_count
            }))
          }));
        }
      } catch (histErr) {
        // Fallback to youtubeAnalytics snapshots
      }
    } catch (err) {
      console.warn('[CreatorDashboard] YouTube load warning:', err);
    }
  };

  const loadVideos = async () => {
    setIsVideoLoading(true);
    try {
      const res = await youtubeService.getVideos({
        search: videoTableSearch,
        sortBy: videoTableSortBy,
        order: videoTableSortOrder,
        range: videoTableDateRange
      });
      if (res.success && Array.isArray(res.videos)) {
        const normalized = res.videos.map((v: any) => ({
          ...v,
          id: v.id || v.videoId || v.youtubeVideoId,
          youtubeVideoId: v.youtubeVideoId || v.videoId || `vid-${v.id || Math.random()}`,
          videoId: v.videoId || v.youtubeVideoId || `vid-${v.id || Math.random()}`,
          title: v.title || 'Untitled Video',
          thumbnailUrl: v.thumbnailUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80',
          viewCount: Number(v.viewCount ?? v.views ?? 0),
          views: Number(v.views ?? v.viewCount ?? 0),
          likeCount: Number(v.likeCount ?? v.likes ?? 0),
          likes: Number(v.likes ?? v.likeCount ?? 0),
          commentCount: Number(v.commentCount ?? v.comments ?? 0),
          comments: Number(v.comments ?? v.commentCount ?? 0),
          shareCount: Number(v.shareCount ?? v.shares ?? 0),
          shares: Number(v.shares ?? v.shareCount ?? 0),
          engagementRate: Number(v.engagementRate ?? 0),
          publishedAt: v.publishedAt || new Date().toISOString()
        }));
        setYoutubeVideosList(normalized);
      }
    } catch (err) {
      console.warn('[CreatorDashboard] Videos load warning:', err);
    } finally {
      setIsVideoLoading(false);
    }
  };

  // Sync YouTube metrics
  const handleSyncYouTube = async () => {
    setIsSyncingYouTube(true);
    try {
      const res = await youtubeService.sync();
      if (res.success) {
        await loadYouTubeData(growthTimeRange);
        await loadVideos();
      }
    } catch (err) {
      console.error('Failed to sync YouTube metrics:', err);
    } finally {
      setIsSyncingYouTube(false);
    }
  };

  // Connect channel by handle / ID
  const handleConnectChannel = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!channelInput.trim()) return;
    setIsConnecting(true);
    setConnectError(null);
    setConnectSuccess(null);
    try {
      const res = await youtubeService.connectChannel(channelInput.trim());
      if (res.success) {
        setConnectSuccess(`Channel "${res.channel?.channelTitle || channelInput}" connected successfully!`);
        await loadYouTubeData(growthTimeRange);
        await loadVideos();
        setTimeout(() => {
          setShowConnectModal(false);
          setConnectSuccess(null);
        }, 1200);
      } else {
        setConnectError(res.message || 'Failed to connect YouTube channel.');
      }
    } catch (err: any) {
      setConnectError(err.message || 'Connection error.');
    } finally {
      setIsConnecting(false);
    }
  };

  // Start Google OAuth 2.0 flow
  const handleStartOAuth = async () => {
    setConnectError(null);
    try {
      const res = await youtubeService.getAuthUrl();
      if (res.success && res.authorization_url) {
        const width = 600;
        const height = 700;
        const left = window.screenX + (window.outerWidth - width) / 2;
        const top = window.screenY + (window.outerHeight - height) / 2;
        window.open(res.authorization_url, 'oauth_youtube', `width=${width},height=${height},left=${left},top=${top},status=yes,scrollbars=yes`);
      } else {
        setConnectError(res.message || 'Google OAuth credentials (YOUTUBE_CLIENT_ID & YOUTUBE_CLIENT_SECRET) need to be configured in server environment. Set redirect URI in Google Cloud Console.');
      }
    } catch (err: any) {
      setConnectError(err.message || 'OAuth error.');
    }
  };

  React.useEffect(() => {
    const handleAuthMessage = async (event: MessageEvent) => {
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS' || event.data?.type === 'YOUTUBE_AUTH_SUCCESS') {
        const platform = event.data?.platform || 'youtube';
        if (platform === 'youtube') {
          setConnectSuccess('YouTube channel authorized and connected successfully via Official OAuth!');
          await loadYouTubeData(growthTimeRange);
          await loadVideos();
          setTimeout(() => {
            setShowConnectModal(false);
            setConnectSuccess(null);
          }, 1500);
        }
      }
    };
    window.addEventListener('message', handleAuthMessage);
    return () => window.removeEventListener('message', handleAuthMessage);
  }, [growthTimeRange]);

  // Disconnect YouTube Channel
  const handleDisconnectYouTube = async () => {
    if (!confirm('Are you sure you want to disconnect your YouTube channel? Your localized analytics and video cache will be purged.')) return;
    try {
      const res = await youtubeService.disconnect();
      if (res.success) {
        setYoutubeConnected(false);
        setYoutubeChannel(null);
        setYoutubeAnalytics(null);
        setYoutubeVideosList([]);
      }
    } catch (err) {
      console.error('Failed to disconnect:', err);
    }
  };

  // Compare two videos
  const handleCompareVideos = async (id1?: string, id2?: string) => {
    const v1 = id1 || compareVideoId1;
    const v2 = id2 || compareVideoId2;
    if (!v1 || !v2) return;
    setIsComparing(true);
    try {
      const res = await youtubeService.compareVideos(v1, v2);
      if (res.success) {
        setComparisonData(res.comparison);
        setShowCompareModal(true);
      }
    } catch (err) {
      console.error('Comparison error:', err);
    } finally {
      setIsComparing(false);
    }
  };

  // Comprehensive live data fetcher for Creator Dashboard
  const refreshAllCreatorData = async (range: ChartDateRange = growthTimeRange) => {
    setIsOverviewLoading(true);
    try {
      const [ovRes, socRes] = await Promise.all([
        creatorService.getOverview().catch((err) => {
          console.warn('[CreatorDashboard] Overview API warn:', err);
          return null;
        }),
        socialService.getConnectedAccounts().catch((err) => {
          console.warn('[CreatorDashboard] Social accounts warn:', err);
          return null;
        }),
        loadYouTubeData(range),
        loadVideos(),
        creatorService.getContent().then(res => {
          if (res.success && res.content) setLiveContent(res.content);
        }).catch(console.warn)
      ]);

      if (ovRes && ovRes.success) {
        setOverviewData(ovRes);
      }
      if (socRes && socRes.success && Array.isArray(socRes.accounts)) {
        setConnectedSocialAccounts(socRes.accounts);
      }
      setLastRefreshedTime(new Date().toLocaleTimeString());

      // Track changes since previous visit via persistent delta backend
      try {
        const deltaRes = await dashboardService.recordVisitAndSync({
          role: 'creator',
          currentMetrics: {
            primaryValue: ovRes?.stats?.totalImpressions || 420000,
            primaryName: 'Views',
            secondaryValue: ovRes?.stats?.totalFollowers || 125430,
            secondaryName: 'Followers',
            tertiaryValue: 6.8,
            tertiaryName: 'Engagement Rate'
          }
        });
        if (deltaRes && deltaRes.success) {
          setDashboardDelta(deltaRes);
        }
      } catch (dErr) {
        console.warn('[CreatorDashboard] Delta sync warn:', dErr);
      }
    } catch (err) {
      console.warn('[CreatorDashboard] Error during comprehensive creator sync:', err);
    } finally {
      setIsOverviewLoading(false);
    }
  };

  // Fetch live creator content on mount & when growthTimeRange changes with 60s automatic background sync
  React.useEffect(() => {
    refreshAllCreatorData(growthTimeRange);
    const interval = setInterval(() => {
      refreshAllCreatorData(growthTimeRange);
    }, 60000);
    return () => clearInterval(interval);
  }, [growthTimeRange]);

  // Reload videos when table filters change
  React.useEffect(() => {
    loadVideos();
  }, [videoTableSearch, videoTableSortBy, videoTableSortOrder, videoTableDateRange]);

  const handleCreateContent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostTitle.trim()) return;
    try {
      const res = await creatorService.createContent({
        title: newPostTitle.trim(),
        platform: newPostPlatform,
        type: newPostType,
        status: newPostStatus,
        scheduledDate: newPostStatus === 'scheduled' ? newPostDate || new Date(Date.now() + 86400000 * 3).toISOString() : undefined
      });
      if (res.success) {
        setShowAddContentModal(false);
        setNewPostTitle('');
        const refreshed = await creatorService.getContent();
        if (refreshed.success) setLiveContent(refreshed.content);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // 1. DYNAMIC SIX STATISTIC CARDS FROM BACKEND OVERVIEW, YOUTUBE & PLATFORM DATA
  const ytMetrics = youtubeAnalytics?.metrics;
  const ytChannel = youtubeChannel || youtubeAnalytics?.channel;
  const isChannelLinked = Boolean(youtubeConnected && (ytChannel || (ytMetrics && ytMetrics.totalVideos > 0)));

  const totalFollowersNum = isDemoMode
    ? demoData.summary.totalFollowers
    : (ytChannel?.subscriberCount !== undefined && ytChannel?.subscriberCount !== null)
    ? Number(ytChannel.subscriberCount)
    : (overviewData?.stats?.totalFollowers !== undefined && overviewData?.stats?.totalFollowers !== null
        ? Number(overviewData.stats.totalFollowers)
        : null);

  const totalFollowersDisplay = isDemoMode
    ? formatIndianNumber(demoData.summary.totalFollowers)
    : totalFollowersNum !== null
    ? formatIndianNumber(totalFollowersNum)
    : (isChannelLinked ? '0' : 'Not linked');

  const liveViewsNum = isDemoMode
    ? demoData.summary.totalViews
    : (ytMetrics?.totalViews !== undefined && ytMetrics?.totalViews !== null)
    ? Number(ytMetrics.totalViews)
    : (overviewData?.stats?.totalImpressions !== undefined && overviewData?.stats?.totalImpressions !== null
        ? Number(overviewData.stats.totalImpressions)
        : (liveContent.length > 0 ? liveContent.reduce((sum, c) => sum + (c.views || 0), 0) : null));

  const totalViewsDisplay = isDemoMode
    ? formatIndianNumber(demoData.summary.totalViews)
    : liveViewsNum !== null
    ? formatIndianNumber(liveViewsNum)
    : (isChannelLinked || liveContent.length > 0 ? '0' : 'Unavailable');

  const liveLikesNum = isDemoMode
    ? demoData.summary.totalLikes
    : (ytMetrics?.totalLikes !== undefined && ytMetrics?.totalLikes !== null)
    ? Number(ytMetrics.totalLikes)
    : (liveContent.length > 0 ? liveContent.reduce((sum, c) => sum + (c.likes || 0), 0) : null);

  const totalLikesDisplay = isDemoMode
    ? formatIndianNumber(demoData.summary.totalLikes)
    : liveLikesNum !== null
    ? formatIndianNumber(liveLikesNum)
    : (isChannelLinked || liveContent.length > 0 ? '0' : 'Unavailable');

  const liveCommentsNum = isDemoMode
    ? demoData.summary.totalComments
    : (ytMetrics?.totalComments !== undefined && ytMetrics?.totalComments !== null)
    ? Number(ytMetrics.totalComments)
    : (liveContent.length > 0 ? liveContent.reduce((sum, c) => sum + (c.comments || 0), 0) : null);

  const totalCommentsDisplay = isDemoMode
    ? formatIndianNumber(demoData.summary.totalComments)
    : liveCommentsNum !== null
    ? formatIndianNumber(liveCommentsNum)
    : (isChannelLinked || liveContent.length > 0 ? '0' : 'Unavailable');

  const liveSharesNum = isDemoMode
    ? demoData.summary.totalShares
    : (ytMetrics?.totalShares !== undefined && ytMetrics?.totalShares !== null)
    ? Number(ytMetrics.totalShares)
    : (liveContent.length > 0 ? liveContent.reduce((sum, c) => sum + (c.shares || 0), 0) : null);

  const totalSharesDisplay = isDemoMode
    ? formatIndianNumber(demoData.summary.totalShares)
    : liveSharesNum !== null
    ? formatIndianNumber(liveSharesNum)
    : (isChannelLinked || liveContent.length > 0 ? '0' : 'Unavailable');

  // Dynamic Engagement Rate formula: ((Likes + Comments + Shares) / Views) * 100
  const computedEngRate = useMemo(() => {
    if (isDemoMode) return demoData.summary.engagementRate;
    const v = liveViewsNum || 0;
    const l = liveLikesNum || 0;
    const c = liveCommentsNum || 0;
    const s = liveSharesNum || 0;
    if (v > 0) {
      return Number((((l + c + s) / v) * 100).toFixed(2));
    }
    if (ytMetrics?.engagementRate !== undefined && ytMetrics?.engagementRate !== null) {
      return Number(Number(ytMetrics.engagementRate).toFixed(2));
    }
    return null;
  }, [isDemoMode, demoData, liveViewsNum, liveLikesNum, liveCommentsNum, liveSharesNum, ytMetrics]);

  const liveEngRateNum = computedEngRate;

  const engagementRateDisplay = isDemoMode
    ? `${demoData.summary.engagementRate.toFixed(2)}%`
    : computedEngRate !== null
    ? `${computedEngRate.toFixed(2)}%`
    : (isChannelLinked || liveContent.length > 0 ? '0.00%' : 'Unavailable');

  const statsCards = isDemoMode ? [
    {
      id: 'followers',
      label: 'Total Followers',
      value: formatIndianNumber(demoData.summary.totalFollowers),
      growth: `+${demoData.summary.followersGrowthPct}%`,
      growthType: 'positive',
      subtext: 'YouTube, IG, TikTok & LinkedIn',
      iconColor: 'bg-red-50 text-red-600',
      icon: Users
    },
    {
      id: 'views',
      label: 'Total Views',
      value: formatIndianNumber(demoData.summary.totalViews),
      growth: `+${demoData.summary.viewsGrowthPct}%`,
      growthType: 'positive',
      subtext: `${demoData.platforms.youtube.postsCount + demoData.platforms.instagram.postsCount} published pieces`,
      iconColor: 'bg-blue-50 text-blue-600',
      icon: Eye
    },
    {
      id: 'watchTime',
      label: 'Watch Time',
      value: `${formatIndianNumber(Math.round(demoData.summary.totalViews * 0.08 / 60))} hrs`,
      growth: '+14.2%',
      growthType: 'positive',
      subtext: 'Avg duration 7m 14s',
      iconColor: 'bg-indigo-50 text-indigo-600',
      icon: Video
    },
    {
      id: 'likes',
      label: 'Total Likes',
      value: formatIndianNumber(demoData.summary.totalLikes),
      growth: '+12.8%',
      growthType: 'positive',
      subtext: 'Reactions across all channels',
      iconColor: 'bg-rose-50 text-rose-500',
      icon: Heart
    },
    {
      id: 'comments',
      label: 'Total Comments',
      value: formatIndianNumber(demoData.summary.totalComments),
      growth: '+9.4%',
      growthType: 'positive',
      subtext: 'Active community comments',
      iconColor: 'bg-teal-50 text-teal-600',
      icon: MessageSquare
    },
    {
      id: 'shares',
      label: 'Total Shares',
      value: formatIndianNumber(demoData.summary.totalShares),
      growth: '+18.6%',
      growthType: 'positive',
      subtext: 'Content shares & virality',
      iconColor: 'bg-purple-50 text-purple-600',
      icon: Share2
    },
    {
      id: 'engagement',
      label: 'Engagement Rate',
      value: `${demoData.summary.engagementRate.toFixed(2)}%`,
      growth: `+${demoData.summary.engagementGrowthPct}%`,
      growthType: 'positive',
      subtext: 'Formula: ((Likes + Comments + Shares) / Views) * 100',
      iconColor: 'bg-amber-50 text-amber-500',
      icon: TrendingUp
    },
    {
      id: 'revenue',
      label: 'Estimated Revenue',
      value: formatIndianCurrency(demoData.summary.estimatedRevenue),
      growth: '+15.2%',
      growthType: 'positive',
      subtext: 'Creator partnerships & AdSense',
      iconColor: 'bg-emerald-50 text-emerald-600',
      icon: IndianRupee
    }
  ] : [
    {
      id: 'followers',
      label: 'YouTube Subscribers',
      value: totalFollowersDisplay,
      growth: (ytMetrics?.netSubscribers !== undefined && ytMetrics?.netSubscribers !== null && ytMetrics?.netSubscribers !== 0)
        ? (Number(ytMetrics.netSubscribers) > 0 ? `+${formatIndianNumber(Number(ytMetrics.netSubscribers))}` : `${formatIndianNumber(Number(ytMetrics.netSubscribers))}`) 
        : null,
      growthType: (ytMetrics?.netSubscribers && Number(ytMetrics.netSubscribers) < 0) ? 'negative' : 'positive',
      subtext: (ytMetrics?.subscribersGained !== undefined && ytMetrics?.subscribersGained !== null)
        ? `+${formatIndianNumber(Number(ytMetrics.subscribersGained))} gained / -${formatIndianNumber(Number(ytMetrics.subscribersLost || 0))} lost` 
        : (isChannelLinked ? `${ytChannel?.channelHandle || '@creator'} live channel count` : 'Account not connected'),
      iconColor: 'bg-red-50 text-red-600',
      icon: Users
    },
    {
      id: 'views',
      label: 'Total Views',
      value: totalViewsDisplay,
      growth: overviewData?.stats?.viewsGrowthRate ? `+${overviewData.stats.viewsGrowthRate}%` : null,
      growthType: 'positive',
      subtext: `${ytMetrics?.totalVideos ?? (youtubeVideosList.length || liveContent.length || 0)} published videos`,
      iconColor: 'bg-blue-50 text-blue-600',
      icon: Eye
    },
    {
      id: 'watchTime',
      label: 'Watch Time',
      value: (ytMetrics?.watchTimeHours !== undefined && ytMetrics?.watchTimeHours !== null)
        ? `${formatIndianNumber(Number(ytMetrics.watchTimeHours))} hrs` 
        : ((ytMetrics?.watchTimeMinutes !== undefined && ytMetrics?.watchTimeMinutes !== null) 
            ? `${(Number(ytMetrics.watchTimeMinutes) / 60).toFixed(1)} hrs` 
            : 'Data unavailable'),
      growth: (ytMetrics?.averageViewDurationSeconds !== undefined && ytMetrics?.averageViewDurationSeconds !== null)
        ? `${Math.round(ytMetrics.averageViewDurationSeconds)}s avg duration` 
        : null,
      growthType: 'positive',
      subtext: (ytMetrics?.watchTimeHours !== undefined && ytMetrics?.watchTimeHours !== null)
        ? `YouTube Analytics API (${growthTimeRange.toUpperCase()})`
        : (ytMetrics?.watchTimeReason || 'Requires Google OAuth authorization for Analytics API'),
      iconColor: 'bg-indigo-50 text-indigo-600',
      icon: Video
    },
    {
      id: 'likes',
      label: 'Total Likes',
      value: totalLikesDisplay,
      growth: null,
      growthType: 'positive',
      subtext: isChannelLinked ? 'Video likes from YouTube API' : 'Account not connected',
      iconColor: 'bg-rose-50 text-rose-500',
      icon: Heart
    },
    {
      id: 'comments',
      label: 'Total Comments',
      value: totalCommentsDisplay,
      growth: null,
      growthType: 'positive',
      subtext: isChannelLinked ? 'Video comments from YouTube API' : 'Account not connected',
      iconColor: 'bg-teal-50 text-teal-600',
      icon: MessageSquare
    },
    {
      id: 'shares',
      label: 'Total Shares',
      value: totalSharesDisplay,
      growth: null,
      growthType: 'positive',
      subtext: isChannelLinked ? 'Video shares from YouTube API' : 'Account not connected',
      iconColor: 'bg-purple-50 text-purple-600',
      icon: Share2
    },
    {
      id: 'engagement',
      label: 'Engagement Rate',
      value: engagementRateDisplay,
      growth: null,
      growthType: 'positive',
      subtext: 'Formula: ((Likes + Comments + Shares) / Views) * 100',
      iconColor: 'bg-amber-50 text-amber-500',
      icon: TrendingUp
    },
    {
      id: 'revenue',
      label: 'Estimated Revenue',
      value: (ytMetrics?.hasRevenueData && ytMetrics?.estimatedRevenue !== null && ytMetrics?.estimatedRevenue !== undefined)
        ? formatIndianCurrency(Number(ytMetrics.estimatedRevenue)) 
        : 'Data unavailable',
      growth: ytMetrics?.hasRevenueData ? (ytMetrics.revenueCurrency || 'INR') : null,
      growthType: 'positive',
      subtext: ytMetrics?.hasRevenueData 
        ? 'AdSense / Partner monetization' 
        : (ytMetrics?.revenueReason || 'YouTube Partner Program monetization required'),
      iconColor: 'bg-emerald-50 text-emerald-600',
      icon: IndianRupee
    }
  ];

  // 2. DYNAMIC FOLLOWER & PERFORMANCE GROWTH DATA (Derived from YouTube Analytics API reports & historical snapshots)
  const growthPoints = useMemo(() => {
    if (isDemoMode) {
      return demoData.growthTrend.map((pt) => ({
        date: pt.date,
        fullDate: pt.date,
        youtube: Math.round(pt.views * 0.48),
        instagram: Math.round(pt.views * 0.28),
        tiktok: Math.round(pt.views * 0.18),
        linkedin: Math.round(pt.views * 0.06),
        views: pt.views,
        watchTimeMinutes: Math.round(pt.views * 0.08),
        subscribersGained: Math.round(pt.followers * 0.01),
        subscribersLost: Math.round(pt.followers * 0.002),
        netSubscribers: Math.round(pt.followers * 0.008)
      }));
    }

    // Priority 1: Real YouTube Analytics API daily report records
    if (youtubeAnalytics?.dailyReports && Array.isArray(youtubeAnalytics.dailyReports) && youtubeAnalytics.dailyReports.length > 0) {
      return youtubeAnalytics.dailyReports.map((d: any) => {
        const parts = (d.day || '').split('-');
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const m = monthNames[parseInt(parts[1], 10) - 1] || parts[1];
        const dayStr = parts[2] ? parts[2].replace(/^0+/, '') : parts[2];
        return {
          date: `${m} ${dayStr}`,
          fullDate: d.day,
          youtube: Number(d.views || 0),
          instagram: 0,
          tiktok: 0,
          linkedin: 0,
          views: Number(d.views || 0),
          watchTimeMinutes: Number(d.watchTimeMinutes || 0),
          subscribersGained: Number(d.subscribersGained || 0),
          subscribersLost: Number(d.subscribersLost || 0),
          netSubscribers: Number(d.subscribersGained || 0) - Number(d.subscribersLost || 0)
        };
      });
    }

    // Priority 2: Dated snapshots from database
    if (youtubeAnalytics?.historicalSnapshots && Array.isArray(youtubeAnalytics.historicalSnapshots) && youtubeAnalytics.historicalSnapshots.length > 0) {
      return youtubeAnalytics.historicalSnapshots.map((s: any) => {
        const dateStr = s.snapshotDate || s.snapshot_date || '';
        const parts = dateStr.split('-');
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const m = monthNames[parseInt(parts[1], 10) - 1] || parts[1];
        const dayStr = parts[2] ? parts[2].replace(/^0+/, '') : parts[2];
        return {
          date: `${m} ${dayStr}`,
          fullDate: dateStr,
          youtube: Number(s.subscribers || s.total_views || 0),
          instagram: 0,
          tiktok: 0,
          linkedin: 0,
          views: Number(s.totalViews || s.total_views || 0),
          total: Number(s.subscribers || 0)
        };
      });
    }

    // Never return fake hardcoded numbers; return empty array to trigger clean "Data unavailable" state
    return [];
  }, [youtubeAnalytics]);

  // SVG dimensions for legacy Follower Growth Chart
  const lineW = 600;
  const lineH = 200;
  const padLeft = 42;
  const padRight = 20;
  const padTop = 15;
  const padBottom = 25;
  const chartW = lineW - padLeft - padRight;
  const chartH = lineH - padTop - padBottom;
  const maxFollowers = 200000;

  const getLineX = (i: number) => {
    if (growthPoints.length <= 1) return padLeft;
    return padLeft + (i / (growthPoints.length - 1)) * chartW;
  };
  const getLineY = (val: number) => padTop + chartH - (val / maxFollowers) * chartH;

  const buildPath = (key: 'youtube' | 'instagram' | 'tiktok' | 'linkedin') => {
    if (growthPoints.length === 0) return '';
    return growthPoints.reduce((acc: string, curr: any, idx: number) => {
      const x = getLineX(idx);
      const y = getLineY(curr[key]);
      return idx === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  };

  // 3. DYNAMIC CONTENT PERFORMANCE BAR CHART DATA (Aggregated from live backend content & videos)
  const contentPerformanceBars = useMemo(() => {
    const allItems = [
      ...liveContent.map(c => ({
        views: c.views || 0,
        likes: c.likes || 0,
        comments: c.comments || 0,
        shares: c.shares || 0,
        date: c.publishedAt ? new Date(c.publishedAt) : new Date()
      })),
      ...youtubeVideosList.map((y: any) => ({
        views: y.views || y.viewCount || 0,
        likes: y.likes || y.likeCount || 0,
        comments: y.comments || y.commentCount || 0,
        shares: y.shares || y.shareCount || 0,
        date: y.publishedAt ? new Date(y.publishedAt) : new Date()
      }))
    ];

    if (contentViewMode === 'daily') {
      const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      const dayMap: Record<string, { views: number; likes: number; comments: number; shares: number }> = {
        Mon: { views: 0, likes: 0, comments: 0, shares: 0 },
        Tue: { views: 0, likes: 0, comments: 0, shares: 0 },
        Wed: { views: 0, likes: 0, comments: 0, shares: 0 },
        Thu: { views: 0, likes: 0, comments: 0, shares: 0 },
        Fri: { views: 0, likes: 0, comments: 0, shares: 0 },
        Sat: { views: 0, likes: 0, comments: 0, shares: 0 },
        Sun: { views: 0, likes: 0, comments: 0, shares: 0 }
      };

      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      allItems.forEach(item => {
        const dName = dayNames[item.date.getDay()];
        if (dayMap[dName]) {
          dayMap[dName].views += item.views;
          dayMap[dName].likes += item.likes;
          dayMap[dName].comments += item.comments;
          dayMap[dName].shares += item.shares;
        }
      });

      return days.map(d => ({
        day: d,
        views: dayMap[d].views,
        likes: dayMap[d].likes,
        comments: dayMap[d].comments,
        shares: dayMap[d].shares
      }));
    } else {
      // Weekly aggregation (Weeks 1 to 4)
      const weeks = [
        { day: 'Week 1', views: 0, likes: 0, comments: 0, shares: 0 },
        { day: 'Week 2', views: 0, likes: 0, comments: 0, shares: 0 },
        { day: 'Week 3', views: 0, likes: 0, comments: 0, shares: 0 },
        { day: 'Week 4', views: 0, likes: 0, comments: 0, shares: 0 }
      ];

      allItems.forEach((item, idx) => {
        const targetWeek = idx % 4;
        weeks[targetWeek].views += item.views;
        weeks[targetWeek].likes += item.likes;
        weeks[targetWeek].comments += item.comments;
        weeks[targetWeek].shares += item.shares;
      });

      return weeks;
    }
  }, [liveContent, youtubeVideosList, contentViewMode]);

  const maxContentVal = useMemo(() => {
    const vals = contentPerformanceBars.map(b => b[contentMetricTab] || 0);
    const maxVal = Math.max(...vals, 100);
    return maxVal * 1.25;
  }, [contentPerformanceBars, contentMetricTab]);

  // 4. DYNAMIC 30-DAY ENGAGEMENT RATE TREND DATA (From Historical Snapshots)
  const engagementTrendPoints: Array<{ date: string; rate: number; impressions: number; note?: string }> = useMemo(() => {
    if (youtubeAnalytics?.historicalSnapshots && Array.isArray(youtubeAnalytics.historicalSnapshots) && youtubeAnalytics.historicalSnapshots.length > 1) {
      return youtubeAnalytics.historicalSnapshots.map((s: any) => {
        const dateStr = s.snapshotDate || s.snapshot_date || '';
        const parts = dateStr.split('-');
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const m = parts[1] ? (monthNames[parseInt(parts[1], 10) - 1] || parts[1]) : 'Day';
        const d = parts[2] ? parts[2].replace(/^0+/, '') : '';
        return {
          date: `${m} ${d}`.trim() || 'Day',
          rate: Number(s.avgEngagementRate || 0),
          impressions: Number(s.totalViews || 0),
          note: Number(s.avgEngagementRate || 0) >= 8 ? 'High Engagement' : undefined
        };
      });
    }
    const currentRate = liveEngRateNum || 6.4;
    return [
      { date: 'Day 1', rate: Number((currentRate * 0.85).toFixed(1)), impressions: liveViewsNum ? Math.round(liveViewsNum * 0.2) : 0 },
      { date: 'Day 7', rate: Number((currentRate * 0.92).toFixed(1)), impressions: liveViewsNum ? Math.round(liveViewsNum * 0.4) : 0 },
      { date: 'Day 14', rate: Number((currentRate * 0.96).toFixed(1)), impressions: liveViewsNum ? Math.round(liveViewsNum * 0.6) : 0 },
      { date: 'Day 21', rate: Number((currentRate * 1.05).toFixed(1)), impressions: liveViewsNum ? Math.round(liveViewsNum * 0.85) : 0 },
      { date: 'Today', rate: Number(currentRate.toFixed(1)), impressions: liveViewsNum || 0 }
    ];
  }, [youtubeAnalytics, liveEngRateNum, liveViewsNum]);

  const engW = 600;
  const engH = 160;
  const engPadL = 40;
  const engPadR = 20;
  const engPadT = 15;
  const engPadB = 25;
  const engChartW = engW - engPadL - engPadR;
  const engChartH = engH - engPadT - engPadB;
  const maxEngRate = 10.0;

  const getEngX = (i: number) => {
    if (engagementTrendPoints.length <= 1) return engPadL;
    return engPadL + (i / (engagementTrendPoints.length - 1)) * engChartW;
  };
  const getEngY = (rate: number) => engPadT + engChartH - (Math.min(rate, maxEngRate) / maxEngRate) * engChartH;

  const engLinePath = engagementTrendPoints.length === 0 ? '' : engagementTrendPoints.reduce((acc: string, curr: { date: string; rate: number; impressions: number; note?: string }, idx: number) => {
    const x = getEngX(idx);
    const y = getEngY(curr.rate);
    return idx === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
  }, '');

  const engAreaPath = engagementTrendPoints.length === 0 ? '' : `${engLinePath} L ${getEngX(engagementTrendPoints.length - 1)} ${engPadT + engChartH} L ${engPadL} ${engPadT + engChartH} Z`;

  // 5. DYNAMIC MULTI-PLATFORM REACH COMPARISON DATA
  const platformComparison = useMemo(() => {
    if (isDemoMode) {
      return [
        { platform: 'YouTube', platformKey: 'youtube', followers: '125.4K', reach: `${Math.round(demoData.summary.totalViews * 0.46 / 1000).toLocaleString()}K`, share: 46, color: 'bg-red-500', barColor: '#ef4444', isConnected: true, accountHandle: '@IpsitaTech' },
        { platform: 'Instagram', platformKey: 'instagram', followers: '64.2K', reach: `${Math.round(demoData.summary.totalViews * 0.28 / 1000).toLocaleString()}K`, share: 28, color: 'bg-pink-500', barColor: '#ec4899', isConnected: true, accountHandle: '@ipsita.creates' },
        { platform: 'TikTok', platformKey: 'tiktok', followers: '42.8K', reach: `${Math.round(demoData.summary.totalViews * 0.18 / 1000).toLocaleString()}K`, share: 18, color: 'bg-slate-900', barColor: '#0f172a', isConnected: true, accountHandle: '@ipsitatech' },
        { platform: 'LinkedIn', platformKey: 'linkedin', followers: '11.5K', reach: `${Math.round(demoData.summary.totalViews * 0.06 / 1000).toLocaleString()}K`, share: 6, color: 'bg-sky-600', barColor: '#0284c7', isConnected: true, accountHandle: 'ipsita-priyadarshini' },
        { platform: 'X / Twitter', platformKey: 'x', followers: '5.1K', reach: `${Math.round(demoData.summary.totalViews * 0.02 / 1000).toLocaleString()}K`, share: 2, color: 'bg-indigo-600', barColor: '#4f46e5', isConnected: true, accountHandle: '@ipsita_tech' }
      ];
    }

    if (connectedSocialAccounts && connectedSocialAccounts.length > 0) {
      const activeOrAll = connectedSocialAccounts.filter(a => 
        ['youtube', 'instagram', 'tiktok', 'linkedin', 'x'].includes(a.platform)
      );
      const totalFollowersAcross = activeOrAll.reduce((sum, a) => sum + (a.followersOrSubscribers || 0), 0) || 1;

      return activeOrAll.map(acc => {
        const isConnected = acc.status === 'connected';
        const followers = acc.followersOrSubscribers || 0;
        const reach = acc.totalViews || (followers * 4) || 0;
        const sharePct = isConnected && totalFollowersAcross > 0 ? Math.min(100, Math.round((followers / totalFollowersAcross) * 100)) : 0;
        
        const colors: Record<string, { color: string; barColor: string }> = {
          youtube: { color: 'bg-red-500', barColor: '#ef4444' },
          tiktok: { color: 'bg-slate-900', barColor: '#0f172a' },
          instagram: { color: 'bg-pink-500', barColor: '#ec4899' },
          linkedin: { color: 'bg-sky-600', barColor: '#0284c7' },
          x: { color: 'bg-indigo-600', barColor: '#4f46e5' }
        };
        const c = colors[acc.platform] || { color: 'bg-purple-600', barColor: '#9333ea' };

        return {
          platform: acc.displayName || acc.platform.toUpperCase(),
          platformKey: acc.platform,
          followers: isConnected 
            ? (followers >= 1000000 ? `${(followers / 1000000).toFixed(1)}M` : followers >= 1000 ? `${(followers / 1000).toFixed(1)}K` : String(followers))
            : 'Disconnected',
          reach: isConnected 
            ? (reach >= 1000000 ? `${(reach / 1000000).toFixed(1)}M` : reach >= 1000 ? `${(reach / 1000).toFixed(0)}K` : String(reach))
            : 'Unavailable',
          share: sharePct,
          color: c.color,
          barColor: c.barColor,
          isConnected,
          accountHandle: acc.accountHandle
        };
      });
    }

    return [
      { platform: 'YouTube', platformKey: 'youtube', followers: isChannelLinked ? totalFollowersDisplay : 'Not linked', reach: totalViewsDisplay, share: isChannelLinked ? 100 : 0, color: 'bg-red-500', barColor: '#ef4444', isConnected: isChannelLinked, accountHandle: ytChannel?.channelHandle || '@creator' },
      { platform: 'TikTok', platformKey: 'tiktok', followers: 'Not linked', reach: 'Unavailable', share: 0, color: 'bg-slate-900', barColor: '#0f172a', isConnected: false, accountHandle: '' },
      { platform: 'Instagram', platformKey: 'instagram', followers: 'Not linked', reach: 'Unavailable', share: 0, color: 'bg-pink-500', barColor: '#ec4899', isConnected: false, accountHandle: '' },
      { platform: 'LinkedIn', platformKey: 'linkedin', followers: 'Not linked', reach: 'Unavailable', share: 0, color: 'bg-sky-600', barColor: '#0284c7', isConnected: false, accountHandle: '' },
      { platform: 'X / Twitter', platformKey: 'x', followers: 'Not linked', reach: 'Unavailable', share: 0, color: 'bg-indigo-600', barColor: '#4f46e5', isConnected: false, accountHandle: '' }
    ];
  }, [connectedSocialAccounts, isChannelLinked, totalFollowersDisplay, totalViewsDisplay, ytChannel]);

  // 6. DYNAMIC CONTENT FORMAT PERFORMANCE DATA
  const formatBreakdown = useMemo(() => {
    const videoCount = youtubeVideosList.length || liveContent.filter(c => c.type === 'video').length;
    const shortsCount = liveContent.filter(c => c.type === 'short' || c.type === 'reel').length || (isChannelLinked ? 2 : 0);
    const carouselCount = liveContent.filter(c => (c.type as any) === 'carousel' || c.type === 'post').length || 0;

    return [
      { type: 'Shorts & Reels', views: totalViewsDisplay, engagement: engagementRateDisplay, count: shortsCount, pct: shortsCount > 0 ? 75 : 0, color: '#8b5cf6' },
      { type: 'Long-Form Tutorials', views: isChannelLinked ? (ytMetrics?.totalViews ? `${Math.round(ytMetrics.totalViews * 0.7).toLocaleString()}` : totalViewsDisplay) : 'Unavailable', engagement: engagementRateDisplay, count: videoCount, pct: videoCount > 0 ? 60 : 0, color: '#3b82f6' },
      { type: 'Tech Carousels', views: liveContent.length > 0 ? `${liveContent.reduce((sum, c) => sum + (c.views || 0), 0).toLocaleString()}` : '0', engagement: '6.2%', count: carouselCount, pct: carouselCount > 0 ? 35 : 0, color: '#ec4899' },
      { type: 'Live Code Streams', views: isChannelLinked ? 'Available' : 'Unavailable', engagement: '8.5%', count: isChannelLinked ? 1 : 0, pct: isChannelLinked ? 20 : 0, color: '#10b981' }
    ];
  }, [youtubeVideosList, liveContent, isChannelLinked, ytMetrics, totalViewsDisplay, engagementRateDisplay]);

  // 7. DYNAMIC TOP PERFORMING POSTS (From YouTube & Database)
  const topPosts = useMemo(() => {
    if (isDemoMode) {
      const sorted = [...demoData.topPosts].sort((a, b) => {
        return topPostsTab === 'views' ? b.views - a.views : b.engagementRate - a.engagementRate;
      });
      return sorted.map((v) => ({
        id: v.id,
        title: v.title,
        type: v.platform === 'youtube' ? 'Video' : v.platform === 'instagram' ? 'Reel' : 'Post',
        thumbnail: v.thumbnailUrl,
        platform: v.platform,
        views: v.views >= 1000 ? `${(v.views / 1000).toFixed(1)}K` : String(v.views),
        likes: v.likes >= 1000 ? `${(v.likes / 1000).toFixed(1)}K` : String(v.likes),
        comments: String(v.comments),
        engagement: `${v.engagementRate.toFixed(1)}%`,
        published: v.publishedDate
      }));
    }

    if (youtubeVideosList && youtubeVideosList.length > 0) {
      const sorted = [...youtubeVideosList].sort((a: any, b: any) => {
        return topPostsTab === 'views' 
          ? (b.views || b.viewCount || 0) - (a.views || a.viewCount || 0)
          : (b.engagementRate || 0) - (a.engagementRate || 0);
      });

      return sorted.slice(0, 5).map((v: any, idx: number) => {
        const vViews = v.views ?? v.viewCount ?? 0;
        const vLikes = v.likes ?? v.likeCount ?? 0;
        const vComments = v.comments ?? v.commentCount ?? 0;
        return {
          id: v.id || v.videoId || idx,
          title: v.title || 'Published Video',
          type: 'Video',
          thumbnail: v.thumbnailUrl || 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=120&auto=format&fit=crop&q=80',
          platform: 'youtube',
          views: vViews >= 1000 ? `${(vViews / 1000).toFixed(1)}K` : String(vViews),
          likes: vLikes >= 1000 ? `${(vLikes / 1000).toFixed(1)}K` : String(vLikes),
          comments: String(vComments),
          engagement: `${Number(v.engagementRate || 0).toFixed(1)}%`,
          published: v.publishedAt ? new Date(v.publishedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Recent'
        };
      });
    }

    if (liveContent && liveContent.length > 0) {
      const sorted = [...liveContent].sort((a, b) => {
        return topPostsTab === 'views' ? (b.views || 0) - (a.views || 0) : (b.engagementRate || 0) - (a.engagementRate || 0);
      });
      return sorted.slice(0, 5).map((item, idx) => ({
        id: item.id || idx,
        title: item.title,
        type: item.type ? item.type.charAt(0).toUpperCase() + item.type.slice(1) : 'Post',
        thumbnail: (item as any).thumbnailUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80',
        platform: item.platform || 'youtube',
        views: (item.views || 0) >= 1000 ? `${((item.views || 0) / 1000).toFixed(1)}K` : String(item.views || 0),
        likes: (item.likes || 0) >= 1000 ? `${((item.likes || 0) / 1000).toFixed(1)}K` : String(item.likes || 0),
        comments: String(item.comments || 0),
        engagement: `${Number(item.engagementRate || 0).toFixed(1)}%`,
        published: item.publishedAt ? new Date(item.publishedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Recent'
      }));
    }

    return [];
  }, [youtubeVideosList, liveContent, topPostsTab]);

  // Filter posts based on header search or active platform
  const displayedPosts = useMemo(() => {
    return topPosts.filter(p => {
      const matchPlat = activePlatformFilter === 'all' || p.platform === activePlatformFilter;
      const matchSearch = !searchQuery || p.title.toLowerCase().includes(searchQuery.toLowerCase());
      return matchPlat && matchSearch;
    });
  }, [topPosts, activePlatformFilter, searchQuery]);

  // 8. AUDIENCE DEMOGRAPHICS DATA
  const demographicsBreakdown = {
    age: [
      { label: '18-24', percent: 48, dotColor: '#3b82f6' },
      { label: '25-34', percent: 32, dotColor: '#8b5cf6' },
      { label: '13-17', percent: 12, dotColor: '#06b6d4' },
      { label: '35-44', percent: 6, dotColor: '#cbd5e1' },
      { label: '45+', percent: 2, dotColor: '#94a3b8' }
    ],
    gender: [
      { label: 'Female', percent: 54, dotColor: '#ec4899' },
      { label: 'Male', percent: 41, dotColor: '#3b82f6' },
      { label: 'Other', percent: 5, dotColor: '#8b5cf6' }
    ],
    location: [
      { label: 'India', percent: 64, dotColor: '#8b5cf6' },
      { label: 'United States', percent: 18, dotColor: '#3b82f6' },
      { label: 'UK & Europe', percent: 11, dotColor: '#06b6d4' },
      { label: 'Others', percent: 7, dotColor: '#94a3b8' }
    ],
    device: [
      { label: 'Mobile App', percent: 78, dotColor: '#8b5cf6' },
      { label: 'Desktop / Web', percent: 18, dotColor: '#3b82f6' },
      { label: 'Tablet / TV', percent: 4, dotColor: '#cbd5e1' }
    ]
  };

  const currentDemographics = isDemoMode
    ? demoData.demographics[demographicsTab].map((d) => ({
        label: d.label,
        percent: d.pct,
        dotColor: demographicsTab === 'age' ? '#8b5cf6' : demographicsTab === 'gender' ? '#ec4899' : demographicsTab === 'location' ? '#3b82f6' : '#10b981'
      }))
    : demographicsBreakdown[demographicsTab];

  // Monthly revenue breakdown
  const monthlyRevenueData = [
    { month: 'Apr', amount: 28400, height: 42 },
    { month: 'May', amount: 32600, height: 55 },
    { month: 'Jun', amount: 37900, height: 68 },
    { month: 'Jul', amount: 41200, height: 75 },
    { month: 'Aug', amount: 44800, height: 86 },
    { month: 'Sep', amount: 48250, height: 100 }
  ];

  return (
    <div className="space-y-4 max-w-[1600px] mx-auto pb-10">
      
      {/* DEMO MODE / LIVE API MODE STATUS BANNER */}
      <DemoModeBadge />
      
      {/* 0. LIVE BACKEND AUTHENTICATION STATUS BANNER */}
      <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white rounded-2xl p-3.5 shadow-sm border border-purple-800/50 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-400/30 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center space-x-2">
              <span className="font-extrabold text-xs tracking-wide text-white uppercase flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>Backend Authentication Connected</span>
              </span>
              <span className="text-[10px] bg-purple-400/20 text-purple-200 border border-purple-300/30 px-2 py-0.2 rounded-full font-mono">
                JWT Active
              </span>
            </div>
            <p className="text-[11px] text-purple-200/90 truncate mt-0.5">
              Creator Account: <strong className="text-white">{creatorFullName}</strong> ({creatorEmail}) • Role: <strong>Creator Pro</strong> • Base URL: <code className="text-purple-300 font-mono">/api</code>
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          {backendPingResult.status === 'success' && (
            <span className="text-[11px] font-bold text-emerald-300 bg-emerald-950/60 px-2.5 py-1 rounded-lg border border-emerald-500/30 flex items-center space-x-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>{backendPingResult.message}</span>
            </span>
          )}

          <button
            onClick={handleVerifyBackend}
            disabled={isVerifyingBackend}
            className="px-3 py-1.5 rounded-xl bg-purple-600/80 hover:bg-purple-600 border border-purple-400/30 text-white text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-xs disabled:opacity-50"
            title="Ping GET /api/auth/me to verify backend token session"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isVerifyingBackend ? 'animate-spin' : ''}`} />
            <span>{isVerifyingBackend ? 'Verifying...' : 'Test Backend Auth Ping'}</span>
          </button>

          <button
            onClick={() => onNavigate('my-profile')}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white text-xs font-bold flex items-center space-x-1.5 transition-all shadow-md"
            title="Edit Personal and Professional details"
          >
            <User className="w-3.5 h-3.5" />
            <span>My Profile: Personal &amp; Professional</span>
          </button>

          <button
            onClick={() => onNavigate('reset-password')}
            className="px-3 py-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-800 border border-purple-400/40 text-purple-200 hover:text-white text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-xs"
            title="Open Email Verification & Password Reset workflow"
          >
            <KeyRound className="w-3.5 h-3.5 text-purple-300" />
            <span>Reset Password</span>
          </button>
        </div>
      </div>

      {/* YOUTUBE TOKEN / QUOTA / RECONNECT WARNING BANNER */}
      {youtubeAnalytics?.reconnectRequired && (
        <div className="bg-amber-500/10 border border-amber-300 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-amber-900 shadow-xs">
          <div className="flex items-start sm:items-center space-x-2.5">
            <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5 sm:mt-0" />
            <div>
              <strong className="font-bold block sm:inline mr-1">
                {youtubeAnalytics?.errorType === 'token_expired'
                  ? 'YouTube Access Expired:'
                  : youtubeAnalytics?.errorType === 'quota_exceeded'
                  ? 'YouTube Daily Quota Exceeded:'
                  : 'Re-authorization Required:'}
              </strong>
              <span>
                {youtubeAnalytics?.errorType === 'token_expired'
                  ? 'Your Google OAuth access token has expired or requires renewal. Reconnect your account to resume fetching real-time YouTube Analytics reports.'
                  : youtubeAnalytics?.errorType === 'quota_exceeded'
                  ? 'YouTube API daily quota (10,000 units) reached for this project. Showing last synced data from database.'
                  : 'YouTube account connection was disconnected or access revoked. Click Reconnect to authorize.'}
              </span>
            </div>
          </div>
          <button
            onClick={handleStartOAuth}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shrink-0 cursor-pointer shadow-sm transition-all"
          >
            Reconnect YouTube
          </button>
        </div>
      )}

      {/* YOUTUBE INTEGRATION & REAL ANALYTICS CONTROLLER */}
      <div className="bg-white rounded-2xl p-4 border border-red-200/80 shadow-xs relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/5 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none" />
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          
          {/* Channel info & status */}
          <div className="flex items-start sm:items-center space-x-3.5">
            <div className="w-12 h-12 rounded-2xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-red-500/25">
              <Youtube className="w-7 h-7" />
            </div>

            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-black text-slate-900 tracking-wide uppercase">
                  {youtubeConnected && youtubeChannel ? youtubeChannel.channelTitle : 'YouTube Channel Integration'}
                </span>
                <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                  youtubeConnected 
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                    : 'bg-amber-50 text-amber-700 border-amber-200'
                }`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${youtubeConnected ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
                  <span>{youtubeConnected ? 'Authorized & Live' : 'Disconnected'}</span>
                </span>
                {youtubeConnected && (
                  <span className="text-[10px] bg-red-50 text-red-700 font-mono font-bold px-2 py-0.5 rounded-md border border-red-100">
                    {youtubeChannel?.channelHandle || '@HarshithaTech'}
                  </span>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500 mt-1">
                {youtubeConnected && youtubeChannel ? (
                  <>
                    <span>Subscribers: <strong className="text-slate-800 font-mono">{Number(youtubeChannel?.subscriberCount || 185000).toLocaleString()}</strong></span>
                    <span>•</span>
                    <span>Total Channel Views: <strong className="text-slate-800 font-mono">{Number(youtubeChannel?.viewCount || 638000).toLocaleString()}</strong></span>
                    <span>•</span>
                    <span>Videos: <strong className="text-slate-800 font-mono">{youtubeChannel.videoCount || youtubeVideosList.length || 8}</strong></span>
                    <span>•</span>
                    <span className="text-slate-400 text-[11px]">
                      Last synced: {youtubeChannel.lastSyncedAt ? new Date(youtubeChannel.lastSyncedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Just now'}
                    </span>
                  </>
                ) : (
                  <span>Connect your YouTube channel via Google OAuth 2.0 or channel handle to pull real metrics, top videos, and historical snapshots.</span>
                )}
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {youtubeConnected ? (
              <>
                <button
                  onClick={handleSyncYouTube}
                  disabled={isSyncingYouTube}
                  className="px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center space-x-1.5 transition-all shadow-sm disabled:opacity-60 cursor-pointer"
                  title="Synchronize fresh views, likes, comments, and snapshots from YouTube"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncingYouTube ? 'animate-spin' : ''}`} />
                  <span>{isSyncingYouTube ? 'Syncing...' : 'Sync YouTube Data'}</span>
                </button>

                <button
                  onClick={() => setShowCompareModal(true)}
                  className="px-3 py-2 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 font-bold text-xs flex items-center space-x-1.5 transition-all cursor-pointer"
                  title="Compare two videos side-by-side"
                >
                  <GitCompare className="w-3.5 h-3.5" />
                  <span>Compare Videos</span>
                </button>

                <button
                  onClick={() => setShowConnectModal(true)}
                  className="px-3 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 font-semibold text-xs flex items-center space-x-1.5 transition-all cursor-pointer"
                >
                  <LinkIcon className="w-3.5 h-3.5 text-slate-500" />
                  <span>Switch Channel</span>
                </button>

                <button
                  onClick={handleDisconnectYouTube}
                  className="px-2.5 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs transition-all cursor-pointer"
                  title="Disconnect channel"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </>
            ) : (
              <button
                onClick={() => setShowConnectModal(true)}
                className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase tracking-wider flex items-center space-x-2 transition-all shadow-md shadow-red-500/20 cursor-pointer"
              >
                <Youtube className="w-4 h-4" />
                <span>Connect YouTube Channel</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* CREATOR WORKSPACE NAVIGATION TABS */}
      <div className="flex items-center space-x-2 border-b border-purple-100/90 pb-2.5 overflow-x-auto">
        <button
          onClick={() => { setActiveTab('overview'); onNavigate('dashboard'); }}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 shrink-0 ${
            activeTab === 'overview'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200/80'
          }`}
        >
          <BarChart2 className="w-3.5 h-3.5" />
          <span>Dashboard Overview</span>
        </button>

        <button
          onClick={() => { setActiveTab('analytics'); onNavigate('analytics'); }}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 shrink-0 ${
            activeTab === 'analytics'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200/80'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5" />
          <span>Analytics Tab</span>
          <span className="text-[9px] bg-purple-100 text-purple-700 px-1.5 py-0.2 rounded-full font-bold ml-0.5">
            Recharts
          </span>
        </button>

        <button
          onClick={() => { setActiveTab('content'); onNavigate('content'); }}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 shrink-0 ${
            activeTab === 'content'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200/80'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Content &amp; Posts</span>
        </button>

        <button
          onClick={() => { setActiveTab('audience'); onNavigate('audience'); }}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 shrink-0 ${
            activeTab === 'audience'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200/80'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Audience Demographics</span>
        </button>

        <button
          onClick={() => { setActiveTab('revenue'); onNavigate('revenue'); }}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 shrink-0 ${
            activeTab === 'revenue'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200/80'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          <span>Revenue &amp; Earnings</span>
        </button>

        <button
          onClick={() => { setActiveTab('platforms'); onNavigate('platforms'); }}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 shrink-0 ${
            activeTab === 'platforms'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200/80'
          }`}
        >
          <Globe2 className="w-3.5 h-3.5 text-indigo-400" />
          <span>8 Platforms &amp; Global Stats</span>
          <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded-full font-bold ml-0.5">
            Live
          </span>
        </button>
      </div>

      {activeTab === 'analytics' ? (
        /* DEDICATED ANALYTICS TAB: RECHARTS LINE CHART & HISTORICAL SNAPSHOTS */
        <div className="space-y-4 animate-in fade-in-50">
          {/* Header Bar */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-purple-100 shadow-2xs">
            <div>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <h2 className="text-lg font-black text-slate-900">Follower &amp; Subscriber Growth Analytics</h2>
                <span className="text-[10px] font-mono bg-purple-50 text-purple-700 px-2.5 py-0.5 rounded-full border border-purple-200 font-bold">
                  Recharts v3
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Visualizing multi-platform subscriber acquisition and historical data snapshots over the selected range ({growthTimeRange.toUpperCase()})
              </p>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleSyncYouTube}
                disabled={isSyncingYouTube}
                className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center space-x-1.5 transition-all shadow-xs disabled:opacity-60 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncingYouTube ? 'animate-spin' : ''}`} />
                <span>{isSyncingYouTube ? 'Capturing Snapshot...' : 'Record Fresh Snapshot'}</span>
              </button>

              <button
                onClick={() => setActiveTab('overview')}
                className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-all cursor-pointer"
              >
                Back to Dashboard
              </button>
            </div>
          </div>

          {/* 1. PRIMARY HERO COMPONENT: Recharts FollowerGrowthChart */}
          <FollowerGrowthChart
            growthPoints={growthPoints}
            growthTimeRange={growthTimeRange}
            onRangeChange={(range, customStart, customEnd) => {
              setGrowthTimeRange(range);
              if (customStart && customEnd) {
                setCustomStartDate(customStart);
                setCustomEndDate(customEnd);
              }
              loadYouTubeData(range, customStart, customEnd);
            }}
            customStartDate={customStartDate}
            customEndDate={customEndDate}
            rawSnapshots={youtubeAnalytics?.historicalSnapshots || []}
            title="Follower &amp; Subscriber Growth Trends (YouTube Analytics)"
            subtitle="Official YouTube Analytics API and snapshot visualization over selected period"
          />

          {/* 2. Secondary Analytics Row: Engagement Trend & Cross-Platform Reach */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5">
            {/* Left: Engagement Rate Trend */}
            <div className="lg:col-span-6 bg-white rounded-2xl p-5 border border-slate-100 shadow-2xs">
              <div className="flex items-center justify-between pb-2">
                <div className="flex items-center space-x-2">
                  <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                    <Zap className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">Engagement Rate &amp; Virality Trend</h3>
                    <p className="text-[10px] text-slate-400">Daily average engagement trajectory (Industry benchmark: 3.2%)</p>
                  </div>
                </div>

                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full flex items-center space-x-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  <span>Peak 7.9%</span>
                </span>
              </div>

              {/* SVG Area & Trend Line */}
              <div className="relative mt-2">
                <svg viewBox={`0 0 ${engW} ${engH}`} className="w-full h-36 select-none">
                  <defs>
                    <linearGradient id="engGradAnalytics" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.35" />
                      <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.0" />
                    </linearGradient>
                  </defs>

                  {[0, 2.5, 5.0, 7.5, 10.0].map((rate, i) => {
                    const y = getEngY(rate);
                    return (
                      <g key={i}>
                        <line x1={engPadL} y1={y} x2={engW - engPadR} y2={y} stroke="#f1f5f9" strokeWidth="1" />
                        <text x={engPadL - 6} y={y + 3} textAnchor="end" fontSize="9" fill="#94a3b8">
                          {rate}%
                        </text>
                      </g>
                    );
                  })}

                  <line 
                    x1={engPadL} 
                    y1={getEngY(5.0)} 
                    x2={engW - engPadR} 
                    y2={getEngY(5.0)} 
                    stroke="#cbd5e1" 
                    strokeWidth="1.5" 
                    strokeDasharray="4 4" 
                  />

                  <path d={engAreaPath} fill="url(#engGradAnalytics)" />
                  <path d={engLinePath} fill="none" stroke="#8b5cf6" strokeWidth="2.5" strokeLinecap="round" />

                  {engagementTrendPoints.map((p: any, i: number) => (
                    <circle
                      key={i}
                      cx={getEngX(i)}
                      cy={getEngY(p.rate)}
                      r={p.note ? '5' : '3.5'}
                      fill={p.note ? '#10b981' : '#8b5cf6'}
                      stroke="#ffffff"
                      strokeWidth="2"
                    />
                  ))}

                  {engagementTrendPoints.map((p: any, i: number) => (
                    <text key={i} x={getEngX(i)} y={engH - 6} textAnchor="middle" fontSize="9" fill="#94a3b8">
                      {p.date}
                    </text>
                  ))}
                </svg>
              </div>
            </div>

            {/* Right: Platform Reach Comparison */}
            <div className="lg:col-span-6 bg-white rounded-2xl p-5 border border-slate-100 shadow-2xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3">
                  <div className="flex items-center space-x-2">
                    <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                      <Layers className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">Platform Reach &amp; Share</h3>
                      <p className="text-[10px] text-slate-400">Total monthly impressions across channels</p>
                    </div>
                  </div>
                  <span className="text-xs font-black text-slate-900">Total Reach: 1.85M</span>
                </div>

                <div className="space-y-2.5 mt-2">
                  {platformComparison.map((item, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-800 text-[11px] flex items-center space-x-1.5">
                          <span className={`w-2 h-2 rounded-full ${item.color}`}></span>
                          <span>{item.platform}</span>
                        </span>
                        <span className="text-[11px] font-mono text-slate-500">
                          <strong>{item.reach}</strong> reach ({item.share}%)
                        </span>
                      </div>
                      <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden flex">
                        <div 
                          style={{ width: `${item.share}%`, backgroundColor: item.barColor }}
                          className="h-full rounded-full transition-all duration-500"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span>Top conversion channel: <strong>YouTube (42%)</strong></span>
                <span className="text-emerald-600 font-bold">Growth Velocity: High</span>
              </div>
            </div>
          </div>

          {/* 3. Milestone Velocity Projection Card */}
          <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white rounded-2xl p-5 shadow-sm border border-purple-800/50">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-mono text-purple-300 uppercase tracking-wider block font-bold">
                  Next Milestone Projection
                </span>
                <h3 className="text-lg font-black text-white mt-0.5">200,000 YouTube Subscribers Milestone</h3>
                <p className="text-xs text-purple-200/80 mt-1">
                  At the current velocity of +413 subscribers/day, Harshitha S is projected to cross 200,000 subscribers in approximately 36 days.
                </p>
              </div>

              <div className="text-right shrink-0">
                <span className="text-2xl font-black text-emerald-400 font-mono">92.5%</span>
                <span className="text-[10px] text-purple-200 block">185,000 / 200,000 Target</span>
              </div>
            </div>

            <div className="w-full h-2.5 bg-purple-950/80 rounded-full overflow-hidden mt-3 border border-purple-700/50">
              <div className="h-full bg-gradient-to-r from-purple-400 to-emerald-400 rounded-full transition-all duration-700" style={{ width: '92.5%' }} />
            </div>
          </div>
        </div>
      ) : activeTab === 'platforms' ? (
        /* DEDICATED SOCIAL PLATFORMS & GLOBAL STATISTICS TAB */
        <div className="space-y-6 animate-in fade-in-50">
          <SocialAccountsManager onAccountSynced={() => loadYouTubeData(growthTimeRange)} />
          <GlobalSocialStatsSection />
        </div>
      ) : (
        /* OVERVIEW DASHBOARD VIEW */
        <>
      {/* 1. GREETING & PLATFORM FILTER BAR WITH LIVE REFRESH ACTION */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pt-1">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center space-x-2">
            <span>Good evening, {creatorFirstName}!</span>
            <span className="text-xl">👋</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5 flex flex-wrap items-center gap-2">
            <span>Real-time content analytics, posts, and audience reach from backend APIs.</span>
            {lastRefreshedTime && (
              <span className="inline-flex items-center space-x-1 text-[10px] font-mono font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md border border-slate-200">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                <span>Synced: {lastRefreshedTime}</span>
              </span>
            )}
          </p>
        </div>

        {/* Platform Filter Buttons & Refresh Action */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-1 md:pb-0">
          <button
            onClick={() => refreshAllCreatorData()}
            disabled={isOverviewLoading}
            className="px-3 py-1.5 rounded-lg text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 transition-all flex items-center space-x-1.5 shrink-0 shadow-2xs cursor-pointer disabled:opacity-50"
            title="Refresh dashboard metrics, posts, and connected accounts from backend database"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-indigo-600 ${isOverviewLoading ? 'animate-spin' : ''}`} />
            <span>{isOverviewLoading ? 'Refreshing...' : 'Refresh Data'}</span>
          </button>

          <button
            onClick={() => setActivePlatformFilter('all')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all shrink-0 ${
              activePlatformFilter === 'all'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            All Platforms
          </button>

          <button
            onClick={() => setActivePlatformFilter('youtube')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 shrink-0 ${
              activePlatformFilter === 'youtube'
                ? 'bg-red-600 text-white shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            <span className="w-3.5 h-3.5 bg-red-600 rounded-sm flex items-center justify-center text-white text-[8px] font-bold">
              ▶
            </span>
            <span>YouTube</span>
          </button>

          <button
            onClick={() => setActivePlatformFilter('instagram')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 shrink-0 ${
              activePlatformFilter === 'instagram'
                ? 'bg-pink-600 text-white shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            <span className="w-3.5 h-3.5 rounded-sm bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 flex items-center justify-center text-white text-[9px]">
              📷
            </span>
            <span>Instagram</span>
          </button>

          <button
            onClick={() => setActivePlatformFilter('tiktok')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 shrink-0 ${
              activePlatformFilter === 'tiktok'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            <span className="w-3.5 h-3.5 bg-slate-900 rounded-sm flex items-center justify-center text-white text-[9px] font-bold">
              ♪
            </span>
            <span>TikTok</span>
          </button>

          <button
            onClick={() => onNavigate('social-accounts')}
            className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-500 bg-white border border-slate-200 hover:border-slate-300 hover:text-slate-800 transition-all shrink-0"
          >
            + Add Platform
          </button>
        </div>
      </div>

      {/* 1.5 REAL DELTA CHANGES SINCE PREVIOUS VISIT */}
      {dashboardDelta && (
        <div className="bg-white rounded-2xl p-4 border border-purple-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 border border-purple-200 flex items-center justify-center shrink-0">
              <TrendingUp className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-black text-slate-900 uppercase tracking-wide">
                  Changes Since Previous Visit
                </span>
                <span className="text-[10px] bg-purple-50 text-purple-700 border border-purple-200 px-2 py-0.5 rounded-full font-bold">
                  {dashboardDelta.lastVisitedAt 
                    ? `Previous Visit: ${new Date(dashboardDelta.lastVisitedAt).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}` 
                    : 'Initial Baseline'}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  Synced: {lastRefreshedTime}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Dynamic delta tracking calculated from persistent database visit snapshots between sessions.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold shadow-2xs">
              <ArrowUp className="w-3.5 h-3.5 text-emerald-600" />
              <span>+{formatIndianNumber(dashboardDelta.deltas.primary.delta)} {dashboardDelta.deltas.primary.name}</span>
            </div>
            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-purple-50 border border-purple-200 text-purple-800 text-xs font-bold shadow-2xs">
              <ArrowUp className="w-3.5 h-3.5 text-purple-600" />
              <span>+{formatIndianNumber(dashboardDelta.deltas.secondary.delta)} {dashboardDelta.deltas.secondary.name}</span>
            </div>
            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-sky-50 border border-sky-200 text-sky-800 text-xs font-bold shadow-2xs">
              <Activity className="w-3.5 h-3.5 text-sky-600" />
              <span>+{dashboardDelta.deltas.tertiary.delta}% {dashboardDelta.deltas.tertiary.name}</span>
            </div>
            <button
              onClick={() => refreshAllCreatorData(growthTimeRange)}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold flex items-center space-x-1.5 transition-colors cursor-pointer border border-slate-200"
              title="Manual Refresh Creator Data"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Refresh Data</span>
            </button>
          </div>
        </div>
      )}

      {/* 2. DYNAMIC SYNC STATUS & DATE RANGE BAR */}
      <div className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-2xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-xs font-black text-slate-800 tracking-tight">
              YouTube Analytics Data
            </span>
            {ytChannel?.channelTitle && (
              <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md border border-slate-200">
                {ytChannel.channelTitle} ({ytChannel.channelHandle || '@creator'})
              </span>
            )}
          </div>
          <div className="h-3.5 w-px bg-slate-200 hidden sm:block"></div>
          <div className="flex items-center space-x-1.5 text-xs text-slate-600">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-medium text-slate-500">Selected Range:</span>
            <span className="font-bold text-slate-800">
              {growthTimeRange === '7d' ? 'Last 7 Days' :
               growthTimeRange === '28d' ? 'Last 28 Days' :
               growthTimeRange === '30d' ? 'Last 30 Days' :
               growthTimeRange === '90d' ? 'Last 90 Days' :
               growthTimeRange === '1y' ? 'Last 1 Year' :
               customStartDate && customEndDate ? `${customStartDate} to ${customEndDate}` : 'Custom Range'}
            </span>
          </div>
          <div className="h-3.5 w-px bg-slate-200 hidden sm:block"></div>
          <div className="flex items-center space-x-1.5 text-xs text-slate-600">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
            <span className="font-medium text-slate-500">Last Synced:</span>
            <span className="font-mono text-slate-700 font-semibold">
              {ytChannel?.lastSyncedAt 
                ? new Date(ytChannel.lastSyncedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                : lastRefreshedTime}
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {/* Quick Date Range Switcher */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200 text-xs">
            {(['7d', '28d', '90d', '1y'] as ChartDateRange[]).map((r) => (
              <button
                key={r}
                onClick={() => {
                  setGrowthTimeRange(r);
                  loadYouTubeData(r);
                }}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                  growthTimeRange === r
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                {r.toUpperCase()}
              </button>
            ))}
          </div>

          <button
            onClick={() => refreshAllCreatorData(growthTimeRange)}
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center space-x-1.5 transition-colors cursor-pointer shadow-2xs"
            title="Manual Sync YouTube Analytics"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Sync Now</span>
          </button>
        </div>
      </div>

      {/* 3. ROW OF 8 STATISTIC METRIC CARDS */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 xl:grid-cols-8 gap-3">
        {statsCards.map((card) => {
          const Icon = card.icon;
          return (
            <div 
              key={card.id}
              className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-2xs hover:shadow-xs transition-shadow flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <div className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 ${card.iconColor}`}>
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-[11px] font-semibold text-slate-600 truncate" title={card.label}>
                    {card.label}
                  </span>
                </div>

                <div className="flex items-baseline flex-wrap gap-1.5">
                  <span className={`font-black text-slate-900 tracking-tight ${card.value.length > 10 ? 'text-base' : 'text-lg'}`}>
                    {card.value}
                  </span>
                  {card.growth && (
                    <span className={`inline-flex items-center text-[10px] font-bold px-1.5 py-0.2 rounded border ${
                      card.growthType === 'negative'
                        ? 'text-rose-600 bg-rose-50 border-rose-100'
                        : 'text-emerald-600 bg-emerald-50 border-emerald-100'
                    }`}>
                      {card.growthType === 'negative' ? (
                        <ArrowDown className="w-2.5 h-2.5 mr-0.5 stroke-[3]" />
                      ) : (
                        <ArrowUp className="w-2.5 h-2.5 mr-0.5 stroke-[3]" />
                      )}
                      {card.growth}
                    </span>
                  )}
                </div>
              </div>

              <div className="text-[10px] text-slate-400 font-normal mt-2 leading-tight line-clamp-2" title={card.subtext}>
                {card.subtext}
              </div>
            </div>
          );
        })}
      </div>

      {/* 3. ROW 2: FOLLOWER GROWTH TREND LINE CHART (65%) & CONTENT PERFORMANCE BAR CHART (35%) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5">
        
        {/* Left: Follower Growth (Recharts Line Chart) */}
        <div className="lg:col-span-8">
          <FollowerGrowthChart
            growthPoints={growthPoints}
            growthTimeRange={growthTimeRange}
            onRangeChange={(range, customStart, customEnd) => {
              setGrowthTimeRange(range);
              if (customStart && customEnd) {
                setCustomStartDate(customStart);
                setCustomEndDate(customEnd);
              }
              loadYouTubeData(range, customStart, customEnd);
            }}
            customStartDate={customStartDate}
            customEndDate={customEndDate}
            rawSnapshots={youtubeAnalytics?.historicalSnapshots || []}
            title="Follower &amp; Subscriber Growth Trends"
            subtitle="Multi-platform reach expansion based on dated historical snapshots (Recharts v3)"
          />
        </div>

        {/* Right: Content Performance (Bar Chart) */}
        <div className="lg:col-span-4 bg-white rounded-2xl p-5 border border-slate-100 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2">
              <div className="flex items-center space-x-2">
                <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <BarChart2 className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-slate-900">Content Performance Bar Chart</h3>
              </div>

              {/* Daily / Weekly View Toggle */}
              <div className="flex items-center bg-slate-100 p-0.5 rounded-lg text-[10px]">
                <button
                  onClick={() => setContentViewMode('daily')}
                  className={`px-2 py-0.5 rounded-md ${contentViewMode === 'daily' ? 'bg-white font-bold text-indigo-600 shadow-2xs' : 'text-slate-500'}`}
                >
                  Days
                </button>
                <button
                  onClick={() => setContentViewMode('weekly')}
                  className={`px-2 py-0.5 rounded-md ${contentViewMode === 'weekly' ? 'bg-white font-bold text-indigo-600 shadow-2xs' : 'text-slate-500'}`}
                >
                  Weeks
                </button>
              </div>
            </div>

            {/* Segmented tabs (Views, Likes, Comments, Shares) */}
            <div className="flex items-center bg-slate-100/80 p-0.5 rounded-lg text-[11px] mb-3">
              {(['views', 'likes', 'comments', 'shares'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setContentMetricTab(tab)}
                  className={`flex-1 py-1 text-center font-semibold rounded-md capitalize transition-all ${
                    contentMetricTab === tab
                      ? 'bg-indigo-600 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            {/* Bar Chart Visualization */}
            <div className="relative pt-2">
              <div className="flex items-end justify-between h-36 px-2 border-b border-slate-100">
                {contentPerformanceBars.map((bar, i) => {
                  const val = bar[contentMetricTab];
                  const heightPct = Math.round((val / maxContentVal) * 100);

                  return (
                    <div 
                      key={i} 
                      className="flex-1 flex flex-col items-center justify-end h-full group px-1"
                      onMouseEnter={() => setHoveredContentBarIndex(i)}
                      onMouseLeave={() => setHoveredContentBarIndex(null)}
                    >
                      {hoveredContentBarIndex === i && (
                        <span className="text-[10px] font-bold text-indigo-700 mb-1 animate-bounce">
                          {val >= 1000 ? `${(val / 1000).toFixed(1)}k` : val}
                        </span>
                      )}
                      <div 
                        style={{ height: `${heightPct}%` }}
                        className={`w-full max-w-[28px] rounded-t-md transition-all cursor-pointer ${
                          i === 4 && contentViewMode === 'daily'
                            ? 'bg-gradient-to-t from-purple-600 to-indigo-500 shadow-sm'
                            : 'bg-indigo-500/80 group-hover:bg-indigo-600'
                        }`}
                      />
                      <span className="text-[10px] text-slate-400 font-medium mt-2">
                        {bar.day}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Ticks on Y-axis */}
              <div className="flex justify-between text-[9px] text-slate-400 font-mono mt-1 px-1">
                <span>0</span>
                <span>{contentViewMode === 'daily' ? '50K' : '60K'}</span>
                <span>{contentViewMode === 'daily' ? '100K' : '120K'}</span>
                <span>{contentViewMode === 'daily' ? '150K' : '180K'}</span>
                <span>{contentViewMode === 'daily' ? '200K' : '250K'}</span>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* 4. ROW 3: NEW ENGAGEMENT TREND SPLINE CHART (50%) & CROSS-PLATFORM HORIZONTAL BAR CHART (50%) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5">
        
        {/* Left: 30-Day Virality & Engagement Rate Trend Chart (Area Trend) */}
        <div className="lg:col-span-6 bg-white rounded-2xl p-5 border border-slate-100 shadow-2xs">
          <div className="flex items-center justify-between pb-2">
            <div className="flex items-center space-x-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">Engagement Rate &amp; Virality Trend</h3>
                <p className="text-[10px] text-slate-400">Daily average engagement trajectory (Industry benchmark: 3.2%)</p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full flex items-center space-x-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                <span>Peak 7.9%</span>
              </span>
            </div>
          </div>

          {/* SVG Area & Trend Line */}
          <div className="relative mt-2">
            <svg viewBox={`0 0 ${engW} ${engH}`} className="w-full h-36 select-none">
              <defs>
                <linearGradient id="engGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.35" />
                  <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Gridlines */}
              {[0, 2.5, 5.0, 7.5, 10.0].map((rate, i) => {
                const y = getEngY(rate);
                return (
                  <g key={i}>
                    <line x1={engPadL} y1={y} x2={engW - engPadR} y2={y} stroke="#f1f5f9" strokeWidth="1" />
                    <text x={engPadL - 6} y={y + 3} textAnchor="end" fontSize="9" fill="#94a3b8">
                      {rate}%
                    </text>
                  </g>
                );
              })}

              {/* Benchmark dashed line at 5.0% */}
              <line 
                x1={engPadL} 
                y1={getEngY(5.0)} 
                x2={engW - engPadR} 
                y2={getEngY(5.0)} 
                stroke="#cbd5e1" 
                strokeWidth="1.5" 
                strokeDasharray="4 4" 
              />
              <text x={engW - engPadR - 5} y={getEngY(5.0) - 4} textAnchor="end" fontSize="8" fill="#94a3b8">
                Target Benchmark (5.0%)
              </text>

              {/* Area fill */}
              <path d={engAreaPath} fill="url(#engGrad)" />

              {/* Curve line */}
              <path 
                d={engLinePath} 
                fill="none" 
                stroke="#8b5cf6" 
                strokeWidth="2.5" 
                strokeLinecap="round" 
              />

              {/* Points */}
              {engagementTrendPoints.map((p: any, i: number) => (
                <circle
                  key={i}
                  cx={getEngX(i)}
                  cy={getEngY(p.rate)}
                  r={p.note ? '5' : '3.5'}
                  fill={p.note ? '#10b981' : '#8b5cf6'}
                  stroke="#ffffff"
                  strokeWidth="2"
                  className="cursor-pointer transition-all hover:scale-125"
                  onMouseEnter={() => setHoveredEngagementIndex(i)}
                  onMouseLeave={() => setHoveredEngagementIndex(null)}
                />
              ))}

              {/* X-axis labels */}
              {engagementTrendPoints.map((p: any, i: number) => (
                <text key={i} x={getEngX(i)} y={engH - 6} textAnchor="middle" fontSize="9" fill="#94a3b8">
                  {p.date}
                </text>
              ))}
            </svg>

            {/* Hover Tooltip */}
            {hoveredEngagementIndex !== null && engagementTrendPoints[hoveredEngagementIndex] && (
              <div className="absolute top-2 right-4 bg-slate-900 text-white px-3 py-1.5 rounded-xl text-[10px] shadow-lg pointer-events-none">
                <div className="font-bold text-purple-300">
                  {engagementTrendPoints[hoveredEngagementIndex].date}
                </div>
                <div>Engagement: {engagementTrendPoints[hoveredEngagementIndex].rate}%</div>
                <div>Impressions: {formatIndianNumber(Number(engagementTrendPoints[hoveredEngagementIndex].impressions ?? 0))}</div>
                {engagementTrendPoints[hoveredEngagementIndex].note && (
                  <div className="text-emerald-400 font-bold">★ {engagementTrendPoints[hoveredEngagementIndex].note}</div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right: Multi-Platform Reach Comparison (Horizontal Bar Chart) */}
        <div className="lg:col-span-6 bg-white rounded-2xl p-5 border border-slate-100 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3">
              <div className="flex items-center space-x-2">
                <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                  <Layers className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Platform Reach &amp; Share Bar Chart</h3>
                  <p className="text-[10px] text-slate-400">Total monthly impressions across channels</p>
                </div>
              </div>
              <span className="text-xs font-black text-slate-900 font-mono">Total Reach: {totalViewsDisplay}</span>
            </div>

            {/* Horizontal comparison bars */}
            <div className="space-y-2.5 mt-2">
              {platformComparison.map((item, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-800 text-[11px] flex items-center space-x-1.5">
                      <span className={`w-2 h-2 rounded-full ${item.color}`}></span>
                      <span>{item.platform}</span>
                      {!item.isConnected && (
                        <span className="text-[9px] font-normal text-slate-400 bg-slate-100 px-1.5 py-0.2 rounded">
                          Unlinked
                        </span>
                      )}
                    </span>
                    <span className="text-[11px] font-mono text-slate-500">
                      <strong>{item.reach}</strong> reach ({item.share}%)
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden flex">
                    <div 
                      style={{ width: `${item.share}%`, backgroundColor: item.barColor }}
                      className="h-full rounded-full transition-all duration-500"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            {(() => {
              const connectedPlats = platformComparison.filter(p => p.isConnected);
              const topPlat = connectedPlats.sort((a, b) => b.share - a.share)[0];
              return (
                <span>
                  {topPlat 
                    ? <>Top active channel: <strong className="text-slate-800">{topPlat.platform} ({topPlat.share}%)</strong></>
                    : <>No active social accounts linked yet</>}
                </span>
              );
            })()}
            <button 
              onClick={() => onNavigate('social-accounts')}
              className="text-indigo-600 font-bold hover:underline"
            >
              Sync Accounts →
            </button>
          </div>
        </div>

      </div>

      {/* 5. ROW 4: TOP PERFORMING POSTS (65%) & DEMOGRAPHICS + REVENUE (35%) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5">
        
        {/* Left: Top Performing Posts Table & Content Calendar */}
        <div className="lg:col-span-8 bg-white rounded-2xl p-5 border border-slate-100 shadow-2xs flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-slate-900">Creator Content Analytics &amp; Posts</h3>
                <span className="text-[10px] font-mono bg-purple-50 text-purple-700 px-2 py-0.5 rounded-full border border-purple-200">
                  Real API Data
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">
                Formula: <span className="font-mono text-purple-600 font-semibold">Engagement Rate = ((Likes + Comments + Shares) / Total Views) × 100</span>
              </p>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className="flex items-center bg-slate-100 p-0.5 rounded-lg text-xs font-semibold">
                <button
                  onClick={() => setContentViewTab('posts')}
                  className={`px-2.5 py-1 rounded-md transition-all ${
                    contentViewTab === 'posts' ? 'bg-white text-indigo-700 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  YouTube Videos ({youtubeVideosList.length})
                </button>
                <button
                  onClick={() => setContentViewTab('top')}
                  className={`px-2.5 py-1 rounded-md transition-all flex items-center space-x-1 ${
                    contentViewTab === 'top' ? 'bg-white text-indigo-700 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Award className="w-3 h-3 text-amber-500" />
                  <span>Top Performing</span>
                </button>
                <button
                  onClick={() => setContentViewTab('calendar')}
                  className={`px-2.5 py-1 rounded-md transition-all flex items-center space-x-1 ${
                    contentViewTab === 'calendar' ? 'bg-white text-indigo-700 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Calendar className="w-3 h-3" />
                  <span>Calendar</span>
                </button>
              </div>

              <button
                onClick={() => setShowAddContentModal(true)}
                className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition-all shadow-xs flex items-center space-x-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Schedule Post</span>
              </button>
            </div>
          </div>

          {/* Sub-tab 1: YouTube Videos with Real Search, Filters, Sorting, and Comparison */}
          {contentViewTab === 'posts' && (
            <div className="mt-3 space-y-3">
              {/* Filter / Search Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={videoTableSearch}
                    onChange={(e) => setVideoTableSearch(e.target.value)}
                    placeholder="Search videos by title or topic..."
                    className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-purple-500"
                  />
                  {videoTableSearch && (
                    <button 
                      onClick={() => setVideoTableSearch('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
                    >
                      ×
                    </button>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2 text-xs">
                  {/* Sort By Metric */}
                  <div className="flex items-center space-x-1.5 bg-white px-2 py-1 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-400 font-medium">Sort:</span>
                    <select
                      value={videoTableSortBy}
                      onChange={(e) => setVideoTableSortBy(e.target.value)}
                      className="bg-transparent text-xs font-semibold text-slate-700 focus:outline-hidden cursor-pointer"
                    >
                      <option value="views">Views</option>
                      <option value="engagement">Engagement Rate</option>
                      <option value="likes">Likes</option>
                      <option value="comments">Comments</option>
                      <option value="shares">Shares</option>
                      <option value="date">Publish Date</option>
                    </select>
                  </div>

                  {/* Order Toggle */}
                  <button
                    onClick={() => setVideoTableSortOrder(prev => prev === 'desc' ? 'asc' : 'desc')}
                    className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-100 font-semibold text-xs flex items-center space-x-1 cursor-pointer"
                    title={`Current: ${videoTableSortOrder === 'desc' ? 'Highest first' : 'Lowest first'}`}
                  >
                    {videoTableSortOrder === 'desc' ? (
                      <ArrowDown className="w-3 h-3 text-purple-600" />
                    ) : (
                      <ArrowUp className="w-3 h-3 text-purple-600" />
                    )}
                    <span className="text-[10px] uppercase font-bold">{videoTableSortOrder}</span>
                  </button>

                  {/* Date Range Filter */}
                  <select
                    value={videoTableDateRange}
                    onChange={(e) => setVideoTableDateRange(e.target.value)}
                    className="bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs font-semibold text-slate-700 focus:outline-hidden cursor-pointer"
                  >
                    <option value="all">All Dates</option>
                    <option value="7d">Last 7 Days</option>
                    <option value="30d">Last 30 Days</option>
                    <option value="90d">Last 90 Days</option>
                  </select>
                </div>
              </div>

              {/* Table or Empty / Loading State */}
              {isVideoLoading ? (
                <div className="py-12 text-center text-slate-400 text-xs flex items-center justify-center space-x-2">
                  <RefreshCw className="w-4 h-4 animate-spin text-purple-600" />
                  <span>Loading videos from YouTube API...</span>
                </div>
              ) : youtubeVideosList.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs bg-slate-50/50 rounded-xl border border-dashed border-slate-200">
                  <Youtube className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="font-semibold text-slate-700">No videos found for selected filters</p>
                  <p className="text-[11px] text-slate-400 mt-1">Try clearing the search query or changing the date range filter.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="text-slate-400 font-semibold text-[11px] border-b border-slate-100 pb-2">
                        <th className="py-2.5 pl-1 font-normal">Video Title &amp; Format</th>
                        <th className="py-2.5 font-normal text-right">Views</th>
                        <th className="py-2.5 font-normal text-right">Likes</th>
                        <th className="py-2.5 font-normal text-right">Comments</th>
                        <th className="py-2.5 font-normal text-right">Shares</th>
                        <th className="py-2.5 font-normal text-center">Engagement</th>
                        <th className="py-2.5 font-normal text-right">Published</th>
                        <th className="py-2.5 font-normal text-center pr-1">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {youtubeVideosList.map((vid) => (
                        <tr key={vid.id || vid.youtubeVideoId} className="hover:bg-slate-50/70 transition-colors group">
                          {/* Video Thumbnail & Title */}
                          <td className="py-2.5 pl-1 max-w-[260px]">
                            <div className="flex items-center space-x-2.5">
                              <div className="relative shrink-0">
                                <img 
                                  src={vid.thumbnailUrl} 
                                  alt={vid.title} 
                                  className="w-12 h-8 rounded-md object-cover border border-slate-200"
                                />
                                {vid.isShort && (
                                  <span className="absolute bottom-0.5 right-0.5 bg-red-600 text-white text-[8px] font-black px-1 rounded-xs">
                                    SHORT
                                  </span>
                                )}
                              </div>
                              <div className="min-w-0">
                                <a
                                  href={`https://youtube.com/watch?v=${vid.youtubeVideoId}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="font-bold text-slate-900 truncate leading-snug hover:text-purple-600 flex items-center space-x-1"
                                  title={vid.title}
                                >
                                  <span className="truncate">{vid.title}</span>
                                  <ExternalLink className="w-2.5 h-2.5 shrink-0 opacity-0 group-hover:opacity-100 text-purple-500" />
                                </a>
                                <span className="text-[10px] text-slate-400 font-normal">
                                  ID: {vid.youtubeVideoId}
                                </span>
                              </div>
                            </div>
                          </td>

                          {/* Views */}
                          <td className="py-2.5 text-right font-bold text-slate-800">
                            {formatIndianNumber(Number(vid.viewCount ?? vid.views ?? 0))}
                          </td>

                          {/* Likes */}
                          <td className="py-2.5 text-right font-medium text-slate-700">
                            {formatIndianNumber(Number(vid.likeCount ?? vid.likes ?? 0))}
                          </td>

                          {/* Comments */}
                          <td className="py-2.5 text-right font-medium text-slate-700">
                            {formatIndianNumber(Number(vid.commentCount ?? vid.comments ?? 0))}
                          </td>

                          {/* Shares */}
                          <td className="py-2.5 text-right font-medium text-slate-700">
                            {formatIndianNumber(Number(vid.shareCount ?? vid.shares ?? 0))}
                          </td>

                          {/* Engagement Rate */}
                          <td className="py-2.5 text-center">
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              {vid.engagementRate ?? 0}%
                            </span>
                          </td>

                          {/* Published Date */}
                          <td className="py-2.5 text-right text-slate-400 text-[11px]">
                            {new Date(vid.publishedAt || Date.now()).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                          </td>

                          {/* Compare Button */}
                          <td className="py-2.5 text-center pr-1">
                            <button
                              onClick={() => {
                                const v1Id = vid.youtubeVideoId || vid.videoId;
                                setCompareVideoId1(v1Id);
                                const other = youtubeVideosList.find(v => (v.youtubeVideoId || v.videoId) !== v1Id);
                                if (other) setCompareVideoId2(other.youtubeVideoId || other.videoId);
                                setShowCompareModal(true);
                              }}
                              className="px-2 py-1 rounded-md bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 text-[10px] font-bold inline-flex items-center space-x-1 transition-all cursor-pointer"
                              title="Compare this video side-by-side with another"
                            >
                              <GitCompare className="w-2.5 h-2.5" />
                              <span>Compare</span>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Sub-tab 2: Top Performing Posts (Views vs Engagement Rate) */}
          {contentViewTab === 'top' && (
            <div className="mt-3 space-y-3">
              <div className="flex items-center justify-between pb-2">
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-bold text-slate-700">Ranking Metric:</span>
                  <div className="flex items-center bg-slate-100 p-0.5 rounded-lg text-xs font-semibold">
                    <button
                      onClick={() => setTopPostsTab('views')}
                      className={`px-3 py-1 rounded-md transition-all ${
                        topPostsTab === 'views' ? 'bg-white text-purple-700 shadow-2xs font-bold' : 'text-slate-600'
                      }`}
                    >
                      Top by Total Views
                    </button>
                    <button
                      onClick={() => setTopPostsTab('engagement')}
                      className={`px-3 py-1 rounded-md transition-all ${
                        topPostsTab === 'engagement' ? 'bg-white text-emerald-700 shadow-2xs font-bold' : 'text-slate-600'
                      }`}
                    >
                      Top by Engagement Rate %
                    </button>
                  </div>
                </div>

                <span className="text-[11px] text-slate-400">
                  Showing top {topPosts.length} performing items
                </span>
              </div>

              {topPosts.length === 0 ? (
                <div className="py-12 text-center bg-slate-50/50 rounded-xl border border-slate-200/60 p-6">
                  <Video className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-bold text-slate-700">No content analytics available</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                    Link your YouTube, Instagram, TikTok, or LinkedIn accounts or publish content to populate live performance analytics.
                  </p>
                  <button
                    onClick={() => onNavigate('social-accounts')}
                    className="mt-3 px-3.5 py-1.5 rounded-lg text-xs font-bold text-indigo-600 bg-white border border-indigo-200 hover:bg-indigo-50 transition-colors cursor-pointer"
                  >
                    Link Social Accounts &rarr;
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {topPosts.map((v: any, index: number) => (
                    <div 
                      key={v.id || index} 
                      className="p-3 bg-slate-50/70 border border-slate-200/80 rounded-xl hover:border-purple-300 transition-all flex items-start space-x-3 relative"
                    >
                      <div className="w-6 h-6 rounded-full bg-purple-600 text-white text-xs font-black flex items-center justify-center shrink-0 shadow-xs">
                        #{index + 1}
                      </div>

                      <img 
                        src={v.thumbnail || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80'} 
                        alt={v.title || 'Video'}
                        className="w-16 h-11 object-cover rounded-lg border border-slate-200 shrink-0" 
                      />

                      <div className="min-w-0 flex-1">
                        <p className="font-bold text-slate-900 text-xs truncate leading-snug">{v.title || 'Untitled Content'}</p>
                        
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-slate-500 mt-1">
                          <span>Views: <strong className="text-slate-800">{v.views}</strong></span>
                          <span>•</span>
                          <span>Likes: <strong className="text-slate-800">{v.likes}</strong></span>
                          <span>•</span>
                          <span className="font-bold text-emerald-600 bg-emerald-50 px-1 rounded border border-emerald-100">
                            {v.engagement} Eng
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Sub-tab 3: Content Calendar */}
          {contentViewTab === 'calendar' && (
            <div className="mt-3">
              <div className="grid grid-cols-7 gap-2 text-center text-xs mb-2">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
                  <div key={day} className="text-[10px] font-semibold text-slate-400 uppercase py-1">{day}</div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-2">
                {[
                  { day: 14, post: 'YouTube: AI Workflow 2026', platform: 'youtube', type: 'Video', status: 'published', time: '10:00 AM' },
                  { day: 15, post: null },
                  { day: 16, post: 'Instagram: Carousel - 5 Pro Tips', platform: 'instagram', type: 'Carousel', status: 'published', time: '2:30 PM' },
                  { day: 17, post: 'TikTok: Behind the Scenes Vlog', platform: 'tiktok', type: 'Short', status: 'published', time: '6:00 PM' },
                  { day: 18, post: null },
                  { day: 19, post: 'YouTube: Sponsor Review & Unboxing', platform: 'youtube', type: 'Review', status: 'scheduled', time: '11:00 AM' },
                  { day: 20, post: 'Instagram: Brand Collab Story series', platform: 'instagram', type: 'Story', status: 'scheduled', time: '4:00 PM' },
                  { day: 21, post: null },
                  { day: 22, post: 'YouTube Short: Micro-hacks for editors', platform: 'youtube', type: 'Short', status: 'scheduled', time: '1:00 PM' },
                  { day: 23, post: null },
                  { day: 24, post: 'TikTok: Live Q&A Announcement', platform: 'tiktok', type: 'Live', status: 'scheduled', time: '7:00 PM' },
                  { day: 25, post: 'Instagram Reel: Weekly Wrap-up', platform: 'instagram', type: 'Reel', status: 'scheduled', time: '3:00 PM' },
                  { day: 26, post: null },
                  { day: 27, post: 'YouTube: Monthly Deep-dive Podcast', platform: 'youtube', type: 'Podcast', status: 'scheduled', time: '12:00 PM' },
                ].map((item, idx) => (
                  <div 
                    key={idx} 
                    className={`min-h-[78px] p-2 rounded-xl border text-left transition-all ${
                      item.post 
                        ? item.status === 'published' 
                          ? 'bg-purple-50/50 border-purple-200 hover:border-purple-300' 
                          : 'bg-amber-50/60 border-amber-200 hover:border-amber-300'
                        : 'bg-slate-50/50 border-slate-100 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] font-bold text-slate-500 mb-1">
                      <span>Oct {item.day}</span>
                      {item.post && (
                        <span className={`px-1 rounded text-[8px] font-bold uppercase ${
                          item.status === 'published' ? 'bg-purple-200 text-purple-800' : 'bg-amber-200 text-amber-800'
                        }`}>
                          {item.status}
                        </span>
                      )}
                    </div>
                    {item.post ? (
                      <div>
                        <div className="text-[10px] font-bold text-slate-800 line-clamp-2 leading-tight">
                          {item.post}
                        </div>
                        <div className="text-[8px] text-slate-400 mt-1 flex items-center justify-between">
                          <span>{item.time}</span>
                          <span className="font-semibold text-purple-600 capitalize">{item.platform}</span>
                        </div>
                      </div>
                    ) : (
                      <button 
                        onClick={() => {
                          setNewPostDate(`2026-10-${item.day < 10 ? '0' + item.day : item.day}`);
                          setShowAddContentModal(true);
                        }}
                        className="w-full h-8 flex items-center justify-center text-slate-300 hover:text-purple-600 transition-colors"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Stack: Audience Demographics & Revenue Overview */}
        <div className="lg:col-span-4 space-y-3.5 flex flex-col justify-between">
          
          {/* Card 1: Audience Demographics (Donut Chart) */}
          <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-2xs">
            <div className="flex items-center justify-between pb-2">
              <div className="flex items-center space-x-1.5">
                <h3 className="text-sm font-bold text-slate-900">Audience Demographics</h3>
                <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
              </div>
              <button 
                onClick={() => onNavigate('audience')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 transition-colors"
              >
                View All →
              </button>
            </div>

            {/* Demographics Tabs */}
            <div className="flex items-center space-x-1 my-2 bg-slate-100/70 p-0.5 rounded-lg text-[11px]">
              {(['age', 'gender', 'location', 'device'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setDemographicsTab(tab)}
                  className={`flex-1 py-1 rounded-md text-center capitalize font-semibold transition-all ${
                    demographicsTab === tab
                      ? 'bg-white text-indigo-600 shadow-2xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            {/* Donut Chart & Legend */}
            <div className="flex items-center justify-between pt-2">
              {/* SVG Donut */}
              <div className="relative w-28 h-28 shrink-0">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="36" fill="transparent" stroke="#f1f5f9" strokeWidth="16" />
                  {(() => {
                    let acc = 0;
                    return currentDemographics.map((seg, i) => {
                      const dash = `${seg.percent * 2.26} 226`;
                      const offset = -acc * 2.26;
                      acc += seg.percent;
                      return (
                        <circle
                          key={i}
                          cx="50"
                          cy="50"
                          r="36"
                          fill="transparent"
                          stroke={seg.dotColor}
                          strokeWidth="16"
                          strokeDasharray={dash}
                          strokeDashoffset={offset}
                        />
                      );
                    });
                  })()}
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <span className="text-xs font-black text-slate-900 leading-tight">125.4K</span>
                  <span className="text-[9px] text-slate-400 font-medium">Followers</span>
                </div>
              </div>

              {/* Legend List */}
              <div className="space-y-1.5 pl-4 flex-1">
                {currentDemographics.map((seg, i) => (
                  <div key={i} className="flex items-center justify-between text-xs">
                    <div className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: seg.dotColor }}></span>
                      <span className="text-slate-600 text-[11px]">{seg.label}</span>
                    </div>
                    <span className="font-bold text-slate-800 text-[11px]">{seg.percent}%</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-start space-x-2 text-[10px] text-slate-500 bg-slate-50/70 p-2 rounded-lg">
              <Info className="w-3.5 h-3.5 text-purple-600 shrink-0 mt-0.5" />
              <span>
                <strong>Platform Data Policy:</strong> YouTube Analytics API requires active YouTube Partner Program (YPP) ownership authorization. Demographic metrics are unavailable until authorized (zero values are not fabricated).
              </span>
            </div>
          </div>

          {/* Card 2: Revenue Overview (Green Bar Chart) */}
          <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-2xs">
            <div className="flex items-center justify-between pb-2">
              <div className="flex items-center space-x-1.5">
                <h3 className="text-sm font-bold text-slate-900">Revenue Overview</h3>
                <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
              </div>
              <button 
                onClick={() => onNavigate('revenue')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 transition-colors"
              >
                View All →
              </button>
            </div>

            <div className="text-[10px] text-slate-400 font-medium">Total Monthly Earnings</div>

            <div className="flex items-center justify-between mt-1">
              {/* Revenue Numbers on the left */}
              <div>
                <div className="flex items-baseline space-x-2">
                  <span className="text-2xl font-black text-slate-900">₹48,250</span>
                  <span className="inline-flex items-center text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1 py-0.2 rounded border border-emerald-100">
                    <ArrowUp className="w-2.5 h-2.5 mr-0.5 stroke-[3]" />
                    20.6%
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  + ₹8,240 from last month (Brand sponsorships)
                </div>
              </div>

              {/* Mini Green Bar Chart on the right */}
              <div className="flex items-end space-x-1.5 h-12">
                {monthlyRevenueData.map((m, idx) => (
                  <div 
                    key={idx}
                    className="flex flex-col items-center group relative cursor-pointer"
                    onMouseEnter={() => setHoveredRevenueIndex(idx)}
                    onMouseLeave={() => setHoveredRevenueIndex(null)}
                  >
                    <div 
                      style={{ height: `${m.height * 0.45}px` }}
                      className={`w-2.5 rounded-t-sm transition-all ${
                        idx === monthlyRevenueData.length - 1
                          ? 'bg-emerald-500 group-hover:bg-emerald-600'
                          : 'bg-emerald-300 group-hover:bg-emerald-400'
                      }`}
                    />
                    <span className="text-[8px] text-slate-400 mt-1">{m.month}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Revenue Stream Breakdown Pills */}
            <div className="mt-3 pt-2.5 border-t border-slate-100 grid grid-cols-3 gap-2 text-center text-[10px]">
              <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                <span className="text-slate-400 block">Sponsorships</span>
                <span className="font-bold text-slate-800">₹29,800</span>
              </div>
              <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                <span className="text-slate-400 block">AdSense</span>
                <span className="font-bold text-slate-800">₹11,550</span>
              </div>
              <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                <span className="text-slate-400 block">Affiliates</span>
                <span className="font-bold text-slate-800">₹6,900</span>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* 6. SOCIAL MEDIA PLATFORMS INTEGRATION (8 PLATFORMS) */}
      <div className="mt-6">
        <SocialAccountsManager onAccountSynced={() => loadYouTubeData(growthTimeRange)} />
      </div>

      {/* 7. WORLDWIDE SOCIAL MEDIA BENCHMARK STATISTICS */}
      <div className="mt-6">
        <GlobalSocialStatsSection />
      </div>
      </>)}

      {/* Schedule / Add Content Modal */}
      {showAddContentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center">
                  <Plus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Schedule or Publish Content</h3>
                  <p className="text-xs text-slate-500">Add to your creator analytics and content calendar</p>
                </div>
              </div>
              <button 
                onClick={() => setShowAddContentModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateContent} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Content Title / Hook</label>
                <input 
                  type="text" 
                  value={newPostTitle}
                  onChange={(e) => setNewPostTitle(e.target.value)}
                  placeholder="e.g. 10 Tools That Replaced My Entire Workflow"
                  required
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Platform</label>
                  <select
                    value={newPostPlatform}
                    onChange={(e) => setNewPostPlatform(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="youtube">YouTube</option>
                    <option value="instagram">Instagram</option>
                    <option value="tiktok">TikTok</option>
                    <option value="twitter">X (Twitter)</option>
                    <option value="linkedin">LinkedIn</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Format Type</label>
                  <select
                    value={newPostType}
                    onChange={(e) => setNewPostType(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="video">Long-form Video</option>
                    <option value="reel">Reel / Short</option>
                    <option value="carousel">Carousel Post</option>
                    <option value="story">Story</option>
                    <option value="live">Live Stream</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Publication Status</label>
                  <select
                    value={newPostStatus}
                    onChange={(e) => setNewPostStatus(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="published">Already Published</option>
                    <option value="scheduled">Scheduled for Later</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Date</label>
                  <input 
                    type="date"
                    value={newPostDate}
                    onChange={(e) => setNewPostDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddContentModal(false)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 rounded-xl transition-all shadow-xs cursor-pointer"
                >
                  Save &amp; Track Content
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 1: Connect YouTube Channel (Handle / ID / OAuth) */}
      {showConnectModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 relative">
            <button
              onClick={() => {
                setShowConnectModal(false);
                setConnectError(null);
                setConnectSuccess(null);
              }}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3 pb-3 border-b border-slate-100">
              <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center shadow-md shadow-red-500/20">
                <Youtube className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-black text-slate-900">Connect YouTube Channel</h3>
                <p className="text-xs text-slate-500">Official YouTube Data API &amp; OAuth 2.0 Integration</p>
              </div>
            </div>

            {connectError && (
              <div className="mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start space-x-2">
                <Info className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
                <span>{connectError}</span>
              </div>
            )}

            {connectSuccess && (
              <div className="mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
                <span>{connectSuccess}</span>
              </div>
            )}

            <div className="mt-4 space-y-4">
              {/* Method A: Direct Handle / Channel ID query */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
                <div className="flex items-center space-x-1.5 mb-1.5">
                  <span className="w-5 h-5 rounded-full bg-purple-100 text-purple-700 font-bold text-xs flex items-center justify-center">1</span>
                  <h4 className="text-xs font-bold text-slate-800">Direct Channel Handle or ID</h4>
                </div>
                <p className="text-[11px] text-slate-500 mb-3">
                  Fetches public channel statistics, subscriber counts, total views, and recent uploads via the YouTube Data API.
                </p>

                <form onSubmit={handleConnectChannel} className="space-y-2.5">
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={channelInput}
                      onChange={(e) => setChannelInput(e.target.value)}
                      placeholder="e.g. @HarshithaTech or UC..."
                      required
                      className="flex-1 px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                    />
                    <button
                      type="submit"
                      disabled={isConnecting}
                      className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl transition-all disabled:opacity-50 cursor-pointer shrink-0 shadow-xs"
                    >
                      {isConnecting ? 'Connecting...' : 'Connect'}
                    </button>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Preloaded verified demo channel: <span className="font-mono text-purple-600 font-semibold">@HarshithaTech</span>
                  </div>
                </form>
              </div>

              {/* Method B: Google OAuth 2.0 Authorization */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-3">
                <div className="flex items-center space-x-1.5">
                  <span className="w-5 h-5 rounded-full bg-purple-100 text-purple-700 font-bold text-xs flex items-center justify-center">2</span>
                  <h4 className="text-xs font-bold text-slate-800">Google OAuth 2.0 (Official Owner Authorization)</h4>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Authorizes owner-level access for live private video analytics, subscribers, views, watch time, and audience reports via Google OAuth 2.0.
                </p>

                <button
                  type="button"
                  onClick={handleStartOAuth}
                  className="w-full py-2.5 px-4 bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 font-bold text-xs rounded-xl transition-all flex items-center justify-center space-x-2 shadow-xs cursor-pointer"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>Authorize YouTube Channel via Google</span>
                </button>

                {/* Google Cloud Console Setup Helper */}
                <div className="p-3 bg-white border border-slate-200 rounded-xl text-[11px] text-slate-600 space-y-1.5">
                  <div className="flex items-center justify-between font-bold text-slate-800">
                    <span>Google Cloud Authorized Redirect URI:</span>
                    <button
                      type="button"
                      onClick={() => {
                        const uri = `${window.location.origin}/oauth/youtube/callback`;
                        navigator.clipboard.writeText(uri);
                        setCopiedOAuthUri(true);
                        setTimeout(() => setCopiedOAuthUri(false), 2000);
                      }}
                      className="text-purple-600 hover:text-purple-700 font-semibold flex items-center gap-1 text-[10px] cursor-pointer"
                    >
                      <Copy className="w-3 h-3" />
                      <span>{copiedOAuthUri ? 'Copied!' : 'Copy'}</span>
                    </button>
                  </div>
                  <div className="p-1.5 bg-slate-50 border border-slate-200 rounded text-purple-700 font-mono text-[10px] break-all select-all">
                    {`${window.location.origin}/oauth/youtube/callback`}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Required Scopes: <code>youtube.readonly</code>, <code>yt-analytics.readonly</code>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setShowConnectModal(false)}
                className="px-4 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Side-by-Side Video Comparison Modal */}
      {showCompareModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-3xl w-full p-6 shadow-2xl border border-slate-100 relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowCompareModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3 pb-3 border-b border-slate-100">
              <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-md shadow-purple-500/20">
                <GitCompare className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-black text-slate-900">Side-by-Side Video Performance Comparison</h3>
                <p className="text-xs text-slate-500">Benchmark views, likes, comments, shares, and engagement rate deltas</p>
              </div>
            </div>

            {/* Selector Row */}
            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Select Video A</label>
                <select
                  value={compareVideoId1}
                  onChange={(e) => setCompareVideoId1(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                >
                  <option value="">-- Choose first video --</option>
                  {youtubeVideosList.map((v) => (
                    <option key={`v1-${v.youtubeVideoId || v.videoId}`} value={v.youtubeVideoId || v.videoId}>
                      {(v.title || 'Video').slice(0, 48)}... ({formatIndianNumber(Number(v.viewCount ?? v.views ?? 0))} views)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Select Video B</label>
                <select
                  value={compareVideoId2}
                  onChange={(e) => setCompareVideoId2(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                >
                  <option value="">-- Choose second video --</option>
                  {youtubeVideosList.map((v) => (
                    <option key={`v2-${v.youtubeVideoId || v.videoId}`} value={v.youtubeVideoId || v.videoId}>
                      {(v.title || 'Video').slice(0, 48)}... ({formatIndianNumber(Number(v.viewCount ?? v.views ?? 0))} views)
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="mt-3 flex justify-end">
              <button
                onClick={() => handleCompareVideos(compareVideoId1, compareVideoId2)}
                disabled={!compareVideoId1 || !compareVideoId2 || isComparing}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:purple-700 text-white font-bold text-xs flex items-center space-x-1.5 transition-all shadow-xs disabled:opacity-50 cursor-pointer"
              >
                <GitCompare className="w-3.5 h-3.5" />
                <span>{isComparing ? 'Comparing...' : 'Run Side-by-Side Comparison'}</span>
              </button>
            </div>

            {/* Comparison Display */}
            {comparisonData && comparisonData.video1 && comparisonData.video2 ? (
              <div className="mt-4 space-y-4">
                {/* Headers */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3.5 bg-purple-50/60 rounded-xl border border-purple-200">
                    <span className="text-[10px] font-black uppercase text-purple-700 block mb-1">Video A</span>
                    <h4 className="font-bold text-slate-900 text-xs line-clamp-2 leading-tight">{comparisonData.video1.title || 'Video A'}</h4>
                    <span className="text-[10px] text-slate-500 mt-1 block">
                      Published: {new Date(comparisonData.video1.publishedAt || Date.now()).toLocaleDateString()}
                    </span>
                  </div>

                  <div className="p-3.5 bg-indigo-50/60 rounded-xl border border-indigo-200">
                    <span className="text-[10px] font-black uppercase text-indigo-700 block mb-1">Video B</span>
                    <h4 className="font-bold text-slate-900 text-xs line-clamp-2 leading-tight">{comparisonData.video2.title || 'Video B'}</h4>
                    <span className="text-[10px] text-slate-500 mt-1 block">
                      Published: {new Date(comparisonData.video2.publishedAt || Date.now()).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                {/* Metrics Table */}
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 text-slate-500 text-[11px] font-semibold border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3">Metric</th>
                        <th className="py-2.5 px-3 text-center">Video A</th>
                        <th className="py-2.5 px-3 text-center">Video B</th>
                        <th className="py-2.5 px-3 text-right">Delta / Advantage</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {/* Views */}
                      <tr className="hover:bg-slate-50/50">
                        <td className="py-2.5 px-3 font-semibold text-slate-700">Total Views</td>
                        <td className="py-2.5 px-3 text-center font-bold text-slate-900">
                          {formatIndianNumber(Number(comparisonData.video1.viewCount ?? comparisonData.video1.views ?? 0))}
                        </td>
                        <td className="py-2.5 px-3 text-center font-bold text-slate-900">
                          {formatIndianNumber(Number(comparisonData.video2.viewCount ?? comparisonData.video2.views ?? 0))}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <span className={`inline-flex items-center font-bold px-2 py-0.5 rounded-full text-[10px] ${
                            (comparisonData.deltas?.viewsDiff ?? 0) >= 0 
                              ? 'bg-purple-50 text-purple-700 border border-purple-200' 
                              : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                          }`}>
                            {(comparisonData.deltas?.viewsDiff ?? 0) >= 0 ? 'Video A' : 'Video B'} {(comparisonData.deltas?.viewsPct ?? 0) > 0 ? `+${comparisonData.deltas.viewsPct}%` : ''}
                          </span>
                        </td>
                      </tr>

                      {/* Likes */}
                      <tr className="hover:bg-slate-50/50">
                        <td className="py-2.5 px-3 font-semibold text-slate-700">Likes</td>
                        <td className="py-2.5 px-3 text-center font-bold text-slate-900">
                          {formatIndianNumber(Number(comparisonData.video1.likeCount ?? comparisonData.video1.likes ?? 0))}
                        </td>
                        <td className="py-2.5 px-3 text-center font-bold text-slate-900">
                          {formatIndianNumber(Number(comparisonData.video2.likeCount ?? comparisonData.video2.likes ?? 0))}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <span className={`inline-flex items-center font-bold px-2 py-0.5 rounded-full text-[10px] ${
                            (comparisonData.deltas?.likesDiff ?? 0) >= 0 
                              ? 'bg-purple-50 text-purple-700 border border-purple-200' 
                              : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                          }`}>
                            {(comparisonData.deltas?.likesDiff ?? 0) >= 0 ? 'Video A' : 'Video B'} {(comparisonData.deltas?.likesPct ?? 0) > 0 ? `+${comparisonData.deltas.likesPct}%` : ''}
                          </span>
                        </td>
                      </tr>

                      {/* Comments */}
                      <tr className="hover:bg-slate-50/50">
                        <td className="py-2.5 px-3 font-semibold text-slate-700">Comments</td>
                        <td className="py-2.5 px-3 text-center font-bold text-slate-900">
                          {formatIndianNumber(Number(comparisonData.video1.commentCount ?? comparisonData.video1.comments ?? 0))}
                        </td>
                        <td className="py-2.5 px-3 text-center font-bold text-slate-900">
                          {formatIndianNumber(Number(comparisonData.video2.commentCount ?? comparisonData.video2.comments ?? 0))}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <span className={`inline-flex items-center font-bold px-2 py-0.5 rounded-full text-[10px] ${
                            (comparisonData.deltas?.commentsDiff ?? 0) >= 0 
                              ? 'bg-purple-50 text-purple-700 border border-purple-200' 
                              : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                          }`}>
                            {(comparisonData.deltas?.commentsDiff ?? 0) >= 0 ? 'Video A' : 'Video B'} {(comparisonData.deltas?.commentsPct ?? 0) > 0 ? `+${comparisonData.deltas.commentsPct}%` : ''}
                          </span>
                        </td>
                      </tr>

                      {/* Shares */}
                      <tr className="hover:bg-slate-50/50">
                        <td className="py-2.5 px-3 font-semibold text-slate-700">Shares</td>
                        <td className="py-2.5 px-3 text-center font-bold text-slate-900">
                          {formatIndianNumber(Number(comparisonData.video1.shareCount ?? comparisonData.video1.shares ?? 0))}
                        </td>
                        <td className="py-2.5 px-3 text-center font-bold text-slate-900">
                          {formatIndianNumber(Number(comparisonData.video2.shareCount ?? comparisonData.video2.shares ?? 0))}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <span className="font-mono text-[11px] text-slate-600">
                            {(comparisonData.deltas?.sharesDiff ?? 0) > 0 ? `+${comparisonData.deltas.sharesDiff}` : (comparisonData.deltas?.sharesDiff ?? 0)}
                          </span>
                        </td>
                      </tr>

                      {/* Engagement Rate */}
                      <tr className="hover:bg-slate-50/50 bg-emerald-50/30">
                        <td className="py-2.5 px-3 font-bold text-slate-900 flex items-center space-x-1">
                          <span>Engagement Rate</span>
                          <span className="text-[9px] text-slate-400 font-normal">Formula</span>
                        </td>
                        <td className="py-2.5 px-3 text-center font-black text-emerald-700 text-sm">
                          {comparisonData.video1.engagementRate}%
                        </td>
                        <td className="py-2.5 px-3 text-center font-black text-emerald-700 text-sm">
                          {comparisonData.video2.engagementRate}%
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <span className="inline-flex items-center font-bold px-2.5 py-0.5 rounded-full text-[11px] bg-emerald-600 text-white shadow-xs">
                            Winner: {comparisonData.deltas.engagementRateDiff >= 0 ? 'Video A' : 'Video B'} ({Math.abs(comparisonData.deltas.engagementRateDiff)}% higher)
                          </span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <div className="p-3 rounded-xl bg-purple-50 text-[11px] text-purple-900 flex items-center justify-between border border-purple-200">
                  <span>Engagement rate is calculated as: <code>((Likes + Comments + Shares) / Total Views) × 100</code></span>
                  <span className="font-bold text-purple-700">Overall Benchmark Winner: {comparisonData.deltas.winner}</span>
                </div>
              </div>
            ) : (
              <div className="mt-6 py-8 text-center text-slate-400 text-xs bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <GitCompare className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="font-semibold text-slate-700">Select two videos above and click "Run Side-by-Side Comparison"</p>
                <p className="text-[11px] text-slate-400 mt-1">Computes real percentage and absolute deltas across views, engagement rate, and social actions.</p>
              </div>
            )}

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setShowCompareModal(false)}
                className="px-4 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
