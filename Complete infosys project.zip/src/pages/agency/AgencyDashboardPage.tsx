import React, { useState, useEffect } from 'react';
import { 
  Building, 
  Users, 
  Eye, 
  TrendingUp, 
  Calendar, 
  IndianRupee, 
  Youtube, 
  Instagram, 
  Video, 
  Linkedin, 
  ExternalLink, 
  CheckCircle2, 
  Clock, 
  Plus, 
  ArrowUpRight, 
  Search, 
  ChevronDown, 
  HelpCircle,
  Briefcase,
  Layers,
  Sparkles,
  UserCheck,
  RefreshCw,
  Filter,
  ShieldCheck,
  Target,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useDemoMode, DemoModeBadge } from '../../context/DemoModeContext';
import { getAgencyDemoData } from '../../data/demoData';
import { agencyService, dashboardService } from '../../services/api';
import { AgencyDashboardData, AgencyCreatorCard, Campaign, DashboardDeltaRecord } from '../../types/auth';
import { formatIndianNumber, formatIndianCurrency, formatIndianDate } from '../../utils/formatters';

interface AgencyDashboardPageProps {
  onNavigate: (page: string) => void;
}

export const AgencyDashboardPage: React.FC<AgencyDashboardPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const { isDemoMode } = useDemoMode();
  const [selectedDateRange, setSelectedDateRange] = useState('30d');
  const demoData = React.useMemo(() => getAgencyDemoData(selectedDateRange), [selectedDateRange]);
  const [selectedPlatform, setSelectedPlatform] = useState('all');
  const [selectedCreatorId, setSelectedCreatorId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastSyncTime, setLastSyncTime] = useState<string>(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
  const [dashboardData, setDashboardData] = useState<AgencyDashboardData | null>(null);
  const [dashboardDelta, setDashboardDelta] = useState<DashboardDeltaRecord | null>(null);

  const fetchAgencyData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await agencyService.getDashboard({
        range: selectedDateRange,
        platform: selectedPlatform !== 'all' ? selectedPlatform : undefined,
        creatorId: selectedCreatorId !== 'all' ? selectedCreatorId : undefined
      });
      if (res.success && res.data) {
        setDashboardData(res.data);
        setLastSyncTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));

        // Record visit and calculate real changes since previous visit
        try {
          const deltaRes = await dashboardService.recordVisitAndSync({
            role: 'agency',
            currentMetrics: {
              primaryValue: res.data.summary.totalViews || 0,
              primaryName: 'Views',
              secondaryValue: res.data.summary.totalFollowers || 0,
              secondaryName: 'Followers',
              tertiaryValue: res.data.summary.activeCampaigns || 0,
              tertiaryName: 'Active Campaigns'
            }
          });
          if (deltaRes && deltaRes.success) {
            setDashboardDelta(deltaRes);
          }
        } catch (dErr) {
          console.warn('[Agency Dashboard] Delta sync note:', dErr);
        }
      } else {
        setError('Failed to load agency portfolio data.');
      }
    } catch (err: any) {
      console.warn('[Agency Dashboard API]', { status: err.status, message: err.message });
      setError(err.message || 'Error connecting to agency service.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAgencyData();
    const interval = setInterval(() => {
      fetchAgencyData();
    }, 60000);
    return () => clearInterval(interval);
  }, [selectedDateRange, selectedPlatform, selectedCreatorId]);

  const summary = isDemoMode
    ? demoData.summary
    : (dashboardData?.summary || {
        totalCreators: 0,
        totalFollowers: 0,
        totalViews: 0,
        activeCampaigns: 0,
        totalRevenue: 0,
        growthPct: 0
      });

  const creators = isDemoMode
    ? demoData.creators.map(c => ({
        id: c.id,
        name: c.name,
        handle: c.handle.replace('@', ''),
        avatarUrl: c.avatarUrl,
        niche: c.niche,
        connectedPlatforms: c.platform === 'multi' ? ['youtube', 'instagram'] : [c.platform],
        totalFollowers: c.followers,
        totalViews: c.views,
        avgEngagementRate: c.engagementRate,
        campaignCount: c.activeDeals,
        collaborationStatus: c.status === 'active' ? 'open' : 'review',
        revenue: c.revenue
      }))
    : (dashboardData?.creators || []);

  const campaigns = isDemoMode
    ? demoData.campaigns.map(c => ({
        id: c.id,
        brand: c.brand,
        title: c.title,
        budget: c.budget,
        deliverables: `${c.creatorsCount} Creators · Dedicated Integrations`,
        startDate: '2026-10-01',
        endDate: c.deadline,
        status: c.status,
        progressPct: c.progressPct
      }))
    : (dashboardData?.campaigns || []);

  const performanceTrend = isDemoMode
    ? [
        { date: 'Oct 01', views: Math.round(demoData.summary.totalViews * 0.12), followers: 1390000 },
        { date: 'Oct 08', views: Math.round(demoData.summary.totalViews * 0.22), followers: 1415000 },
        { date: 'Oct 15', views: Math.round(demoData.summary.totalViews * 0.40), followers: 1438000 },
        { date: 'Oct 22', views: Math.round(demoData.summary.totalViews * 0.65), followers: 1455000 },
        { date: 'Oct 29', views: Math.round(demoData.summary.totalViews * 0.85), followers: 1472000 },
        { date: 'Nov 05', views: demoData.summary.totalViews, followers: 1482000 }
      ]
    : (dashboardData?.performanceTrend || []);

  const pendingTasks = isDemoMode ? demoData.pendingTasks : [];
  const recentActivity = isDemoMode ? demoData.recentActivity : [];
  const platformDistribution = isDemoMode ? demoData.platformDistribution : [
    { name: 'YouTube', pct: 42, color: '#ef4444' },
    { name: 'Instagram', pct: 28, color: '#ec4899' },
    { name: 'TikTok', pct: 18, color: '#06b6d4' },
    { name: 'LinkedIn', pct: 8, color: '#0284c7' },
    { name: 'X / Twitter', pct: 4, color: '#64748b' }
  ];

  const filteredCreators = creators.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.handle.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.niche.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // SVG Line Chart coordinates
  const chartW = 560;
  const chartH = 180;
  const padLeft = 45;
  const padRight = 20;
  const padTop = 15;
  const padBottom = 25;
  const innerW = chartW - padLeft - padRight;
  const innerH = chartH - padTop - padBottom;
  const maxViews = Math.max(...performanceTrend.map(d => d.views), 2000000);

  const getX = (idx: number) => {
    if (performanceTrend.length <= 1) return padLeft + innerW / 2;
    return padLeft + (idx / (performanceTrend.length - 1)) * innerW;
  };
  const getY = (val: number) => padTop + innerH - (val / (maxViews || 1)) * innerH;

  const viewsPath = performanceTrend.reduce((acc, curr, idx) => {
    const x = getX(idx);
    const y = getY(curr.views);
    return idx === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
  }, '');

  const followersPath = performanceTrend.reduce((acc, curr, idx) => {
    const x = getX(idx);
    // Scale followers to chart height
    const y = padTop + innerH - (curr.followers / (performanceTrend[performanceTrend.length - 1]?.followers || 1)) * (innerH * 0.8);
    return idx === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
  }, '');

  return (
    <div className="space-y-5 max-w-[1500px] mx-auto pb-10">
      {/* Dashboard Identifier Title with RBAC notice */}
      <div className="py-2.5 px-4 bg-indigo-50/80 border border-indigo-200/70 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm font-black text-indigo-950 tracking-tight">Agency Representation Dashboard</h1>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-600 text-white flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" /> Assigned Creators Only
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-white/80 border border-indigo-200 text-indigo-800">
              Last synced: {lastSyncTime}
            </span>
          </div>
          <p className="text-[11px] text-indigo-700 mt-0.5">
            Strictly isolated to creator rosters legally assigned to your agency account ({user?.name || 'Talent Agency'}).
          </p>
        </div>

        <button
          onClick={fetchAgencyData}
          disabled={isLoading}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-white hover:bg-slate-50 text-indigo-700 border border-indigo-200 rounded-xl transition-all shadow-2xs self-start sm:self-auto cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh Live Roster</span>
        </button>
      </div>

      {/* Demo Mode Notification Badge */}
      <DemoModeBadge />

      {isLoading && !dashboardData && (
        <div className="py-12 flex flex-col items-center justify-center space-y-3 bg-white rounded-2xl border border-slate-200/80 shadow-2xs">
          <div className="w-8 h-8 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs font-semibold text-slate-500">Loading agency creator roster and performance analytics...</p>
        </div>
      )}

      {/* Changes Since Previous Visit Banner */}
      {dashboardDelta && (
        <div className="bg-white rounded-2xl p-4 border border-indigo-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 border border-indigo-200 flex items-center justify-center shrink-0">
              <TrendingUp className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-black text-indigo-950 uppercase tracking-wide">
                  Changes Since Previous Visit
                </span>
                <span className="text-[10px] bg-indigo-50 text-indigo-700 border border-indigo-200 px-2 py-0.5 rounded-full font-bold">
                  {dashboardDelta.lastVisitedAt 
                    ? `Previous Visit: ${new Date(dashboardDelta.lastVisitedAt).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}` 
                    : 'Initial Baseline'}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  Synced: {lastSyncTime}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Real roster and campaign changes tracked dynamically from backend database snapshots.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold shadow-2xs">
              <ArrowUpRight className="w-3.5 h-3.5 text-emerald-600" />
              <span>+{formatIndianNumber(dashboardDelta.deltas.primary.delta)} {dashboardDelta.deltas.primary.name}</span>
            </div>
            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-purple-50 border border-purple-200 text-purple-800 text-xs font-bold shadow-2xs">
              <ArrowUpRight className="w-3.5 h-3.5 text-purple-600" />
              <span>+{formatIndianNumber(dashboardDelta.deltas.secondary.delta)} {dashboardDelta.deltas.secondary.name}</span>
            </div>
            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-sky-50 border border-sky-200 text-sky-800 text-xs font-bold shadow-2xs">
              <Target className="w-3.5 h-3.5 text-sky-600" />
              <span>+{dashboardDelta.deltas.tertiary.delta} {dashboardDelta.deltas.tertiary.name}</span>
            </div>
          </div>
        </div>
      )}

      {/* Top Controls: Search, Date Filter, Platform Filter, Creator Filter */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute inset-y-0 left-3 my-auto pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search assigned creators, niches, handles..."
            className="w-full pl-9 pr-3.5 py-2 rounded-xl border border-slate-200 text-xs text-slate-900 bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-2xs"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {/* Creator Selector Filter */}
          <div className="flex items-center bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs font-medium text-slate-700 shadow-2xs">
            <span className="text-[11px] text-slate-400 mr-1.5">Creator:</span>
            <select
              value={selectedCreatorId}
              onChange={(e) => setSelectedCreatorId(e.target.value)}
              className="bg-transparent font-semibold text-slate-800 focus:outline-none cursor-pointer"
            >
              <option value="all">All Assigned ({creators.length})</option>
              {creators.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          {/* Platform Selector Filter */}
          <div className="flex items-center bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs font-medium text-slate-700 shadow-2xs">
            <span className="text-[11px] text-slate-400 mr-1.5">Platform:</span>
            <select
              value={selectedPlatform}
              onChange={(e) => setSelectedPlatform(e.target.value)}
              className="bg-transparent font-semibold text-slate-800 focus:outline-none cursor-pointer"
            >
              <option value="all">All Channels</option>
              <option value="youtube">YouTube</option>
              <option value="instagram">Instagram</option>
              <option value="tiktok">TikTok</option>
              <option value="linkedin">LinkedIn</option>
            </select>
          </div>

          {/* Date Range Selector */}
          <div className="flex items-center bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs font-medium text-slate-700 shadow-2xs">
            <Calendar className="w-3.5 h-3.5 text-slate-400 mr-1.5" />
            <select
              value={selectedDateRange}
              onChange={(e) => setSelectedDateRange(e.target.value)}
              className="bg-transparent font-semibold text-slate-800 focus:outline-none cursor-pointer"
            >
              <option value="7d">Last 7 Days</option>
              <option value="30d">Last 30 Days</option>
              <option value="90d">Last 90 Days</option>
              <option value="1y">Past 1 Year</option>
            </select>
          </div>

          <button
            onClick={() => onNavigate('my-profile')}
            className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all shadow-xs flex items-center space-x-1.5"
            title="Edit Agency details"
          >
            <Building className="w-3.5 h-3.5" />
            <span>Agency Profile</span>
          </button>
        </div>
      </div>

      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
            <span>{error}</span>
          </div>
          <button onClick={fetchAgencyData} className="font-bold underline cursor-pointer ml-3">Retry</button>
        </div>
      )}

      {/* 5 KPI Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold text-slate-600">Assigned Creators</span>
            <div className="p-1.5 rounded-lg text-indigo-600 bg-indigo-50">
              <Users className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900 tracking-tight">
              {summary.totalCreators}
            </div>
            <div className="mt-1">
              <span className="inline-flex items-center text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                100% Authorized
              </span>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold text-slate-600">Total Followers</span>
            <div className="p-1.5 rounded-lg text-blue-600 bg-blue-50">
              <Users className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900 tracking-tight">
              {formatIndianNumber(summary.totalFollowers, { compact: true })}
            </div>
            <div className="mt-1">
              <span className="inline-flex items-center text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                ↑ +{summary.growthPct}%
              </span>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold text-slate-600">Total Views</span>
            <div className="p-1.5 rounded-lg text-sky-600 bg-sky-50">
              <Eye className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900 tracking-tight">
              {formatIndianNumber(summary.totalViews, { compact: true })}
            </div>
            <div className="mt-1">
              <span className="inline-flex items-center text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                Real Channel Data
              </span>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold text-slate-600">Active Campaigns</span>
            <div className="p-1.5 rounded-lg text-indigo-600 bg-indigo-50">
              <Briefcase className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900 tracking-tight">
              {summary.activeCampaigns}
            </div>
            <div className="mt-1 flex items-center gap-1 text-[10px] text-slate-400">
              <span>{campaigns.length} Total Registered</span>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold text-slate-600">Revenue & Earnings</span>
            <div className="p-1.5 rounded-lg text-amber-600 bg-amber-50">
              <IndianRupee className="w-3.5 h-3.5" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900 tracking-tight">
              {formatIndianCurrency(summary.totalRevenue)}
            </div>
            <div className="mt-1 flex items-center gap-1.5 text-[10px]">
              <span className="font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded-md">
                Agency Cut: {formatIndianCurrency((summary as any).agencyCommission || Math.round(summary.totalRevenue * 0.2))} (20%)
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Middle Grid: Overall Performance & Platform Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Performance Trends */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Portfolio Performance Trend</h2>
              <p className="text-[11px] text-slate-400">Aggregated views and follower expansion across assigned creators</p>
            </div>
            <div className="flex items-center space-x-3 text-[11px]">
              <span className="flex items-center space-x-1 text-slate-600 font-semibold">
                <span className="w-2.5 h-2.5 rounded-full bg-pink-500"></span>
                <span>Views</span>
              </span>
              <span className="flex items-center space-x-1 text-slate-600 font-semibold">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                <span>Followers</span>
              </span>
            </div>
          </div>

          <div className="w-full overflow-x-auto">
            <svg viewBox={`0 0 ${chartW} ${chartH}`} className="w-full h-48 select-none">
              {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
                const y = padTop + innerH - ratio * innerH;
                const label = formatIndianNumber(Math.round(maxViews * ratio), { compact: true });
                return (
                  <g key={ratio}>
                    <line x1={padLeft} y1={y} x2={chartW - padRight} y2={y} stroke="#f1f5f9" strokeDasharray="3 3" />
                    <text x={padLeft - 8} y={y + 3} textAnchor="end" fontSize="9" fill="#94a3b8" fontFamily="sans-serif">
                      {label}
                    </text>
                  </g>
                );
              })}

              <path d={viewsPath} fill="none" stroke="#ec4899" strokeWidth="2.5" strokeLinecap="round" />
              <path d={followersPath} fill="none" stroke="#f43f5e" strokeWidth="2.5" strokeLinecap="round" />

              {performanceTrend.map((d, i) => {
                const x = getX(i);
                return (
                  <g key={d.date}>
                    <text x={x} y={chartH - 6} textAnchor="middle" fontSize="9" fill="#94a3b8" fontFamily="sans-serif">
                      {d.date}
                    </text>
                    <circle cx={x} cy={getY(d.views)} r="3.5" fill="#ec4899" stroke="#ffffff" strokeWidth="1.5" />
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Platform Share of Assigned Portfolio */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900 mb-1">Roster Channel Distribution</h2>
            <p className="text-[11px] text-slate-400">Connected network footprint by platform</p>
          </div>

          <div className="space-y-3 my-4">
            {[
              { platform: 'YouTube', color: 'bg-red-500', share: 45 },
              { platform: 'Instagram', color: 'bg-pink-500', share: 30 },
              { platform: 'TikTok', color: 'bg-slate-900', share: 15 },
              { platform: 'LinkedIn & Others', color: 'bg-blue-600', share: 10 }
            ].map(item => (
              <div key={item.platform} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${item.color}`} />
                    <span>{item.platform}</span>
                  </span>
                  <span className="font-bold text-slate-900">{item.share}%</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className={`h-full ${item.color}`} style={{ width: `${item.share}%` }} />
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-indigo-50/60 rounded-xl border border-indigo-100 text-[11px] text-indigo-900">
            <strong>Cross-Channel Synergy:</strong> Creators linked with both YouTube and Instagram generate 42% higher brand deal engagements.
          </div>
        </div>
      </div>

      {/* Creators Overview Table */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-2">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Represented Creators Overview</h2>
            <p className="text-[11px] text-slate-400">Performance and collaboration metrics for talents assigned to your agency</p>
          </div>
          <span className="text-xs font-semibold text-slate-500">
            {filteredCreators.length} of {creators.length} Creators Listed
          </span>
        </div>

        {filteredCreators.length === 0 ? (
          <div className="py-12 text-center text-slate-400 text-xs">
            No assigned creators match your search or filter.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  <th className="pb-3 pl-2">Creator</th>
                  <th className="pb-3">Niche</th>
                  <th className="pb-3">Connected Channels</th>
                  <th className="pb-3">Followers</th>
                  <th className="pb-3">Total Views</th>
                  <th className="pb-3">Avg Eng.</th>
                  <th className="pb-3">Campaigns</th>
                  <th className="pb-3 pr-2 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 font-medium text-slate-700">
                {filteredCreators.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 pl-2 flex items-center space-x-3">
                      <img 
                        src={c.avatarUrl} 
                        alt={c.name} 
                        className="w-8 h-8 rounded-full object-cover border border-slate-200" 
                      />
                      <div>
                        <div className="font-bold text-slate-900">{c.name}</div>
                        <div className="text-[10px] text-slate-400 font-mono">@{c.handle}</div>
                      </div>
                    </td>
                    <td className="py-3.5">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-semibold text-[10px]">
                        {c.niche}
                      </span>
                    </td>
                    <td className="py-3.5">
                      <div className="flex items-center space-x-1.5">
                        {c.connectedPlatforms.map((p, idx) => (
                          <span 
                            key={idx} 
                            className="px-1.5 py-0.5 rounded bg-slate-100 text-[10px] font-bold uppercase"
                          >
                            {p === 'youtube' ? 'YT' : p === 'instagram' ? 'IG' : p === 'tiktok' ? 'TT' : p === 'linkedin' ? 'IN' : p}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="py-3.5 font-bold text-slate-900 font-mono">
                      {formatIndianNumber(c.totalFollowers)}
                    </td>
                    <td className="py-3.5 text-slate-600 font-mono">
                      {formatIndianNumber(c.totalViews)}
                    </td>
                    <td className="py-3.5 font-semibold text-emerald-600 font-mono">
                      {c.avgEngagementRate}%
                    </td>
                    <td className="py-3.5 font-bold text-slate-800">
                      {c.campaignCount} active
                    </td>
                    <td className="py-3.5 pr-2 text-right">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        c.collaborationStatus === 'open' 
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                          : 'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}>
                        {c.collaborationStatus.toUpperCase()}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Campaigns Managed By Agency Table */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Active Brand Campaigns & Progress</h2>
            <p className="text-[11px] text-slate-400">Deliverables and contractual fulfillment for represented talents</p>
          </div>
          <span className="text-xs font-semibold text-slate-500">
            {campaigns.length} Active Campaigns
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {campaigns.map((camp: any) => (
            <div key={camp.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <h3 className="text-xs font-bold text-slate-900">{camp.title}</h3>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    camp.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'
                  }`}>
                    {camp.status.toUpperCase()}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 mb-2">Brand: <strong className="text-slate-700">{camp.brand}</strong></p>
                <div className="text-[11px] text-slate-600 bg-white p-2.5 rounded-lg border border-slate-200 mb-2.5">
                  <strong>Deliverables:</strong> {camp.deliverables}
                </div>

                {/* Campaign Progress Bar */}
                <div className="space-y-1 mb-2">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-slate-600">Campaign Fulfillment</span>
                    <span className="font-bold text-indigo-700">{camp.progressPct || 65}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-200/80 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-indigo-500 to-indigo-600 rounded-full transition-all duration-500" 
                      style={{ width: `${camp.progressPct || 65}%` }} 
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs pt-2.5 border-t border-slate-200 text-slate-500">
                <span>Budget: <strong className="text-slate-900">{formatIndianCurrency(camp.budget)}</strong></span>
                <span>Deadline: <span className="font-mono text-slate-700">{camp.endDate || (camp as any).deadline}</span></span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Agency Operations: Recent Creator Activity & Pending Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recent Creator Activity */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Recent Creator Activity</h2>
              <p className="text-[11px] text-slate-400">Live operational events and content milestones across your roster</p>
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
              Live Feed
            </span>
          </div>

          <div className="space-y-3">
            {(recentActivity.length > 0 ? recentActivity : [
              { id: 'act-1', creator: 'Ipsita Priyadarshini', action: 'Uploaded new YouTube integration: "AI SaaS Architecture"', time: '18m ago', type: 'upload' },
              { id: 'act-2', creator: 'Harshitha Tech', action: 'Signed Q4 sponsorship contract with Vercel', time: '1h ago', type: 'contract' },
              { id: 'act-3', creator: 'Alex Rivera Tech', action: 'Reached 500,000 views milestone on Shorts campaign', time: '3h ago', type: 'milestone' },
              { id: 'act-4', creator: 'Samir Creative', action: 'Submitted draft Reel for Notion brand review', time: '5h ago', type: 'deal' },
              { id: 'act-5', creator: 'Maya Studio', action: 'Accepted agency commission terms for Winter 2026', time: '1d ago', type: 'contract' }
            ]).map((act: any) => (
              <div key={act.id} className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-50/80 transition-colors border border-transparent hover:border-slate-100">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 text-xs font-bold ${
                  act.type === 'contract' ? 'bg-purple-100 text-purple-700' :
                  act.type === 'upload' ? 'bg-rose-100 text-rose-700' :
                  act.type === 'milestone' ? 'bg-amber-100 text-amber-700' :
                  'bg-sky-100 text-sky-700'
                }`}>
                  {act.type === 'contract' ? <ShieldCheck className="w-4 h-4" /> :
                   act.type === 'upload' ? <Video className="w-4 h-4" /> :
                   act.type === 'milestone' ? <Sparkles className="w-4 h-4" /> :
                   <Briefcase className="w-4 h-4" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900 truncate">{act.creator}</span>
                    <span className="text-[10px] text-slate-400 font-mono shrink-0">{act.time}</span>
                  </div>
                  <p className="text-[11px] text-slate-600 truncate mt-0.5">{act.action}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pending Tasks & Approvals */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Pending Agency Tasks</h2>
              <p className="text-[11px] text-slate-400">Action items requiring agency review, approval or settlement</p>
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
              {(pendingTasks.length || 4)} Pending
            </span>
          </div>

          <div className="space-y-3">
            {(pendingTasks.length > 0 ? pendingTasks : [
              { id: 'task-1', task: 'Review Figma x Harshitha sponsorship deliverable', assignee: 'Talent Manager', priority: 'high', dueDate: 'Today, 5:00 PM' },
              { id: 'task-2', task: 'Approve ₹3,50,000 payout milestone for Ipsita Priyadarshini', assignee: 'Finance Desk', priority: 'high', dueDate: 'Tomorrow' },
              { id: 'task-3', task: 'Counter-sign Supabase brand agreement addendum', assignee: 'Legal Counsel', priority: 'medium', dueDate: 'Nov 12, 2026' },
              { id: 'task-4', task: 'Schedule Q1 2027 creator planning call with Samir', assignee: 'Agent Partner', priority: 'low', dueDate: 'Nov 15, 2026' }
            ]).map((t: any) => (
              <div key={t.id} className="p-3 rounded-xl border border-slate-200/90 bg-white hover:border-slate-300 transition-all shadow-2xs flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-2 h-8 rounded-full shrink-0 ${
                    t.priority === 'high' ? 'bg-rose-500' : t.priority === 'medium' ? 'bg-amber-500' : 'bg-slate-400'
                  }`} />
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-900 truncate">{t.task}</p>
                    <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                      <span>Assignee: <strong className="text-slate-600">{t.assignee}</strong></span>
                      <span>·</span>
                      <span>Due: <strong className="text-slate-600">{t.dueDate}</strong></span>
                    </div>
                  </div>
                </div>

                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase shrink-0 ${
                  t.priority === 'high' ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                  t.priority === 'medium' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                  'bg-slate-100 text-slate-700 border border-slate-200'
                }`}>
                  {t.priority}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
