/**
 * Indian Number System and Currency Formatter Utilities
 * Standards: en-IN, INR (₹), Asia/Kolkata
 */

/**
 * Format a number using Indian Numbering system (1,25,000; 12,50,000; 1,25,00,000)
 * or compact units (K, L, Cr)
 * Examples:
 * - 125000 -> "1,25,000" (full) or "1.25L" (compact)
 * - 12500000 -> "1,25,00,000" (full) or "1.25Cr" (compact)
 */
export function formatIndianNumber(val: number, compactOpt: boolean | { compact?: boolean } = false, maxDecimals = 2): string {
  if (isNaN(val) || val === null || val === undefined) return '0';
  const compact = typeof compactOpt === 'boolean' ? compactOpt : Boolean(compactOpt?.compact);
  
  if (!compact) {
    return new Intl.NumberFormat('en-IN', {
      maximumFractionDigits: maxDecimals,
    }).format(val);
  }

  const abs = Math.abs(val);
  const sign = val < 0 ? '-' : '';

  if (abs >= 10000000) {
    // Crores (1 Crore = 10 Million = 100 Lakhs)
    const cr = abs / 10000000;
    const formatted = cr >= 100 ? cr.toFixed(1) : cr.toFixed(maxDecimals);
    return `${sign}${parseFloat(formatted)}Cr`;
  } else if (abs >= 100000) {
    // Lakhs (1 Lakh = 100 Thousand)
    const lk = abs / 100000;
    const formatted = lk >= 100 ? lk.toFixed(1) : lk.toFixed(maxDecimals);
    return `${sign}${parseFloat(formatted)}L`;
  } else if (abs >= 1000) {
    // Thousands
    const k = abs / 1000;
    const formatted = k >= 100 ? k.toFixed(1) : k.toFixed(maxDecimals);
    return `${sign}${parseFloat(formatted)}K`;
  }

  return `${sign}${new Intl.NumberFormat('en-IN', { maximumFractionDigits: maxDecimals }).format(abs)}`;
}

/**
 * Format currency in Indian Rupees (₹)
 * Examples:
 * - 25000 -> "₹25,000"
 * - 125000 -> "₹1,25,000"
 * - 1250000 -> "₹12,50,000"
 * - 12500000 -> "₹1,25,00,000" (full) or "₹1.25Cr" (compact)
 */
export function formatIndianCurrency(val: number, compactOpt: boolean | { compact?: boolean } = false, maxDecimals = 2): string {
  if (isNaN(val) || val === null || val === undefined) return '₹0';
  const compact = typeof compactOpt === 'boolean' ? compactOpt : Boolean(compactOpt?.compact);

  if (!compact) {
    const formattedNum = new Intl.NumberFormat('en-IN', {
      maximumFractionDigits: val % 1 === 0 ? 0 : maxDecimals,
    }).format(Math.abs(val));
    return `${val < 0 ? '-' : ''}₹${formattedNum}`;
  }

  const abs = Math.abs(val);
  const sign = val < 0 ? '-' : '';

  if (abs >= 10000000) {
    const cr = abs / 10000000;
    const formatted = cr >= 100 ? cr.toFixed(1) : cr.toFixed(maxDecimals);
    return `${sign}₹${parseFloat(formatted)}Cr`;
  } else if (abs >= 100000) {
    const lk = abs / 100000;
    const formatted = lk >= 100 ? lk.toFixed(1) : lk.toFixed(maxDecimals);
    return `${sign}₹${parseFloat(formatted)}L`;
  } else if (abs >= 1000) {
    const k = abs / 1000;
    const formatted = k >= 100 ? k.toFixed(1) : k.toFixed(maxDecimals);
    return `${sign}₹${parseFloat(formatted)}K`;
  }

  return `${sign}₹${new Intl.NumberFormat('en-IN', { maximumFractionDigits: maxDecimals }).format(abs)}`;
}

/**
 * Format date in Asia/Kolkata timezone with en-IN formatting
 * Example: "10 Nov 2026, 06:15 PM"
 */
export function formatIndianDate(dateInput: string | Date | number, includeTime = true): string {
  if (!dateInput) return '';
  const date = typeof dateInput === 'string' || typeof dateInput === 'number' ? new Date(dateInput) : dateInput;
  if (isNaN(date.getTime())) return String(dateInput);

  try {
    return new Intl.DateTimeFormat('en-IN', {
      timeZone: 'Asia/Kolkata',
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      ...(includeTime
        ? {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true,
          }
        : {}),
    }).format(date);
  } catch (_e) {
    return date.toLocaleDateString('en-IN');
  }
}

/**
 * Format percentage with positive/negative indicators
 */
export function formatPercentage(val: number, includeSign = true): string {
  if (isNaN(val) || val === null || val === undefined) return '0%';
  const prefix = includeSign && val > 0 ? '+' : '';
  return `${prefix}${val.toFixed(val % 1 === 0 ? 0 : 1)}%`;
}
