// Demo Data Store for CreatorIQ
// High-fidelity, realistic demonstration data formatted for professional SaaS presentations.

export interface CreatorDemoData {
  summary: {
    totalFollowers: number;
    followersGrowthPct: number;
    totalViews: number;
    viewsGrowthPct: number;
    totalLikes: number;
    totalComments: number;
    totalShares: number;
    engagementRate: number;
    engagementGrowthPct: number;
    estimatedRevenue: number;
    impressions: number;
  };
  growthTrend: Array<{
    date: string;
    followers: number;
    views: number;
    engagement: number;
  }>;
  engagementTrend: Array<{
    date: string;
    likes: number;
    comments: number;
    shares: number;
    views: number;
  }>;
  platforms: {
    youtube: {
      name: string;
      handle: string;
      followers: number;
      views: number;
      postsCount: number;
      engagementRate: number;
      growthPct: number;
      avgDuration: string;
      status: 'demo_active';
    };
    instagram: {
      name: string;
      handle: string;
      followers: number;
      views: number;
      postsCount: number;
      engagementRate: number;
      growthPct: number;
      status: 'demo_active';
    };
    tiktok: {
      name: string;
      handle: string;
      followers: number;
      views: number;
      postsCount: number;
      engagementRate: number;
      growthPct: number;
      status: 'demo_active';
    };
    linkedin: {
      name: string;
      handle: string;
      followers: number;
      views: number;
      postsCount: number;
      engagementRate: number;
      growthPct: number;
      status: 'demo_active';
    };
    x: {
      name: string;
      handle: string;
      followers: number;
      views: number;
      postsCount: number;
      engagementRate: number;
      growthPct: number;
      status: 'demo_active';
    };
  };
  topPosts: Array<{
    id: string;
    title: string;
    platform: 'youtube' | 'instagram' | 'tiktok' | 'linkedin' | 'x';
    thumbnailUrl: string;
    publishedDate: string;
    views: number;
    likes: number;
    comments: number;
    shares: number;
    engagementRate: number;
  }>;
  recentContent: Array<{
    id: string;
    title: string;
    platform: 'youtube' | 'instagram' | 'tiktok' | 'linkedin' | 'x';
    type: 'video' | 'reel' | 'post' | 'short';
    status: 'published' | 'scheduled' | 'draft';
    publishedDate: string;
    views: number;
    engagementRate: number;
  }>;
  demographics: {
    age: Array<{ label: string; pct: number }>;
    gender: Array<{ label: string; pct: number }>;
    location: Array<{ label: string; pct: number }>;
    device: Array<{ label: string; pct: number }>;
  };
}

export function getCreatorDemoData(range: string = '30d'): CreatorDemoData {
  // Multiply factor based on range
  const factor = range === '7d' ? 0.35 : range === '90d' ? 2.8 : range === '1y' ? 9.2 : 1.0;

  return {
    summary: {
      totalFollowers: 248500,
      followersGrowthPct: 12.4,
      totalViews: Math.round(3820400 * factor),
      viewsGrowthPct: 18.2,
      totalLikes: Math.round(284120 * factor),
      totalComments: Math.round(42650 * factor),
      totalShares: Math.round(19840 * factor),
      engagementRate: 4.86,
      engagementGrowthPct: 0.64,
      estimatedRevenue: Math.round(845000 * factor),
      impressions: Math.round(5420000 * factor)
    },
    growthTrend: [
      { date: 'Day 1', followers: 236200, views: Math.round(84000 * factor), engagement: 4.6 },
      { date: 'Day 5', followers: 238400, views: Math.round(112000 * factor), engagement: 4.8 },
      { date: 'Day 10', followers: 240100, views: Math.round(138000 * factor), engagement: 4.7 },
      { date: 'Day 15', followers: 242600, views: Math.round(195000 * factor), engagement: 5.2 },
      { date: 'Day 20', followers: 244800, views: Math.round(162000 * factor), engagement: 4.9 },
      { date: 'Day 25', followers: 246900, views: Math.round(210000 * factor), engagement: 5.4 },
      { date: 'Day 30', followers: 248500, views: Math.round(245000 * factor), engagement: 5.1 }
    ],
    engagementTrend: [
      { date: 'Mon', likes: Math.round(42000 * factor), comments: Math.round(6200 * factor), shares: Math.round(2800 * factor), views: Math.round(540000 * factor) },
      { date: 'Tue', likes: Math.round(38000 * factor), comments: Math.round(5400 * factor), shares: Math.round(2400 * factor), views: Math.round(480000 * factor) },
      { date: 'Wed', likes: Math.round(46000 * factor), comments: Math.round(7100 * factor), shares: Math.round(3400 * factor), views: Math.round(610000 * factor) },
      { date: 'Thu', likes: Math.round(39000 * factor), comments: Math.round(5800 * factor), shares: Math.round(2900 * factor), views: Math.round(520000 * factor) },
      { date: 'Fri', likes: Math.round(52000 * factor), comments: Math.round(8200 * factor), shares: Math.round(4100 * factor), views: Math.round(720000 * factor) },
      { date: 'Sat', likes: Math.round(68000 * factor), comments: Math.round(9800 * factor), shares: Math.round(5200 * factor), views: Math.round(890000 * factor) },
      { date: 'Sun', likes: Math.round(61000 * factor), comments: Math.round(8900 * factor), shares: Math.round(4400 * factor), views: Math.round(810000 * factor) }
    ],
    platforms: {
      youtube: {
        name: 'YouTube',
        handle: '@IpsitaTech',
        followers: 125430,
        views: Math.round(1842000 * factor),
        postsCount: 142,
        engagementRate: 4.92,
        growthPct: 14.2,
        avgDuration: '7m 14s',
        status: 'demo_active'
      },
      instagram: {
        name: 'Instagram',
        handle: '@ipsita.creates',
        followers: 64200,
        views: Math.round(1120000 * factor),
        postsCount: 286,
        engagementRate: 5.48,
        growthPct: 11.8,
        status: 'demo_active'
      },
      tiktok: {
        name: 'TikTok',
        handle: '@ipsitatech',
        followers: 42800,
        views: Math.round(720000 * factor),
        postsCount: 114,
        engagementRate: 6.84,
        growthPct: 22.5,
        status: 'demo_active'
      },
      linkedin: {
        name: 'LinkedIn',
        handle: 'ipsita-priyadarshini',
        followers: 11500,
        views: Math.round(140000 * factor),
        postsCount: 58,
        engagementRate: 3.25,
        growthPct: 8.4,
        status: 'demo_active'
      },
      x: {
        name: 'X (Twitter)',
        handle: '@ipsita_tech',
        followers: 5070,
        views: Math.round(60000 * factor),
        postsCount: 340,
        engagementRate: 2.14,
        growthPct: 5.1,
        status: 'demo_active'
      }
    },
    topPosts: [
      {
        id: 'top-1',
        title: 'Building Production AI SaaS from Scratch in 2026',
        platform: 'youtube',
        thumbnailUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=400&auto=format&fit=crop&q=80',
        publishedDate: '4 days ago',
        views: Math.round(482000 * factor),
        likes: Math.round(38200 * factor),
        comments: Math.round(4200 * factor),
        shares: Math.round(1840 * factor),
        engagementRate: 9.17
      },
      {
        id: 'top-2',
        title: '5 AI Tools Senior Software Engineers Actually Use',
        platform: 'instagram',
        thumbnailUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=400&auto=format&fit=crop&q=80',
        publishedDate: '1 week ago',
        views: Math.round(340000 * factor),
        likes: Math.round(28400 * factor),
        comments: Math.round(3100 * factor),
        shares: Math.round(2400 * factor),
        engagementRate: 9.97
      },
      {
        id: 'top-3',
        title: 'Day in the Life of an AI Creator & Full-Stack Engineer',
        platform: 'tiktok',
        thumbnailUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400&auto=format&fit=crop&q=80',
        publishedDate: '2 weeks ago',
        views: Math.round(290000 * factor),
        likes: Math.round(24500 * factor),
        comments: Math.round(2800 * factor),
        shares: Math.round(3200 * factor),
        engagementRate: 10.51
      },
      {
        id: 'top-4',
        title: 'Why Most Analytics Dashboards Fail (And How to Fix Them)',
        platform: 'linkedin',
        thumbnailUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&auto=format&fit=crop&q=80',
        publishedDate: '3 weeks ago',
        views: Math.round(72000 * factor),
        likes: Math.round(3200 * factor),
        comments: Math.round(840 * factor),
        shares: Math.round(420 * factor),
        engagementRate: 6.20
      },
      {
        id: 'top-5',
        title: 'The exact tech stack I use to build scalable web apps',
        platform: 'x',
        thumbnailUrl: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400&auto=format&fit=crop&q=80',
        publishedDate: '3 days ago',
        views: Math.round(45000 * factor),
        likes: Math.round(1840 * factor),
        comments: Math.round(320 * factor),
        shares: Math.round(510 * factor),
        engagementRate: 5.93
      }
    ],
    recentContent: [
      {
        id: 'rec-1',
        title: 'Deep Dive: Real-time Multi-Platform Web Analytics',
        platform: 'youtube',
        type: 'video',
        status: 'published',
        publishedDate: 'Nov 8, 2026',
        views: Math.round(124000 * factor),
        engagementRate: 5.42
      },
      {
        id: 'rec-2',
        title: 'Clean Architecture with React & Tailwind CSS',
        platform: 'instagram',
        type: 'reel',
        status: 'published',
        publishedDate: 'Nov 6, 2026',
        views: Math.round(88000 * factor),
        engagementRate: 6.18
      },
      {
        id: 'rec-3',
        title: 'Stop using messy state management in 2026',
        platform: 'tiktok',
        type: 'video',
        status: 'published',
        publishedDate: 'Nov 4, 2026',
        views: Math.round(94000 * factor),
        engagementRate: 7.20
      },
      {
        id: 'rec-4',
        title: 'The Evolution of Creator Economy Monetization',
        platform: 'linkedin',
        type: 'post',
        status: 'published',
        publishedDate: 'Nov 2, 2026',
        views: Math.round(28000 * factor),
        engagementRate: 4.15
      },
      {
        id: 'rec-5',
        title: 'Micro-animations that make software feel premium',
        platform: 'youtube',
        type: 'short',
        status: 'published',
        publishedDate: 'Oct 30, 2026',
        views: Math.round(162000 * factor),
        engagementRate: 8.40
      },
      {
        id: 'rec-6',
        title: 'Interactive Dashboards Best Practices Masterclass',
        platform: 'youtube',
        type: 'video',
        status: 'scheduled',
        publishedDate: 'Nov 14, 2026',
        views: 0,
        engagementRate: 0
      }
    ],
    demographics: {
      age: [
        { label: '18-24', pct: 32 },
        { label: '25-34', pct: 44 },
        { label: '35-44', pct: 16 },
        { label: '45+', pct: 8 }
      ],
      gender: [
        { label: 'Female', pct: 54 },
        { label: 'Male', pct: 44 },
        { label: 'Other', pct: 2 }
      ],
      location: [
        { label: 'United States', pct: 45 },
        { label: 'United Kingdom', pct: 15 },
        { label: 'India', pct: 14 },
        { label: 'Canada', pct: 8 },
        { label: 'Germany', pct: 6 }
      ],
      device: [
        { label: 'Mobile Phone', pct: 72 },
        { label: 'Desktop / Laptop', pct: 22 },
        { label: 'Tablet / TV', pct: 6 }
      ]
    }
  };
}

export interface AgencyDemoData {
  summary: {
    totalCreators: number;
    totalFollowers: number;
    totalViews: number;
    activeCampaigns: number;
    totalRevenue: number;
    agencyCommission: number;
    growthPct: number;
  };
  creators: Array<{
    id: string;
    name: string;
    handle: string;
    avatarUrl: string;
    niche: string;
    platform: 'youtube' | 'instagram' | 'tiktok' | 'multi';
    followers: number;
    views: number;
    engagementRate: number;
    revenue: number;
    activeDeals: number;
    status: 'active' | 'in_review';
  }>;
  campaigns: Array<{
    id: string;
    brand: string;
    title: string;
    budget: number;
    creatorsCount: number;
    progressPct: number;
    deadline: string;
    status: 'active' | 'completed' | 'in_review';
  }>;
  platformDistribution: Array<{
    name: string;
    pct: number;
    color: string;
  }>;
  recentActivity: Array<{
    id: string;
    creator: string;
    action: string;
    time: string;
    type: 'upload' | 'contract' | 'deal' | 'milestone';
  }>;
  pendingTasks: Array<{
    id: string;
    task: string;
    assignee: string;
    priority: 'high' | 'medium' | 'low';
    dueDate: string;
  }>;
}

export function getAgencyDemoData(range: string = '30d'): AgencyDemoData {
  const factor = range === '7d' ? 0.35 : range === '90d' ? 2.8 : range === '1y' ? 9.2 : 1.0;

  return {
    summary: {
      totalCreators: 18,
      totalFollowers: 1482000,
      totalViews: Math.round(18420000 * factor),
      activeCampaigns: 14,
      totalRevenue: Math.round(12500000 * factor),
      agencyCommission: Math.round(1875000 * factor),
      growthPct: 14.8
    },
    creators: [
      {
        id: 'c-1',
        name: 'Ipsita Priyadarshini',
        handle: '@IpsitaTech',
        avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
        niche: 'AI & Software Tech',
        platform: 'multi',
        followers: 248500,
        views: Math.round(3820000 * factor),
        engagementRate: 4.86,
        revenue: Math.round(285000 * factor),
        activeDeals: 4,
        status: 'active'
      },
      {
        id: 'c-2',
        name: 'Harshitha Tech',
        handle: '@HarshithaTech',
        avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80',
        niche: 'Developer Workflows',
        platform: 'youtube',
        followers: 185000,
        views: Math.round(2420000 * factor),
        engagementRate: 5.20,
        revenue: Math.round(22400 * factor),
        activeDeals: 3,
        status: 'active'
      },
      {
        id: 'c-3',
        name: 'Alex Rivera',
        handle: '@alexriverafit',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
        niche: 'Fitness & Longevity',
        platform: 'instagram',
        followers: 320000,
        views: Math.round(4120000 * factor),
        engagementRate: 4.12,
        revenue: Math.round(34800 * factor),
        activeDeals: 5,
        status: 'active'
      },
      {
        id: 'c-4',
        name: 'Sophia Chen',
        handle: '@sophiacreates',
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
        niche: 'Design & Aesthetics',
        platform: 'tiktok',
        followers: 410000,
        views: Math.round(5240000 * factor),
        engagementRate: 6.45,
        revenue: Math.round(46200 * factor),
        activeDeals: 4,
        status: 'active'
      },
      {
        id: 'c-5',
        name: 'Marcus Vance',
        handle: '@marcusfinance',
        avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
        niche: 'Personal Wealth',
        platform: 'youtube',
        followers: 168000,
        views: Math.round(1890000 * factor),
        engagementRate: 3.82,
        revenue: Math.round(26000 * factor),
        activeDeals: 2,
        status: 'active'
      },
      {
        id: 'c-6',
        name: 'Elena Rostova',
        handle: '@elenavoyages',
        avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80',
        niche: 'Travel & Photography',
        platform: 'instagram',
        followers: 150500,
        views: Math.round(1930000 * factor),
        engagementRate: 5.90,
        revenue: Math.round(18600 * factor),
        activeDeals: 2,
        status: 'active'
      }
    ],
    campaigns: [
      {
        id: 'camp-1',
        brand: 'Synthetix AI',
        title: 'Q2 Developer Platform Spring Campaign',
        budget: 3500000,
        creatorsCount: 6,
        progressPct: 85,
        deadline: 'Nov 20, 2026',
        status: 'active'
      },
      {
        id: 'camp-2',
        brand: 'Gymshark',
        title: 'Performance Athletic Gear Drop',
        budget: 2800000,
        creatorsCount: 4,
        progressPct: 92,
        deadline: 'Nov 18, 2026',
        status: 'active'
      },
      {
        id: 'camp-3',
        brand: 'NordVPN',
        title: 'Global Cybersecurity Awareness Wave',
        budget: 2200000,
        creatorsCount: 5,
        progressPct: 60,
        deadline: 'Dec 05, 2026',
        status: 'active'
      },
      {
        id: 'camp-4',
        brand: 'Notion',
        title: 'Ultimate Creator Workspace Showcase',
        budget: 1600000,
        creatorsCount: 3,
        progressPct: 100,
        deadline: 'Completed',
        status: 'completed'
      },
      {
        id: 'camp-5',
        brand: 'Epidemic Sound',
        title: 'High-Impact Creator Audio Integration',
        budget: 950000,
        creatorsCount: 2,
        progressPct: 35,
        deadline: 'Dec 12, 2026',
        status: 'in_review'
      }
    ],
    platformDistribution: [
      { name: 'YouTube', pct: 42, color: '#ef4444' },
      { name: 'Instagram', pct: 28, color: '#ec4899' },
      { name: 'TikTok', pct: 18, color: '#06b6d4' },
      { name: 'LinkedIn', pct: 8, color: '#0284c7' },
      { name: 'X / Twitter', pct: 4, color: '#64748b' }
    ],
    recentActivity: [
      {
        id: 'act-1',
        creator: 'Ipsita Priyadarshini',
        action: 'Submitted final video draft for Synthetix AI integration',
        time: '15m ago',
        type: 'upload'
      },
      {
        id: 'act-2',
        creator: 'Sophia Chen',
        action: 'Signed brand partnership contract with Sephora (₹15,25,000)',
        time: '1h ago',
        type: 'contract'
      },
      {
        id: 'act-3',
        creator: 'Alex Rivera',
        action: 'Surpassed 41.5L monthly impressions across Instagram Reels',
        time: '3h ago',
        type: 'milestone'
      },
      {
        id: 'act-4',
        creator: 'Harshitha Tech',
        action: 'Delivered sponsored YouTube video for NordVPN',
        time: '5h ago',
        type: 'deal'
      }
    ],
    pendingTasks: [
      {
        id: 't-1',
        task: 'Approve final script for Synthetix AI Q2 campaign',
        assignee: 'Growth Lead',
        priority: 'high',
        dueDate: 'Today'
      },
      {
        id: 't-2',
        task: 'Process creator payout batch (₹28,50,000) for October deliverables',
        assignee: 'Finance Team',
        priority: 'high',
        dueDate: 'Tomorrow'
      },
      {
        id: 't-3',
        task: 'Review draft media kit update for Sophia Chen',
        assignee: 'Talent Manager',
        priority: 'medium',
        dueDate: 'Nov 14'
      },
      {
        id: 't-4',
        task: 'Schedule introductory call with Adobe Creative Cloud sponsor',
        assignee: 'Brand Partnerships',
        priority: 'medium',
        dueDate: 'Nov 16'
      }
    ]
  };
}

export interface MarketingDemoData {
  summary: {
    totalSpend: number;
    budget: number;
    totalReach: number;
    totalImpressions: number;
    totalClicks: number;
    totalConversions: number;
    avgEngagementRate: number;
    avgRoas: number;
    attributedRevenue: number;
  };
  campaigns: Array<{
    id: string;
    title: string;
    brand: string;
    budget: number;
    spend: number;
    reach: number;
    clicks: number;
    conversions: number;
    roas: number;
    status: 'active' | 'completed' | 'paused';
  }>;
  spendTrend: Array<{
    month: string;
    spend: number;
    revenue: number;
    conversions: number;
  }>;
  channelPerformance: Array<{
    channel: string;
    spend: number;
    roas: number;
    conversions: number;
    pct: number;
  }>;
}

export function getMarketingDemoData(range: string = '30d'): MarketingDemoData {
  const factor = range === '7d' ? 0.35 : range === '90d' ? 2.8 : range === '1y' ? 9.2 : 1.0;

  return {
    summary: {
      totalSpend: Math.round(28500000 * factor),
      budget: Math.round(35000000 * factor),
      totalReach: Math.round(16240000 * factor),
      totalImpressions: Math.round(28400000 * factor),
      totalClicks: Math.round(842600 * factor),
      totalConversions: Math.round(38400 * factor),
      avgEngagementRate: 5.24,
      avgRoas: 3.84,
      attributedRevenue: Math.round(109440000 * factor)
    },
    campaigns: [
      {
        id: 'm-1',
        title: 'Synthetix AI Developer Platform Global Sprint',
        brand: 'Synthetix AI',
        budget: 12500000,
        spend: Math.round(11000000 * factor),
        reach: Math.round(8400000 * factor),
        clicks: Math.round(420000 * factor),
        conversions: Math.round(22400 * factor),
        roas: 4.20,
        status: 'active'
      },
      {
        id: 'm-2',
        title: 'CloudStudio Pro Summer Upgrade Wave',
        brand: 'CloudStudio',
        budget: 8500000,
        spend: Math.round(7400000 * factor),
        reach: Math.round(4800000 * factor),
        clicks: Math.round(240000 * factor),
        conversions: Math.round(9800 * factor),
        roas: 3.65,
        status: 'active'
      },
      {
        id: 'm-3',
        title: 'PulseWear Athletic Brand Ambassador Push',
        brand: 'PulseWear',
        budget: 6500000,
        spend: Math.round(5800000 * factor),
        reach: Math.round(2200000 * factor),
        clicks: Math.round(130000 * factor),
        conversions: Math.round(4600 * factor),
        roas: 3.42,
        status: 'active'
      },
      {
        id: 'm-4',
        title: 'CyberSec Enterprise Trust & Security Campaign',
        brand: 'CyberSec Suite',
        budget: 4500000,
        spend: Math.round(4100000 * factor),
        reach: Math.round(840000 * factor),
        clicks: Math.round(52600 * factor),
        conversions: Math.round(1600 * factor),
        roas: 2.90,
        status: 'completed'
      }
    ],
    spendTrend: [
      { month: 'Jun', spend: Math.round(45000 * factor), revenue: Math.round(158000 * factor), conversions: Math.round(4200 * factor) },
      { month: 'Jul', spend: Math.round(52000 * factor), revenue: Math.round(192000 * factor), conversions: Math.round(5100 * factor) },
      { month: 'Aug', spend: Math.round(68000 * factor), revenue: Math.round(260000 * factor), conversions: Math.round(7400 * factor) },
      { month: 'Sep', spend: Math.round(84000 * factor), revenue: Math.round(324000 * factor), conversions: Math.round(9800 * factor) },
      { month: 'Oct', spend: Math.round(93800 * factor), revenue: Math.round(382350 * factor), conversions: Math.round(11900 * factor) }
    ],
    channelPerformance: [
      { channel: 'YouTube Video Integrations', spend: Math.round(164500 * factor), roas: 4.35, conversions: Math.round(19400 * factor), pct: 48 },
      { channel: 'Instagram Reels & Stories', spend: Math.round(82200 * factor), roas: 3.72, conversions: Math.round(9800 * factor), pct: 24 },
      { channel: 'TikTok Spark Ads & Creators', spend: Math.round(54800 * factor), roas: 3.45, conversions: Math.round(6200 * factor), pct: 16 },
      { channel: 'LinkedIn B2B Thought Leaders', spend: Math.round(41300 * factor), roas: 3.10, conversions: Math.round(3000 * factor), pct: 12 }
    ]
  };
}

export interface AdminDemoData {
  stats: {
    total_users: number;
    active_users: number;
    registrations_last_30_days: number;
    active_sessions: number;
    role_distribution: {
      creator: number;
      agency: number;
      marketing: number;
      admin: number;
    };
  };
  systemHealth: {
    uptime: string;
    apiLatencyMs: number;
    dbLatencyMs: number;
    memoryUsage: string;
    storageUsage: string;
    status: 'healthy';
  };
  users: Array<{
    id: number;
    name: string;
    email: string;
    role: 'creator' | 'agency' | 'marketing' | 'admin';
    status: 'active' | 'pending' | 'suspended';
    lastLogin: string;
    createdAt: string;
  }>;
  auditLogs: Array<{
    id: number;
    action: string;
    user: string;
    details: string;
    ipAddress: string;
    timestamp: string;
  }>;
}

export function getAdminDemoData(): AdminDemoData {
  return {
    stats: {
      total_users: 1428,
      active_users: 1180,
      registrations_last_30_days: 264,
      active_sessions: 84,
      role_distribution: {
        creator: 984,
        agency: 286,
        marketing: 142,
        admin: 16
      }
    },
    systemHealth: {
      uptime: '99.98%',
      apiLatencyMs: 42,
      dbLatencyMs: 28,
      memoryUsage: '48%',
      storageUsage: '34%',
      status: 'healthy'
    },
    users: [
      {
        id: 1,
        name: 'HARSHITHA S',
        email: 'sharshitha28007@gmail.com',
        role: 'admin',
        status: 'active',
        lastLogin: 'Just now',
        createdAt: 'Oct 15, 2026'
      },
      {
        id: 2,
        name: 'Ipsita Priyadarshini',
        email: 'creator@creatoriq.com',
        role: 'creator',
        status: 'active',
        lastLogin: '10m ago',
        createdAt: 'Oct 18, 2026'
      },
      {
        id: 3,
        name: 'Nexus Growth Agency',
        email: 'agency@creatoriq.com',
        role: 'agency',
        status: 'active',
        lastLogin: '25m ago',
        createdAt: 'Oct 20, 2026'
      },
      {
        id: 4,
        name: 'Brand Studio Marketing',
        email: 'marketing@creatoriq.com',
        role: 'marketing',
        status: 'active',
        lastLogin: '1h ago',
        createdAt: 'Oct 22, 2026'
      },
      {
        id: 5,
        name: 'Alex Rivera',
        email: 'alex.rivera@creatorhub.io',
        role: 'creator',
        status: 'active',
        lastLogin: '3h ago',
        createdAt: 'Oct 25, 2026'
      },
      {
        id: 6,
        name: 'Sophia Chen',
        email: 'sophia.chen@creators.co',
        role: 'creator',
        status: 'active',
        lastLogin: '5h ago',
        createdAt: 'Oct 28, 2026'
      },
      {
        id: 7,
        name: 'Vanguard Media Group',
        email: 'ops@vanguardmedia.com',
        role: 'agency',
        status: 'active',
        lastLogin: 'Yesterday',
        createdAt: 'Nov 01, 2026'
      },
      {
        id: 8,
        name: 'Marcus Vance',
        email: 'marcus.vance@creatorhub.io',
        role: 'creator',
        status: 'active',
        lastLogin: 'Yesterday',
        createdAt: 'Nov 03, 2026'
      }
    ],
    auditLogs: [
      {
        id: 101,
        action: 'USER_LOGIN_SUCCESS',
        user: 'sharshitha28007@gmail.com',
        details: 'System Administrator logged in with Firebase OAuth & JWT verification',
        ipAddress: '192.168.1.42',
        timestamp: 'Just now'
      },
      {
        id: 102,
        action: 'WORKSPACE_SWITCHED',
        user: 'sharshitha28007@gmail.com',
        details: 'Switched active workspace session to Admin Team',
        ipAddress: '192.168.1.42',
        timestamp: '5m ago'
      },
      {
        id: 103,
        action: 'CAMPAIGN_SPEND_APPROVED',
        user: 'marketing@creatoriq.com',
        details: 'Approved ₹35,00,000 budget allocation for Synthetix AI Q2 Launch',
        ipAddress: '10.0.4.12',
        timestamp: '18m ago'
      },
      {
        id: 104,
        action: 'CREATOR_ROSTER_SYNC',
        user: 'agency@creatoriq.com',
        details: 'Synchronized performance delta for 18 managed talent accounts',
        ipAddress: '10.0.8.91',
        timestamp: '42m ago'
      },
      {
        id: 105,
        action: 'TOKEN_VERIFIED',
        user: 'creator@creatoriq.com',
        details: 'Verified Creator profile settings & multi-platform analytics query',
        ipAddress: '172.16.2.14',
        timestamp: '1h ago'
      }
    ]
  };
}
