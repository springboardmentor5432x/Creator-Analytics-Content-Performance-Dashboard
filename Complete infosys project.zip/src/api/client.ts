import {
  WorkspaceRole,
  UserProfile,
  SocialAccount,
  CreatorDashboardData,
  AgencyDashboardData,
  MarketingDashboardData,
  AdminDashboardData,
} from '../types';

export class ApiError extends Error {
  statusCode: number;
  data: any;

  constructor(message: string, statusCode: number, data?: any) {
    super(message);
    this.name = 'ApiError';
    this.statusCode = statusCode;
    this.data = data;
  }
}

import { getToken } from '../config/api';

class ApiClient {
  private activeRole: WorkspaceRole = 'marketing';
  private workspaceId: string = 'ws_india_hq';

  setActiveRole(role: WorkspaceRole) {
    this.activeRole = role;
  }

  getActiveRole(): WorkspaceRole {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('creatoriq_active_role') as WorkspaceRole | null;
      if (stored) return stored;
    }
    return this.activeRole;
  }

  private getHeaders(): Record<string, string> {
    const token = getToken();
    const role = this.getActiveRole();
    return {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      'X-Workspace-Role': role,
      'X-Workspace-Id': this.workspaceId,
    };
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = endpoint.startsWith('http') ? endpoint : endpoint;
    const headers = {
      ...this.getHeaders(),
      ...(options.headers as Record<string, string> || {}),
    };

    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (!response.ok) {
      let errorData: any = null;
      try {
        errorData = await response.json();
      } catch (_e) {
        errorData = { message: response.statusText };
      }

      throw new ApiError(
        errorData?.message || `HTTP Request failed with status ${response.status}`,
        response.status,
        errorData
      );
    }

    return response.json() as Promise<T>;
  }

  // Auth & Profile
  async getProfile(): Promise<{ user: UserProfile }> {
    return this.request<{ user: UserProfile }>('/api/auth/me');
  }

  async switchRole(role: WorkspaceRole): Promise<{ success: boolean; user: UserProfile }> {
    this.activeRole = role;
    return this.request<{ success: boolean; user: UserProfile }>('/api/auth/switch-role', {
      method: 'POST',
      body: JSON.stringify({ role }),
    });
  }

  // Dashboard APIs
  async getCreatorDashboard(): Promise<CreatorDashboardData> {
    return this.request<CreatorDashboardData>('/api/creator/dashboard');
  }

  async getAgencyDashboard(): Promise<AgencyDashboardData> {
    return this.request<AgencyDashboardData>('/api/agency/dashboard');
  }

  async getMarketingDashboard(): Promise<MarketingDashboardData> {
    // Note: Passes X-Workspace-Role header. If role is 'marketing' or 'admin', returns 200.
    // If role is unauthorized (e.g. 'creator'), the backend returns HTTP 403 Forbidden.
    return this.request<MarketingDashboardData>('/api/marketing/dashboard');
  }

  async getAdminDashboard(): Promise<AdminDashboardData> {
    return this.request<AdminDashboardData>('/api/admin/dashboard');
  }

  // Integrations APIs
  async getSocialAccounts(): Promise<{ accounts: SocialAccount[] }> {
    return this.request<{ accounts: SocialAccount[] }>('/api/integrations');
  }

  async connectSocialAccount(platform: string): Promise<{ success: boolean; account: SocialAccount }> {
    return this.request<{ success: boolean; account: SocialAccount }>(`/api/integrations/${platform}/connect`, {
      method: 'POST',
    });
  }

  async disconnectSocialAccount(platform: string): Promise<{ success: boolean; account: SocialAccount }> {
    return this.request<{ success: boolean; account: SocialAccount }>(`/api/integrations/${platform}/disconnect`, {
      method: 'POST',
    });
  }

  async syncSocialAccount(platform: string): Promise<{ success: boolean; account: SocialAccount }> {
    return this.request<{ success: boolean; account: SocialAccount }>(`/api/integrations/${platform}/sync`, {
      method: 'POST',
    });
  }
}

export const api = new ApiClient();
