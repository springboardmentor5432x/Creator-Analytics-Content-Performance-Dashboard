const TOKEN_KEY = 'creatoriq_jwt_token';
const API_URL_KEY = 'creatoriq_api_base_url';

export const DEFAULT_API_URL = import.meta.env.VITE_API_BASE_URL || '/api';

export const getApiBaseUrl = (): string => {
  if (typeof window !== 'undefined') {
    const customUrl = localStorage.getItem(API_URL_KEY);
    if (customUrl) return customUrl;
  }
  return DEFAULT_API_URL;
};

export const setApiBaseUrl = (url: string): void => {
  if (typeof window !== 'undefined') {
    if (!url || url === DEFAULT_API_URL) {
      localStorage.removeItem(API_URL_KEY);
    } else {
      localStorage.setItem(API_URL_KEY, url.trim());
    }
  }
};

export const getToken = (): string | null => {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem(TOKEN_KEY);
};

export const setToken = (token: string): void => {
  if (typeof window !== 'undefined') {
    localStorage.setItem(TOKEN_KEY, token);
  }
};

export const clearToken = (): void => {
  if (typeof window !== 'undefined') {
    localStorage.removeItem(TOKEN_KEY);
  }
};
