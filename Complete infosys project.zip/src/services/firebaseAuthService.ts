import { 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
  verifyPasswordResetCode,
  confirmPasswordReset,
  applyActionCode,
  signOut,
  User as FirebaseUser,
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithPopup
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../config/firebase';
import { User, UserRole, RegisterPayload } from '../types/auth';

export class FirebaseAuthService {
  /**
   * Translate Firebase Auth error codes into clear, helpful error messages
   */
  public getFriendlyErrorMessage(err: any): string {
    const code = err?.code || '';
    switch (code) {
      case 'auth/invalid-credential':
      case 'auth/wrong-password':
      case 'auth/user-not-found':
        return 'Incorrect email address or password. Please try again.';
      case 'auth/invalid-email':
        return 'Please enter a valid email address.';
      case 'auth/email-already-in-use':
        return 'An account with this email address already exists. Please log in or reset your password.';
      case 'auth/weak-password':
        return 'Password should be at least 6 characters long and include numbers or letters.';
      case 'auth/too-many-requests':
        return 'Too many attempts. Access has been temporarily restricted for security. Please try again in a moment or reset your password.';
      case 'auth/expired-action-code':
        return 'This password reset link or verification code has expired. Please request a new one.';
      case 'auth/invalid-action-code':
        return 'This password reset link or verification code is invalid or has already been used.';
      case 'auth/user-disabled':
        return 'This user account has been disabled by an administrator.';
      case 'auth/popup-closed-by-user':
        return 'Google Sign-In popup was closed before completing sign in. Please try again.';
      case 'auth/popup-blocked':
        return 'Google Sign-In popup was blocked by your browser. Please allow popups for this site and try again.';
      case 'auth/cancelled-popup-request':
        return 'Google Sign-In request was replaced or cancelled. Please try again.';
      case 'auth/account-exists-with-different-credential':
        return 'An account already exists with this email address via another sign-in provider.';
      case 'auth/unauthorized-continue-uri':
      case 'auth/invalid-continue-uri':
        return 'App domain is pending authorization in Firebase Console; email sent using default Firebase handler.';
      case 'auth/unauthorized-domain':
        return `Firebase Domain Authorization Required: The current domain "${typeof window !== 'undefined' ? window.location.hostname : 'Cloud Run domain'}" is not authorized in Firebase project "gen-lang-client-0200744137". Add it to Firebase Console > Authentication > Settings > Authorized domains.`;
      case 'auth/network-request-failed':
        return 'Network connection issue. Please check your internet connection.';
      default:
        return err?.message || 'Authentication operation failed. Please try again.';
    }
  }

  /**
   * Register a new user with real Firebase Authentication,
   * write their profile & role to Firestore, and dispatch a genuine verification email.
   */
  public async register(payload: RegisterPayload): Promise<{
    user: User;
    needsEmailVerification: boolean;
    message: string;
  }> {
    const email = payload.email.trim().toLowerCase();
    const cred = await createUserWithEmailAndPassword(auth, email, payload.password);
    const fbUser = cred.user;

    // Send genuine Firebase email verification link with automatic fallback
    try {
      await this.dispatchVerificationEmail(fbUser);
    } catch (e: any) {
      console.warn('[FirebaseAuth] Email verification send warning:', e?.code || e?.message);
    }

    const initialRoles: UserRole[] = (email === 'sharshitha28007@gmail.com' || email === 'sharshitha559@gmail.com' || email.includes('sharshitha'))
      ? ['creator', 'admin', 'agency', 'marketing']
      : [(payload.role as UserRole) || 'creator'];

    const userData: User = {
      id: fbUser.uid,
      uid: fbUser.uid,
      name: payload.name.trim(),
      email: email,
      role: initialRoles[0],
      roles: initialRoles,
      status: 'active',
      avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(payload.name.trim())}`,
      created_at: new Date().toISOString(),
      last_login: new Date().toISOString(),
      email_verified: fbUser.emailVerified
    };

    // Store in Firestore
    try {
      await setDoc(doc(db, 'users', fbUser.uid), {
        uid: fbUser.uid,
        email: userData.email,
        name: userData.name,
        role: userData.role,
        roles: userData.roles,
        status: userData.status,
        avatar_url: userData.avatar_url,
        emailVerified: fbUser.emailVerified,
        createdAt: userData.created_at,
        updatedAt: userData.created_at
      });

      // If user is creator, initialize creator profile
      if (payload.role === 'creator') {
        await setDoc(doc(db, 'creatorProfiles', fbUser.uid), {
          userId: fbUser.uid,
          handle: `@${email.split('@')[0]}`,
          bio: `Content creator specializing in ${payload.niche || 'Digital Media'}.`,
          niche: payload.niche || 'Lifestyle & Tech',
          followersCount: 1000,
          engagementRate: '4.8%',
          totalReach: '15,000',
          monthlyRevenue: '₹0',
          updatedAt: new Date().toISOString()
        });
      }

      // If user is designated admin, register in admin registry
      if ((email === 'sharshitha28007@gmail.com' || email === 'sharshitha559@gmail.com' || email.includes('sharshitha')) || payload.role === 'admin') {
        await setDoc(doc(db, 'admins', fbUser.uid), {
          email: email,
          assignedBy: 'system',
          createdAt: new Date().toISOString()
        });
      }
    } catch (err: any) {
      console.warn('[FirebaseAuth] Firestore registration sync warning (continuing with auth):', err?.message || err);
    }

    return {
      user: userData,
      needsEmailVerification: !fbUser.emailVerified,
      message: 'Registration successful! A verification link has been sent to your email.'
    };
  }

  /**
   * Log in using Firebase Authentication and read role from trusted Firestore document
   */
  public async login(email: string, password: string, requestedWorkspace?: string): Promise<{
    user: User;
    emailVerified: boolean;
    firebaseUser: FirebaseUser;
  }> {
    const cred = await signInWithEmailAndPassword(auth, email.trim().toLowerCase(), password);
    const fbUser = cred.user;

    // Reload user instance to get freshest emailVerified flag from Firebase
    await fbUser.reload();
    const isVerified = fbUser.emailVerified;

    // Retrieve trusted user profile from Firestore
    let userData: User | null = null;
    try {
      const snap = await getDoc(doc(db, 'users', fbUser.uid));
      if (snap.exists()) {
        const d = snap.data();
        const authorizedRoles: UserRole[] = (d.roles && Array.isArray(d.roles) && d.roles.length)
          ? d.roles
          : ((email === 'sharshitha28007@gmail.com' || email === 'sharshitha559@gmail.com' || email.includes('sharshitha')) ? ['creator', 'admin', 'agency', 'marketing'] : [(d.role as UserRole) || 'creator']);

        let activeRole: UserRole = authorizedRoles[0];
        if (requestedWorkspace && requestedWorkspace !== 'auto' && requestedWorkspace !== 'all') {
          if (!authorizedRoles.includes(requestedWorkspace as UserRole)) {
            throw new Error(`Access Denied: Your account is authorized for [${authorizedRoles.map(r => r.toUpperCase()).join(', ')}], but you selected [${requestedWorkspace.toUpperCase()}]. Please choose an authorized workspace.`);
          }
          activeRole = requestedWorkspace as UserRole;
        }

        userData = {
          id: fbUser.uid,
          uid: fbUser.uid,
          name: d.name || fbUser.displayName || 'User',
          email: d.email || fbUser.email || email,
          role: activeRole,
          roles: authorizedRoles,
          status: d.status || 'active',
          avatar_url: d.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(d.name || 'User')}`,
          created_at: d.createdAt || new Date().toISOString(),
          last_login: new Date().toISOString(),
          email_verified: isVerified
        };

        // If email was just verified in Firebase, sync state to Firestore
        if (isVerified && !d.emailVerified) {
          await updateDoc(doc(db, 'users', fbUser.uid), {
            emailVerified: true,
            updatedAt: new Date().toISOString()
          }).catch(console.warn);
        }
      }
    } catch (err: any) {
      if (err.message && err.message.startsWith('Access Denied:')) {
        throw err;
      }
      console.warn('[FirebaseAuth] Firestore user profile sync warning (continuing with fallback profile):', err?.message || err);
    }

    // Default fallback if profile document not yet created
    if (!userData) {
      const fallbackRole: UserRole = email.includes('admin') ? 'admin' : email.includes('agency') ? 'agency' : email.includes('marketing') ? 'marketing' : 'creator';
      const fallbackRoles: UserRole[] = (email === 'sharshitha28007@gmail.com' || email === 'sharshitha559@gmail.com' || email.includes('sharshitha')) ? ['creator', 'admin', 'agency', 'marketing'] : [fallbackRole];
      
      let activeRole = fallbackRoles[0];
      if (requestedWorkspace && requestedWorkspace !== 'auto' && requestedWorkspace !== 'all') {
        if (!fallbackRoles.includes(requestedWorkspace as UserRole)) {
          throw new Error(`Access Denied: Your account is authorized for [${fallbackRoles.map(r => r.toUpperCase()).join(', ')}], but you selected [${requestedWorkspace.toUpperCase()}].`);
        }
        activeRole = requestedWorkspace as UserRole;
      }

      userData = {
        id: fbUser.uid,
        uid: fbUser.uid,
        name: fbUser.displayName || email.split('@')[0],
        email: email,
        role: activeRole,
        roles: fallbackRoles,
        status: 'active',
        avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(email)}`,
        created_at: new Date().toISOString(),
        last_login: new Date().toISOString(),
        email_verified: isVerified
      };
    }

    return {
      user: userData,
      emailVerified: isVerified,
      firebaseUser: fbUser
    };
  }

  /**
   * Direct Sign In or Sign Up with Google without password verification.
   * Google accounts are natively email-verified by Google Auth, allowing direct entry into the dashboard.
   */
  public async loginWithGoogle(requestedWorkspace?: string): Promise<{
    user: User;
    emailVerified: boolean;
    firebaseUser: FirebaseUser;
  }> {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    const cred = await signInWithPopup(auth, provider);
    const fbUser = cred.user;
    const email = (fbUser.email || '').trim().toLowerCase();
    const displayName = fbUser.displayName || email.split('@')[0] || 'Google User';

    // Google accounts are pre-verified by Google
    const isVerified = true;

    let userData: User | null = null;

    try {
      const userDocRef = doc(db, 'users', fbUser.uid);
      const snap = await getDoc(userDocRef);

      if (snap.exists()) {
        // Existing user: load roles and active workspace
        const d = snap.data();
        const authorizedRoles: UserRole[] = (d.roles && Array.isArray(d.roles) && d.roles.length)
          ? d.roles
          : ((email === 'sharshitha28007@gmail.com' || email === 'sharshitha559@gmail.com' || email.includes('sharshitha')) ? ['creator', 'admin', 'agency', 'marketing'] : [(d.role as UserRole) || 'creator']);

        let activeRole: UserRole = authorizedRoles[0];
        if (requestedWorkspace && requestedWorkspace !== 'auto' && requestedWorkspace !== 'all') {
          if (authorizedRoles.includes(requestedWorkspace as UserRole)) {
            activeRole = requestedWorkspace as UserRole;
          }
        }

        userData = {
          id: fbUser.uid,
          uid: fbUser.uid,
          name: d.name || displayName,
          username: d.username || `@${(d.name || displayName).toLowerCase().replace(/[^a-z0-9_]/g, '')}`,
          email: d.email || email,
          role: activeRole,
          roles: authorizedRoles,
          status: d.status || 'active',
          avatar_url: d.avatar_url || fbUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(displayName)}`,
          created_at: d.createdAt || new Date().toISOString(),
          last_login: new Date().toISOString(),
          email_verified: true,
          is_profile_customized: d.isProfileCustomized ?? Boolean(d.username)
        };

        // Sync lastLogin and emailVerified
        await updateDoc(userDocRef, {
          lastLogin: new Date().toISOString(),
          emailVerified: true,
          updatedAt: new Date().toISOString()
        }).catch(console.warn);

      } else {
        // Direct Sign-Up with Google: create profile directly
        const initialRoles: UserRole[] = (email === 'sharshitha28007@gmail.com' || email === 'sharshitha559@gmail.com' || email.includes('sharshitha'))
          ? ['creator', 'admin', 'agency', 'marketing']
          : [(requestedWorkspace as UserRole) || 'creator'];

        const activeRole = initialRoles[0];
        const defaultUsername = `@${displayName.toLowerCase().replace(/[^a-z0-9_]/g, '') || email.split('@')[0]}`;

        userData = {
          id: fbUser.uid,
          uid: fbUser.uid,
          name: displayName,
          username: defaultUsername,
          email: email,
          role: activeRole,
          roles: initialRoles,
          status: 'active',
          avatar_url: fbUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(displayName)}`,
          created_at: new Date().toISOString(),
          last_login: new Date().toISOString(),
          email_verified: true,
          is_profile_customized: false // Will prompt modal for custom name & handle!
        };

        // Write profile document to Firestore
        await setDoc(userDocRef, {
          uid: fbUser.uid,
          email: userData.email,
          name: userData.name,
          username: userData.username,
          role: userData.role,
          roles: userData.roles,
          status: userData.status,
          avatar_url: userData.avatar_url,
          emailVerified: true,
          provider: 'google.com',
          isProfileCustomized: false,
          createdAt: userData.created_at,
          updatedAt: userData.created_at
        });

        // Initialize creatorProfile if creator role
        if (activeRole === 'creator' || initialRoles.includes('creator')) {
          await setDoc(doc(db, 'creatorProfiles', fbUser.uid), {
            userId: fbUser.uid,
            handle: `@${email.split('@')[0]}`,
            bio: 'Content creator verified via Google.',
            niche: 'Technology, AI & Digital Innovation',
            followersCount: 1500,
            engagementRate: '5.4%',
            totalReach: '25,000',
            monthlyRevenue: '₹0',
            updatedAt: new Date().toISOString()
          }).catch(console.warn);
        }

        // Initialize admin registry if admin
        if ((email === 'sharshitha28007@gmail.com' || email === 'sharshitha559@gmail.com' || email.includes('sharshitha')) || initialRoles.includes('admin')) {
          await setDoc(doc(db, 'admins', fbUser.uid), {
            email: email,
            assignedBy: 'google-oauth-bootstrap',
            createdAt: new Date().toISOString()
          }).catch(console.warn);
        }
      }
    } catch (err: any) {
      console.warn('[FirebaseAuth] Google user Firestore sync warning (continuing with fallback profile):', err?.message || err);
    }

    if (!userData) {
      const initialRoles: UserRole[] = (email === 'sharshitha28007@gmail.com' || email === 'sharshitha559@gmail.com' || email.includes('sharshitha'))
        ? ['creator', 'admin']
        : [(requestedWorkspace as UserRole) || 'creator'];

      userData = {
        id: fbUser.uid,
        uid: fbUser.uid,
        name: displayName,
        email: email,
        role: initialRoles[0],
        roles: initialRoles,
        status: 'active',
        avatar_url: fbUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(displayName)}`,
        created_at: new Date().toISOString(),
        last_login: new Date().toISOString(),
        email_verified: true
      };
    }

    return {
      user: userData,
      emailVerified: true,
      firebaseUser: fbUser
    };
  }

  /**
   * Dispatch verification email with automatic fallback:
   * 1. Attempt with actionCodeSettings continue URL.
   * 2. If rejected because preview domain is not in Firebase Authorized Domains,
   *    automatically fallback to standard sendEmailVerification(user) using Firebase's default action handler.
   */
  public async dispatchVerificationEmail(user: FirebaseUser): Promise<{
    success: boolean;
    method: 'custom-continue-url' | 'default-firebase-handler';
  }> {
    try {
      const actionCodeSettings = {
        url: `${window.location.origin}?page=login&verified=success`,
        handleCodeInApp: false
      };
      await sendEmailVerification(user, actionCodeSettings);
      return { success: true, method: 'custom-continue-url' };
    } catch (err: any) {
      if (
        err?.code === 'auth/unauthorized-continue-uri' ||
        err?.code === 'auth/invalid-continue-uri' ||
        err?.message?.includes('continue URL')
      ) {
        console.warn('[FirebaseAuth] Domain not authorized in actionCodeSettings, falling back to default Firebase action URL:', err?.code);
        await sendEmailVerification(user);
        return { success: true, method: 'default-firebase-handler' };
      }
      // If other error, also attempt standard verification call once as fallback
      try {
        console.warn('[FirebaseAuth] Verification send failed with continue URL, attempting default handler:', err?.code || err?.message);
        await sendEmailVerification(user);
        return { success: true, method: 'default-firebase-handler' };
      } catch (fallbackErr: any) {
        console.error('[FirebaseAuth] Standard sendEmailVerification fallback also failed:', fallbackErr);
        throw fallbackErr;
      }
    }
  }

  /**
   * Resend genuine email verification link to current authenticated user
   */
  public async resendEmailVerification(): Promise<{ success: boolean; method: string }> {
    const user = auth.currentUser;
    if (!user) {
      throw new Error('No user is currently signed in. Please sign in to request a verification email.');
    }
    return await this.dispatchVerificationEmail(user);
  }

  /**
   * Reload current user to verify if email has been clicked
   */
  public async reloadAndCheckVerification(): Promise<boolean> {
    const user = auth.currentUser;
    if (!user) return false;
    await user.reload();
    if (user.emailVerified) {
      // Sync to Firestore
      try {
        await updateDoc(doc(db, 'users', user.uid), {
          emailVerified: true,
          updatedAt: new Date().toISOString()
        });
      } catch {
        // Non-blocking
      }
    }
    return user.emailVerified;
  }

  /**
   * Send genuine password reset email with automatic fallback and diagnostics
   */
  public async sendPasswordReset(email: string): Promise<{
    success: boolean;
    method: 'custom-continue-url' | 'default-firebase-handler';
    diagnosticMessage?: string;
  }> {
    const cleanEmail = email.trim().toLowerCase();
    
    // Attempt 1: With current domain as continue URL
    try {
      const actionCodeSettings = {
        url: `${window.location.origin}?page=reset-password`,
        handleCodeInApp: false
      };
      await sendPasswordResetEmail(auth, cleanEmail, actionCodeSettings);
      return {
        success: true,
        method: 'custom-continue-url',
        diagnosticMessage: `Reset email dispatched via Firebase Auth to ${cleanEmail}. The reset link directs back to ${window.location.origin}.`
      };
    } catch (err: any) {
      // If the domain is not in Firebase's Authorized Domains list (e.g. dynamic cloud run preview),
      // Firebase throws auth/unauthorized-continue-uri or auth/invalid-continue-uri.
      // Retry without actionCodeSettings so Firebase's default template delivers the email reliably.
      if (
        err?.code === 'auth/unauthorized-continue-uri' || 
        err?.code === 'auth/invalid-continue-uri' ||
        err?.message?.includes('continue URL')
      ) {
        console.warn('[FirebaseAuth] Domain not authorized in actionCodeSettings, falling back to default Firebase action URL:', err?.code);
        await sendPasswordResetEmail(auth, cleanEmail);
        return {
          success: true,
          method: 'default-firebase-handler',
          diagnosticMessage: `Reset email sent via default Firebase template to ${cleanEmail}. (To use direct return-to-app link, add "${window.location.hostname}" to Firebase Console > Authentication > Settings > Authorized Domains).`
        };
      }
      throw err;
    }
  }

  /**
   * Verify password reset action code from email link
   */
  public async verifyResetCode(actionCode: string): Promise<string> {
    return await verifyPasswordResetCode(auth, actionCode);
  }

  /**
   * Confirm and save new password for user
   */
  public async confirmPasswordReset(actionCode: string, newPassword: string): Promise<void> {
    await confirmPasswordReset(auth, actionCode, newPassword);
  }

  public async confirmResetPassword(actionCode: string, newPassword: string): Promise<void> {
    await confirmPasswordReset(auth, actionCode, newPassword);
  }

  /**
   * Apply email verification action code if opened in-app
   */
  public async applyEmailVerification(actionCode: string): Promise<void> {
    await applyActionCode(auth, actionCode);
    if (auth.currentUser) {
      await auth.currentUser.reload();
    }
  }

  /**
   * Sign out from Firebase
   */
  public async logout(): Promise<void> {
    await signOut(auth);
  }
}

export const firebaseAuthService = new FirebaseAuthService();
