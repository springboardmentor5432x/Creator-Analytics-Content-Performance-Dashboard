import { getApiBaseUrl, getToken, setToken } from '../config/api';
import { 
  AuthResponse, 
  LoginPayload, 
  RegisterPayload, 
  User, 
  UserRole,
  CreatorProfile, 
  PersonalDetails,
  ProfileUpdatePayload,
  AdminUserUpdatePayload,
  AdminStats,
  AuditLog,
  Campaign,
  ContentItem,
  TaskItem,
  NotificationItem,
  SystemSettings,
  SupportedPlatform,
  PlatformDeveloperConfig,
  ConnectedPlatformAccount,
  GlobalSocialStat,
  AgencyDashboardData,
  MarketingDashboardData,
  SystemHealthStatus,
  UserSession,
  DashboardDeltaRecord,
  OAuthUrlResponse,
  YouTubeAnalyticsResponse,
  YouTubeDailyReport,
  YouTubeAnalyticsMetrics
} from '../types/auth';

export class ApiError extends Error {
  status: number;
  data: any;
  endpoint?: string;
  responseBody?: any;

  constructor(message: string, status: number, data?: any, endpoint?: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
    this.endpoint = endpoint;
    this.responseBody = data;
  }
}

function normalizeRole(input?: string | null): string {
  if (!input) return '';
  const clean = String(input).trim().toLowerCase().replace(/[-_]/g, ' ');
  if (clean.includes('admin')) return 'admin';
  if (clean.includes('agency')) return 'agency';
  if (clean.includes('marketing') || clean.includes('brand')) return 'marketing';
  if (clean.includes('creator')) return 'creator';
  return clean;
}

async function apiFetch<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const baseUrl = getApiBaseUrl().replace(/\/$/, '');
  const url = `${baseUrl}${endpoint.startsWith('/') ? '' : '/'}${endpoint}`;

  const headers = new Headers(options.headers || {});
  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  let token = getToken();
  try {
    const { auth } = await import('../config/firebase');
    if (auth?.currentUser) {
      const freshToken = await auth.currentUser.getIdToken();
      if (freshToken) {
        token = freshToken;
        setToken(freshToken);
      }
    }
  } catch {
    // Non-blocking fallback to stored token
  }

  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const isAdminEndpoint = endpoint.startsWith('/admin') || endpoint.startsWith('admin');
  const isAgencyEndpoint = endpoint.startsWith('/agency') || endpoint.startsWith('agency');
  const isMarketingEndpoint = endpoint.startsWith('/marketing') || endpoint.startsWith('marketing');
  const isCreatorEndpoint = endpoint.startsWith('/creator') || endpoint.startsWith('creator') || endpoint.startsWith('/creators') || endpoint.startsWith('creators') || endpoint.startsWith('/analytics') || endpoint.startsWith('analytics') || endpoint.startsWith('/content') || endpoint.startsWith('content');

  let activeRole: string | null = null;
  let userPermittedRoles: string[] = [];
  try {
    activeRole = normalizeRole(localStorage.getItem('creatoriq_active_role'));
    const storedUser = localStorage.getItem('creatoriq_user');
    if (storedUser) {
      const parsed = JSON.parse(storedUser);
      if (Array.isArray(parsed.roles)) {
        userPermittedRoles = parsed.roles.map((r: any) => normalizeRole(r) || String(r).toLowerCase());
      } else if (parsed.role) {
        userPermittedRoles = [normalizeRole(parsed.role) || String(parsed.role).toLowerCase()];
      }
    }
  } catch {
    // Ignore localStorage errors
  }

  const isUserAdmin = userPermittedRoles.includes('admin') || activeRole === 'admin';

  if (isAdminEndpoint) {
    headers.set('X-Workspace-Role', 'admin');
  } else if (isAgencyEndpoint) {
    headers.set('X-Workspace-Role', isUserAdmin ? (activeRole === 'agency' ? 'agency' : 'admin') : (userPermittedRoles.includes('agency') ? 'agency' : (activeRole || 'agency')));
  } else if (isMarketingEndpoint) {
    headers.set('X-Workspace-Role', isUserAdmin ? (activeRole === 'marketing' ? 'marketing' : 'admin') : (userPermittedRoles.includes('marketing') ? 'marketing' : (activeRole || 'marketing')));
  } else if (isCreatorEndpoint) {
    headers.set('X-Workspace-Role', isUserAdmin ? (activeRole === 'creator' ? 'creator' : 'admin') : (userPermittedRoles.includes('creator') ? 'creator' : (activeRole || 'creator')));
  } else if (activeRole) {
    headers.set('X-Workspace-Role', activeRole);
  } else if (userPermittedRoles.length > 0) {
    headers.set('X-Workspace-Role', userPermittedRoles[0]);
  }

  if (!headers.has('X-Authorized-Roles')) {
    try {
      const storedUser = localStorage.getItem('creatoriq_user');
      if (storedUser) {
        const parsed = JSON.parse(storedUser);
        if (parsed.roles && Array.isArray(parsed.roles) && parsed.roles.length > 0) {
          headers.set('X-Authorized-Roles', parsed.roles.map((r: string) => normalizeRole(r) || r).join(','));
        }
      }
    } catch {
      // Ignore localStorage errors
    }
  }

  try {
    const response = await fetch(url, {
      ...options,
      headers
    });

    let data: any = {};
    const contentType = response.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
      data = await response.json();
    } else {
      const text = await response.text();
      // Handle HTML error pages gracefully (e.g., Cloud Run 403 Forbidden, Nginx, or proxy errors)
      if (text.includes('<!DOCTYPE') || text.includes('<html') || text.includes('<body') || text.includes('403 Forbidden')) {
        let extractedTitle = '';
        const titleMatch = text.match(/<title>([^<]+)<\/title>/i);
        const h1Match = text.match(/<h1>([^<]+)<\/h1>/i);
        if (titleMatch && titleMatch[1]) {
          extractedTitle = titleMatch[1].trim();
        } else if (h1Match && h1Match[1]) {
          extractedTitle = h1Match[1].trim();
        }

        if (response.status === 403) {
          data = { 
            message: `Access Forbidden (403): You do not have permission to access this endpoint. ${extractedTitle ? `[${extractedTitle}] ` : ''}Please switch to an authorized workspace or sign in with an account that has access.`
          };
        } else if (response.status === 401) {
          data = { 
            message: 'Session Expired (401): Your authentication token has expired or is invalid. Please sign in again.' 
          };
        } else {
          data = { 
            message: `HTTP ${response.status}: ${extractedTitle || 'The server returned an error page.'}` 
          };
        }
      } else {
        data = { message: text };
      }
    }

    if (!response.ok) {
      let errorMessage = data?.message || `Request failed with status ${response.status}`;
      // Strip any residual HTML markup if present
      if (typeof errorMessage === 'string' && errorMessage.includes('<') && errorMessage.includes('>')) {
        errorMessage = errorMessage.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
      }
      throw new ApiError(errorMessage, response.status, data, endpoint);
    }

    return data as T;
  } catch (error: any) {
    if (error instanceof ApiError) {
      throw error;
    }
    throw new ApiError(
      error.message || 'Unable to connect to the backend server. Please verify the API URL.',
      0,
      { error: error.message },
      endpoint
    );
  }
}

// Authentication Service
export const authService = {
  async register(payload: RegisterPayload): Promise<AuthResponse> {
    return apiFetch<AuthResponse>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async login(payload: LoginPayload): Promise<AuthResponse> {
    return apiFetch<AuthResponse>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async getMe(): Promise<{ success: boolean; user: User }> {
    return apiFetch<{ success: boolean; user: User }>('/auth/me');
  },

  async logout(): Promise<{ success: boolean; message: string }> {
    try {
      return await apiFetch<{ success: boolean; message: string }>('/auth/logout', {
        method: 'POST'
      });
    } catch {
      return { success: true, message: 'Logged out' };
    }
  },

  async switchWorkspace(role: UserRole): Promise<{ success: boolean; message: string; token: string; user: User }> {
    return apiFetch<{ success: boolean; message: string; token: string; user: User }>('/auth/switch-workspace', {
      method: 'POST',
      body: JSON.stringify({ role })
    });
  },

  async refreshToken(): Promise<{ success: boolean; token: string; user: User }> {
    return apiFetch<{ success: boolean; token: string; user: User }>('/auth/refresh', {
      method: 'POST'
    });
  },

  async forgotPassword(email: string): Promise<{
    success: boolean;
    message: string;
    email: string;
    expiresInMinutes: number;
    previewCode?: string;
    emailId?: string;
    deliveryStatus?: 'sent' | 'simulated';
  }> {
    return apiFetch('/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email })
    });
  },

  async verifyResetCode(email: string, code: string): Promise<{
    success: boolean;
    valid: boolean;
    message: string;
    token?: string;
  }> {
    return apiFetch('/auth/verify-reset-code', {
      method: 'POST',
      body: JSON.stringify({ email, code })
    });
  },

  async resetPassword(payload: {
    email: string;
    code?: string;
    token?: string;
    newPassword: string;
  }): Promise<{
    success: boolean;
    message: string;
    email: string;
    name?: string;
  }> {
    return apiFetch('/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async getSentEmails(email?: string): Promise<{
    success: boolean;
    emails: Array<{
      id: string;
      to: string;
      from: string;
      subject: string;
      code: string;
      token: string;
      html: string;
      text: string;
      sentAt: string;
      deliveryStatus: 'sent' | 'simulated';
    }>;
  }> {
    const query = email ? `?email=${encodeURIComponent(email)}` : '';
    return apiFetch(`/auth/sent-emails${query}`);
  },

  async setupGoogleProfile(payload: {
    name: string;
    username: string;
    roles?: UserRole[];
    bio?: string;
  }): Promise<{ success: boolean; message: string; token?: string; user: User }> {
    const res = await apiFetch<{ success: boolean; message: string; token?: string; user: User }>('/auth/profile/setup-google', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    if (res.token) {
      setToken(res.token);
    }
    return res;
  },

  async updateProfile(payload: {
    name?: string;
    username?: string;
    avatarUrl?: string;
    workspaceRole?: UserRole;
  }): Promise<{ success: boolean; message: string; user: User }> {
    return apiFetch<{ success: boolean; message: string; user: User }>('/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  },

  async startSession(): Promise<{ success: boolean; session: UserSession }> {
    return apiFetch<{ success: boolean; session: UserSession }>('/auth/session/start', {
      method: 'POST',
      body: JSON.stringify({})
    });
  },

  async heartbeatSession(sessionId: string, durationSeconds?: number): Promise<{ success: boolean; session: UserSession | null; last_activity: string; duration_seconds: number }> {
    return apiFetch<{ success: boolean; session: UserSession | null; last_activity: string; duration_seconds: number }>('/auth/session/heartbeat', {
      method: 'POST',
      body: JSON.stringify({ sessionId, durationSeconds })
    });
  },

  async logoutSession(sessionId?: string, durationSeconds?: number): Promise<{ success: boolean; session?: UserSession; message: string }> {
    return apiFetch<{ success: boolean; session?: UserSession; message: string }>('/auth/session/logout', {
      method: 'POST',
      body: JSON.stringify({ sessionId, durationSeconds })
    });
  },

  sendSessionBeacon(sessionId: string, durationSeconds: number, reason: 'unexpected_close' | 'page_unload' = 'unexpected_close'): void {
    if (typeof window === 'undefined') return;
    const url = '/api/auth/session/beacon';
    const payload = JSON.stringify({ sessionId, durationSeconds, reason });
    if (navigator.sendBeacon) {
      const blob = new Blob([payload], { type: 'application/json' });
      navigator.sendBeacon(url, blob);
    } else {
      fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: payload,
        keepalive: true
      }).catch(() => {});
    }
  },

  async getCurrentSession(): Promise<{
    success: boolean;
    activeSession: UserSession | null;
    previousSession: UserSession | null;
    currentDurationSeconds: number;
    currentSessionStartedAt: string | null;
    lastActivityAt: string | null;
  }> {
    return apiFetch('/auth/sessions/current');
  },

  async getSessionHistory(userId?: number | string): Promise<{ success: boolean; count: number; sessions: UserSession[] }> {
    const q = userId ? `?userId=${encodeURIComponent(userId)}` : '';
    return apiFetch<{ success: boolean; count: number; sessions: UserSession[] }>(`/auth/sessions/history${q}`);
  }
};

// Creator Service
export const creatorService = {
  async getOverview(): Promise<{
    success: boolean;
    stats: {
      totalContentPublished: number;
      totalReach: number;
      totalImpressions: number;
      totalEngagement: number;
      totalFollowers: number;
      engagementRate: number;
      totalRevenue: number;
      followersGrowthRate: string;
      viewsGrowthRate: string;
    };
    profile?: CreatorProfile;
  }> {
    return apiFetch('/creator/overview');
  },

  async getContent(platform?: string, status?: string): Promise<{ success: boolean; count: number; content: ContentItem[] }> {
    const params = new URLSearchParams();
    if (platform && platform !== 'all') params.set('platform', platform);
    if (status && status !== 'all') params.set('status', status);
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiFetch(`/creator/content${query}`);
  },

  async createContent(payload: {
    title: string;
    platform: string;
    type?: string;
    status?: string;
    scheduledDate?: string;
  }): Promise<{ success: boolean; message: string; content: ContentItem }> {
    return apiFetch('/creator/content', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async deleteContent(id: number): Promise<{ success: boolean; message: string }> {
    return apiFetch(`/creator/content/${id}`, {
      method: 'DELETE'
    });
  },

  async getMyProfile(): Promise<{ success: boolean; profile: CreatorProfile; user: User }> {
    return apiFetch<{ success: boolean; profile: CreatorProfile; user: User }>('/creators/me');
  },

  async updateMyProfile(payload: ProfileUpdatePayload): Promise<{ success: boolean; message: string; profile: CreatorProfile; user: User }> {
    return apiFetch<{ success: boolean; message: string; profile: CreatorProfile; user: User }>('/creators/me', {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  },

  async listCreators(niche?: string, search?: string): Promise<{ success: boolean; count: number; creators: Array<{ user: User; profile: CreatorProfile | null }> }> {
    const params = new URLSearchParams();
    if (niche) params.set('niche', niche);
    if (search) params.set('q', search);
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiFetch<{ success: boolean; count: number; creators: Array<{ user: User; profile: CreatorProfile | null }> }>(`/creators${query}`);
  }
};

// Agency Service
export const agencyService = {
  async getDashboard(params: {
    range?: string;
    platform?: string;
    creatorId?: number | string;
  } = {}): Promise<{ success: boolean; data: AgencyDashboardData }> {
    const sp = new URLSearchParams();
    if (params.range) sp.set('range', params.range);
    if (params.platform) sp.set('platform', params.platform);
    if (params.creatorId) sp.set('creatorId', String(params.creatorId));
    const q = sp.toString() ? `?${sp.toString()}` : '';
    return apiFetch<{ success: boolean; data: AgencyDashboardData }>(`/agency/dashboard${q}`, {
      headers: {
        'X-Workspace-Role': 'agency'
      }
    });
  },

  async getAssignedCreators(): Promise<{ success: boolean; creators: any[] }> {
    return apiFetch('/agency/creators', {
      headers: {
        'X-Workspace-Role': 'agency'
      }
    });
  },

  async getOverview(): Promise<{
    success: boolean;
    stats: {
      totalCreators: number;
      totalFollowers: string;
      totalViews: string;
      activeCampaigns: number;
      totalRevenue: string;
      revenueGrowth: string;
    };
    profile?: any;
  }> {
    return apiFetch('/agency/overview', {
      headers: {
        'X-Workspace-Role': 'agency'
      }
    });
  },

  async getCampaigns(): Promise<{ success: boolean; campaigns: Campaign[] }> {
    return apiFetch('/agency/campaigns', {
      headers: {
        'X-Workspace-Role': 'agency'
      }
    });
  },

  async createCampaign(payload: Partial<Campaign> & {
    title: string;
    clientOrBrand?: string;
    brand?: string;
    budget: number;
    deliverables?: string;
    startDate?: string;
    endDate?: string;
    assignedCreators?: string[];
  }): Promise<{ success: boolean; message: string; campaign: Campaign }> {
    return apiFetch('/agency/campaigns', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async updateCampaign(id: number, payload: {
    status?: string;
    spend?: number;
    budget?: number;
  }): Promise<{ success: boolean; message: string; campaign: Campaign }> {
    return apiFetch(`/agency/campaigns/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  },

  async getCreators(): Promise<{
    success: boolean;
    count: number;
    creators: Array<{
      id: number;
      name: string;
      handle: string;
      followers: string;
      niche: string;
      engagement: string;
      rate: string;
      status: string;
      activeCampaigns: number;
    }>;
  }> {
    return apiFetch('/agency/creators');
  },

  async getTasks(): Promise<{ success: boolean; tasks: TaskItem[] }> {
    return apiFetch('/agency/tasks');
  },

  async createTask(payload: {
    title: string;
    campaignId?: number;
    campaignTitle?: string;
    assignee?: string;
    dueDate?: string;
    priority?: string;
  }): Promise<{ success: boolean; message: string; task: TaskItem }> {
    return apiFetch('/agency/tasks', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async toggleTask(id: number): Promise<{ success: boolean; message: string; task: TaskItem }> {
    return apiFetch(`/agency/tasks/${id}/toggle`, {
      method: 'PUT'
    });
  }
};

// Marketing Service
export const marketingService = {
  async getDashboard(params: {
    range?: string;
    platform?: string;
  } = {}): Promise<{ success: boolean; data: MarketingDashboardData }> {
    const sp = new URLSearchParams();
    if (params.range) sp.set('range', params.range);
    if (params.platform) sp.set('platform', params.platform);
    const q = sp.toString() ? `?${sp.toString()}` : '';
    return apiFetch<{ success: boolean; data: MarketingDashboardData }>(`/marketing/dashboard${q}`, {
      headers: {
        'X-Workspace-Role': 'marketing'
      }
    });
  },

  async getOverview(): Promise<{
    success: boolean;
    stats: {
      totalCampaigns: number;
      activeCampaigns: number;
      totalReach: string;
      totalEngagement: string;
      totalSpend: string;
      roi: string;
      reachGrowth: string;
      engagementGrowth: string;
    };
    profile?: any;
  }> {
    return apiFetch('/marketing/overview');
  },

  async getCampaigns(): Promise<{ success: boolean; campaigns: Campaign[] }> {
    return apiFetch('/agency/campaigns');
  },

  async createCampaign(payload: Partial<Campaign> & {
    title: string;
    clientOrBrand?: string;
    brand?: string;
    budget: number;
    deliverables?: string;
    startDate?: string;
    endDate?: string;
    assignedCreators?: string[];
  }): Promise<{ success: boolean; message: string; campaign: Campaign }> {
    return apiFetch('/marketing/campaigns', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async getAudience(): Promise<{
    success: boolean;
    demographics: {
      age: Array<{ segment: string; pct: number; color: string }>;
      gender: Array<{ segment: string; pct: number; color: string }>;
      locations: Array<{ country: string; pct: number; users: string }>;
    };
  }> {
    return apiFetch('/marketing/audience');
  }
};

// Unified Profile Service
export const profileService = {
  async getMyProfile(): Promise<{
    success: boolean;
    user: User;
    role: UserRole;
    personal: PersonalDetails;
    professional: any;
  }> {
    return apiFetch('/profile/me');
  },

  async updateMyProfile(payload: {
    name?: string;
    avatarUrl?: string;
    workspaceRole?: UserRole;
    personal?: PersonalDetails;
    professional?: any;
  }): Promise<{
    success: boolean;
    message: string;
    user: User;
    personal: PersonalDetails;
    professional: any;
  }> {
    return apiFetch('/profile/me', {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  },

  async changePassword(payload: {
    currentPassword: string;
    newPassword: string;
  }): Promise<{ success: boolean; message: string }> {
    return apiFetch('/profile/change-password', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }
};

// Administrator Service
export const adminService = {
  async getUsers(role?: string, status?: string, search?: string): Promise<{ success: boolean; count: number; users: User[] }> {
    const params = new URLSearchParams();
    if (role && role !== 'all') params.set('role', role);
    if (status && status !== 'all') params.set('status', status);
    if (search) params.set('search', search);
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiFetch<{ success: boolean; count: number; users: User[] }>(`/admin/users${query}`);
  },

  async createUser(payload: { name: string; email: string; password?: string; role: string; status?: string }): Promise<{ success: boolean; message: string; user: User }> {
    return apiFetch<{ success: boolean; message: string; user: User }>('/admin/users', {
      method: 'POST',
      headers: {
        'X-Workspace-Role': 'admin'
      },
      body: JSON.stringify(payload)
    });
  },

  async updateUser(id: number | string, payload: AdminUserUpdatePayload): Promise<{ success: boolean; message: string; user: User }> {
    return apiFetch<{ success: boolean; message: string; user: User }>(`/admin/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  },

  async resetUserPassword(id: number | string, newPassword?: string): Promise<{ success: boolean; message: string; temporaryPassword?: string }> {
    return apiFetch(`/admin/users/${id}/reset-password`, {
      method: 'POST',
      body: JSON.stringify({ newPassword })
    });
  },

  async deleteUser(id: number | string): Promise<{ success: boolean; message: string }> {
    return apiFetch<{ success: boolean; message: string }>(`/admin/users/${id}`, {
      method: 'DELETE'
    });
  },

  async getStats(): Promise<{ success: boolean; stats: AdminStats; audit_logs: AuditLog[] }> {
    return apiFetch<{ success: boolean; stats: AdminStats; audit_logs: AuditLog[] }>('/admin/stats');
  },

  async getSettings(): Promise<{ success: boolean; settings: SystemSettings }> {
    return apiFetch('/admin/settings');
  },

  async updateSettings(payload: Partial<SystemSettings>): Promise<{ success: boolean; message: string; settings: SystemSettings }> {
    return apiFetch('/admin/settings', {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  },

  async getSystemHealth(): Promise<{ success: boolean; health: SystemHealthStatus }> {
    return apiFetch<{ success: boolean; health: SystemHealthStatus }>('/admin/system-health');
  },

  async getSocialSyncOverview(): Promise<{ 
    success: boolean; 
    totalConnected: number;
    platformBreakdown: Array<{ platform: SupportedPlatform; connectedCount: number; lastSyncedAt: string | null; status: string }>;
  }> {
    return apiFetch('/admin/social-sync-overview');
  }
};

// Notifications Service
export const notificationService = {
  async getNotifications(): Promise<{ success: boolean; notifications: NotificationItem[] }> {
    return apiFetch('/notifications');
  },

  async markAllRead(): Promise<{ success: boolean; message: string }> {
    return apiFetch('/notifications/mark-all-read', {
      method: 'POST'
    });
  }
};

// Health & System Service
export const healthService = {
  async checkHealth(targetBaseUrl?: string): Promise<{
    ok: boolean;
    data?: any;
    latencyMs?: number;
    error?: string;
  }> {
    const start = performance.now();
    const baseUrl = (targetBaseUrl || getApiBaseUrl()).replace(/\/$/, '');
    const url = `${baseUrl}/health`;

    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
      });
      const latencyMs = Math.round(performance.now() - start);

      if (!response.ok) {
        return { ok: false, error: `HTTP ${response.status}`, latencyMs };
      }

      const data = await response.json();
      return { ok: true, data, latencyMs };
    } catch (err: any) {
      const latencyMs = Math.round(performance.now() - start);
      return { ok: false, error: err.message || 'Connection refused', latencyMs };
    }
  }
};

// YouTube Integration & Content Analytics Service
export const youtubeService = {
  async getStatus(): Promise<{
    success: boolean;
    connected: boolean;
    channel: any;
    config: {
      hasClientId: boolean;
      hasClientSecret: boolean;
      hasApiKey: boolean;
      configured: boolean;
    };
  }> {
    return apiFetch('/youtube/status');
  },

  async getAuthUrl(): Promise<{
    success: boolean;
    configured: boolean;
    authorization_url: string | null;
    message?: string;
    redirect_uri: string;
  }> {
    return apiFetch('/youtube/auth-url');
  },

  async handleCallback(code: string, redirectUri?: string): Promise<{
    success: boolean;
    message: string;
    channel?: any;
  }> {
    return apiFetch('/youtube/callback', {
      method: 'POST',
      body: JSON.stringify({ code, redirectUri })
    });
  },

  async connectChannel(handleOrId: string, title?: string): Promise<{
    success: boolean;
    message: string;
    channel: any;
  }> {
    return apiFetch('/youtube/connect-channel', {
      method: 'POST',
      body: JSON.stringify({ channelHandleOrId: handleOrId, channelTitle: title })
    });
  },

  async sync(): Promise<{
    success: boolean;
    message: string;
    lastSyncedAt: string;
    stats?: any;
  }> {
    return apiFetch('/youtube/sync', {
      method: 'POST'
    });
  },

  async getAnalytics(params: string | { range?: string; startDate?: string; endDate?: string } = '28d'): Promise<YouTubeAnalyticsResponse> {
    let query = '';
    if (typeof params === 'string') {
      query = `?range=${encodeURIComponent(params)}`;
    } else {
      const sp = new URLSearchParams();
      if (params.range) sp.set('range', params.range);
      if (params.startDate) sp.set('startDate', params.startDate);
      if (params.endDate) sp.set('endDate', params.endDate);
      query = sp.toString() ? `?${sp.toString()}` : '';
    }
    return apiFetch<YouTubeAnalyticsResponse>(`/youtube/analytics${query}`);
  },

  async getVideos(params: {
    search?: string;
    sortBy?: string;
    order?: 'asc' | 'desc';
    range?: string;
    page?: number;
    limit?: number;
  } = {}): Promise<{
    success: boolean;
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    videos: any[];
  }> {
    const sp = new URLSearchParams();
    if (params.search) sp.set('search', params.search);
    if (params.sortBy) sp.set('sortBy', params.sortBy);
    if (params.order) sp.set('order', params.order);
    if (params.range) sp.set('range', params.range);
    if (params.page) sp.set('page', String(params.page));
    if (params.limit) sp.set('limit', String(params.limit));
    const query = sp.toString() ? `?${sp.toString()}` : '';
    return apiFetch(`/youtube/videos${query}`);
  },

  async compareVideos(video1: string, video2: string): Promise<{
    success: boolean;
    comparison: {
      video1: any;
      video2: any;
      diff: {
        views: number;
        likes: number;
        comments: number;
        shares: number;
        engagementRate: number;
      };
      winner: {
        views: string;
        engagementRate: string;
        likes: string;
      };
    };
  }> {
    return apiFetch(`/youtube/videos/compare?video1=${encodeURIComponent(video1)}&video2=${encodeURIComponent(video2)}`);
  },

  async disconnect(): Promise<{ success: boolean; message: string }> {
    return apiFetch('/youtube/disconnect', {
      method: 'POST'
    });
  }
};

// Dedicated Creator Audience Analytics Service
export const analyticsService = {
  async getHistoricalAudience(params: { range?: string; platform?: string } = {}): Promise<{
    success: boolean;
    creator_id: number;
    creator_name: string;
    creator_handle: string;
    platform: string;
    range: string;
    cutoff_date: string;
    total_snapshots: number;
    connected_platforms: Array<{
      id: number;
      platform: string;
      channel_id: string;
      channel_title: string;
      channel_handle?: string;
      subscriber_count: number;
      view_count: number;
      status: string;
      last_synced_at?: string;
    }>;
    snapshots: Array<{
      id: number;
      user_id: number;
      platform: string;
      snapshot_date: string;
      subscribers: number;
      total_views: number;
      total_likes: number;
      total_comments: number;
      total_shares: number;
      avg_engagement_rate: number;
      video_count: number;
    }>;
    summary: {
      latest_subscribers: number;
      net_growth: number;
      percentage_growth: number;
      avg_engagement_rate: number;
    };
  }> {
    const sp = new URLSearchParams();
    if (params.range) sp.set('range', params.range);
    if (params.platform) sp.set('platform', params.platform);
    const query = sp.toString() ? `?${sp.toString()}` : '';
    return apiFetch(`/analytics/historical-audience${query}`);
  }
};

// ==========================================
// Modular Social Media Platforms Integration Service
// Covers: YouTube, TikTok, Instagram, Facebook, WhatsApp, Snapchat, X, LinkedIn
// ==========================================
export const socialService = {
  async getPlatforms(): Promise<{ success: boolean; platforms: PlatformDeveloperConfig[] }> {
    return apiFetch<{ success: boolean; platforms: PlatformDeveloperConfig[] }>('/social/platforms');
  },

  async getAuthUrl(platform: SupportedPlatform): Promise<OAuthUrlResponse> {
    return apiFetch<OAuthUrlResponse>(`/oauth/${platform}/auth-url`);
  },

  async getConnectedAccounts(): Promise<{ 
    success: boolean; 
    accounts: ConnectedPlatformAccount[];
    summary: {
      totalConnected: number;
      totalFollowers: number;
      lastSyncedAt: string | null;
    }
  }> {
    return apiFetch('/social/accounts');
  },

  async connectAccount(platform: SupportedPlatform, data: {
    handleOrIdentifier: string;
    apiKeyOrToken?: string;
    accountName?: string;
    appSecret?: string;
  }): Promise<{ success: boolean; message: string; account: ConnectedPlatformAccount }> {
    return apiFetch(`/social/connect/${platform}`, {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  async disconnectAccount(platform: SupportedPlatform): Promise<{ success: boolean; message: string }> {
    return apiFetch(`/social/disconnect/${platform}`, {
      method: 'POST'
    });
  },

  async syncAccount(platform: SupportedPlatform): Promise<{ 
    success: boolean; 
    message: string; 
    account: ConnectedPlatformAccount;
    syncedAt: string;
  }> {
    return apiFetch(`/social/sync/${platform}`, {
      method: 'POST'
    });
  },

  async syncAll(): Promise<{ 
    success: boolean; 
    message: string; 
    syncedCount: number;
    accounts: ConnectedPlatformAccount[];
  }> {
    return apiFetch('/social/sync-all', {
      method: 'POST'
    });
  }
};

// ==========================================
// Global Social Media Statistics Service
// Real, authoritative worldwide benchmark data
// ==========================================
export const globalStatsService = {
  async getGlobalStats(): Promise<{ 
    success: boolean; 
    stats: GlobalSocialStat[];
    sourceMetadata: {
      methodology: string;
      lastVerified: string;
      citations: string[];
    }
  }> {
    return apiFetch('/analytics/global-social-stats');
  }
};

// ==========================================
// Dashboard Visit & Delta Tracking Service
// Tracks delta changes between visits accurately
// ==========================================
export const dashboardService = {
  async recordVisitAndSync(payload: {
    role: UserRole;
    currentMetrics: {
      primaryValue: number;
      primaryName: string;
      secondaryValue: number;
      secondaryName: string;
      tertiaryValue: number;
      tertiaryName: string;
    };
  }): Promise<DashboardDeltaRecord> {
    return apiFetch<DashboardDeltaRecord>('/dashboard/visit-sync', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async getDelta(role?: UserRole): Promise<DashboardDeltaRecord> {
    const q = role ? `?role=${encodeURIComponent(role)}` : '';
    return apiFetch<DashboardDeltaRecord>(`/dashboard/delta${q}`);
  }
};

