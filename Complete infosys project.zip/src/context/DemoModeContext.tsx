import React, { createContext, useContext, useState, useEffect } from 'react';

interface DemoModeContextType {
  isDemoMode: boolean;
  setIsDemoMode: (val: boolean) => void;
  toggleDemoMode: () => void;
}

const DemoModeContext = createContext<DemoModeContextType | undefined>(undefined);

export const DemoModeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Default to true (Demo Mode is default after login per requirement)
  const [isDemoMode, setIsDemoModeState] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('creatoriq_demo_mode');
      if (stored !== null) {
        return stored === 'true';
      }
    } catch {
      // ignore
    }
    return true; // Default to DEMO MODE
  });

  const setIsDemoMode = (val: boolean) => {
    setIsDemoModeState(val);
    try {
      localStorage.setItem('creatoriq_demo_mode', String(val));
    } catch {
      // ignore
    }
  };

  const toggleDemoMode = () => {
    setIsDemoMode(!isDemoMode);
  };

  return (
    <DemoModeContext.Provider value={{ isDemoMode, setIsDemoMode, toggleDemoMode }}>
      {children}
    </DemoModeContext.Provider>
  );
};

export const useDemoMode = (): DemoModeContextType => {
  const context = useContext(DemoModeContext);
  if (!context) {
    throw new Error('useDemoMode must be used within a DemoModeProvider');
  }
  return context;
};

// Reusable Environment Indicator Component (Clean, professional, anti-clutter)
export const DemoModeBadge: React.FC<{ className?: string; compact?: boolean }> = () => {
  // Clean presentation per Section 1: No visible DEMO MODE, SAMPLE DATA, MOCK DATA labels
  return null;
};

