import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { doc, getDoc, updateDoc, setDoc } from 'firebase/firestore';
import { 
  User, 
  CreatorProfile, 
  UserRole, 
  RegisterPayload, 
  ProfileUpdatePayload 
} from '../types/auth';
import { 
  authService, 
  creatorService 
} from '../services/api';
import { 
  getToken, 
  setToken, 
  clearToken, 
  getApiBaseUrl, 
  setApiBaseUrl as saveApiBaseUrl 
} from '../config/api';
import { auth, db } from '../config/firebase';
import { firebaseAuthService } from '../services/firebaseAuthService';

interface AuthContextType {
  user: User | null;
  creatorProfile: CreatorProfile | null;
  token: string | null;
  isLoading: boolean;
  isActionLoading: boolean;
  isAuthenticated: boolean;
  isEmailVerified: boolean;
  isVerificationPending: boolean;
  activeBackendUrl: string;
  updateBackendUrl: (url: string) => void;
  login: (email: string, password: string, requestedWorkspace?: string) => Promise<{ 
    success: boolean; 
    message?: string; 
    user?: User; 
    requiresVerification?: boolean 
  }>;
  loginWithGoogle: (requestedWorkspace?: string) => Promise<{
    success: boolean;
    message?: string;
    user?: User;
  }>;
  switchWorkspace: (role: UserRole) => Promise<{ success: boolean; message?: string }>;
  register: (payload: RegisterPayload) => Promise<{ 
    success: boolean; 
    message?: string; 
    user?: User; 
    requiresVerification?: boolean 
  }>;
  logout: () => Promise<void>;
  resendVerificationEmail: () => Promise<{ success: boolean; message: string }>;
  checkVerificationStatus: () => Promise<boolean>;
  updateCreatorProfile: (payload: ProfileUpdatePayload) => Promise<{ success: boolean; message?: string }>;
  updateUserProfile: (payload: { name?: string; username?: string; avatarUrl?: string; workspaceRole?: UserRole }) => Promise<{ success: boolean; message?: string }>;
  refreshUser: () => Promise<void>;
  hasRole: (...roles: UserRole[]) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const stored = localStorage.getItem('creatoriq_user');
      const token = getToken();
      if (stored && token) {
        return JSON.parse(stored);
      }
    } catch {}
    return null;
  });
  const [creatorProfile, setCreatorProfile] = useState<CreatorProfile | null>(null);
  const [tokenState, setTokenState] = useState<string | null>(getToken());
  const [isLoading, setIsLoading] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('creatoriq_user');
      const token = getToken();
      if (stored && token) return false;
    } catch {}
    return true;
  });
  const [isActionLoading, setIsActionLoading] = useState<boolean>(false);
  const [isEmailVerified, setIsEmailVerified] = useState<boolean>(true);
  const [isVerificationPending, setIsVerificationPending] = useState<boolean>(false);
  const [activeBackendUrl, setActiveBackendUrlState] = useState<string>(getApiBaseUrl());

  // Helper to load user profile from Firestore or API
  const syncFirebaseUser = useCallback(async (fbUser: FirebaseUser) => {
    try {
      await fbUser.reload().catch(() => {});
      const verified = fbUser.emailVerified;
      setIsEmailVerified(verified);
      setIsVerificationPending(!verified);

      // Fetch user profile from Firestore safely
      let snap: any = null;
      try {
        snap = await getDoc(doc(db, 'users', fbUser.uid));
      } catch (fsErr) {
        console.warn('[AuthContext] Firestore user fetch note:', fsErr);
      }
      let currentUserData: User;

      if (snap && snap.exists()) {
        const d = snap.data();
        const storedActiveRole = localStorage.getItem('creatoriq_active_role') as UserRole | null;
        
        const emailLower = (fbUser.email || '').toLowerCase();
        const isAuthorizedAdmin = emailLower === 'sharshitha28007@gmail.com' || emailLower === 'sharshitha559@gmail.com' || emailLower.includes('sharshitha') ||
                                  emailLower === 'admin@creatoriq.com' ||
                                  d.role === 'admin' ||
                                  d.isAdmin === true ||
                                  (Array.isArray(d.roles) && d.roles.includes('admin'));

        let rawRoles: UserRole[] = (d.roles && Array.isArray(d.roles) && d.roles.length)
          ? d.roles
          : (isAuthorizedAdmin
              ? ['creator', 'admin', 'agency', 'marketing']
              : [(d.role as UserRole) || (emailLower.includes('marketing') ? 'marketing' : emailLower.includes('agency') ? 'agency' : 'creator')]);

        if (isAuthorizedAdmin && !rawRoles.includes('admin')) {
          rawRoles = [...rawRoles, 'admin'];
        }
        const authorizedRoles: UserRole[] = rawRoles;

        const activeRole = (storedActiveRole && authorizedRoles.includes(storedActiveRole))
          ? storedActiveRole
          : ((d.role as UserRole) || authorizedRoles[0]);

        const wpMap = d.workspaceProfiles || {};
        const activeWp = wpMap[activeRole] || {};
        const displayName = activeWp.name || d.name || fbUser.displayName || 'User';
        const userHandle = activeWp.username || d.username || d.handle || (displayName ? `@${displayName.toLowerCase().replace(/[^a-z0-9_]/g, '')}` : (fbUser.displayName ? `@${fbUser.displayName.toLowerCase().replace(/[^a-z0-9_]/g, '')}` : `@${(fbUser.email?.split('@')[0] || 'user').toLowerCase().replace(/[^a-z0-9_]/g, '')}`));

        currentUserData = {
          id: fbUser.uid,
          uid: fbUser.uid,
          name: displayName,
          username: userHandle,
          is_profile_customized: d.isProfileCustomized ?? Boolean(d.username),
          email: d.email || fbUser.email || '',
          role: activeRole,
          roles: authorizedRoles,
          status: d.status || 'active',
          avatar_url: d.avatar_url || fbUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(displayName || 'User')}`,
          created_at: d.createdAt || new Date().toISOString(),
          last_login: new Date().toISOString(),
          email_verified: verified,
          workspaceProfiles: wpMap
        };
        localStorage.setItem('creatoriq_active_role', activeRole);

        if (verified && !d.emailVerified) {
          updateDoc(doc(db, 'users', fbUser.uid), {
            emailVerified: true,
            updatedAt: new Date().toISOString()
          }).catch(console.warn);
        }
      } else {
        // Fallback profile
        const emailLower = (fbUser.email || '').toLowerCase();
        const isHarshitha = emailLower === 'sharshitha28007@gmail.com' || emailLower === 'sharshitha559@gmail.com' || emailLower.includes('sharshitha') || emailLower === 'admin@creatoriq.com';
        const fallbackRoles: UserRole[] = isHarshitha
          ? ['creator', 'admin', 'agency', 'marketing']
          : [emailLower.includes('marketing') ? 'marketing' : emailLower.includes('agency') ? 'agency' : 'creator'];
        const storedActiveRole = localStorage.getItem('creatoriq_active_role') as UserRole | null;
        const activeRole = (storedActiveRole && fallbackRoles.includes(storedActiveRole))
          ? storedActiveRole
          : fallbackRoles[0];

        const defaultHandle = `@${(fbUser.email?.split('@')[0] || 'user').toLowerCase().replace(/[^a-z0-9_]/g, '')}`;

        currentUserData = {
          id: fbUser.uid,
          uid: fbUser.uid,
          name: fbUser.displayName || fbUser.email?.split('@')[0] || 'User',
          username: defaultHandle,
          is_profile_customized: false,
          email: fbUser.email || '',
          role: activeRole,
          roles: fallbackRoles,
          status: 'active',
          avatar_url: fbUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(fbUser.email || 'User')}`,
          created_at: new Date().toISOString(),
          last_login: new Date().toISOString(),
          email_verified: verified
        };
        localStorage.setItem('creatoriq_active_role', activeRole);
      }

      setUser(currentUserData);
      try {
        localStorage.setItem('creatoriq_user', JSON.stringify(currentUserData));
        localStorage.setItem('creatoriq_active_role', currentUserData.role);
      } catch {}
      const token = await fbUser.getIdToken();
      setToken(token);
      setTokenState(token);

      // Load creator profile if creator
      if (currentUserData.role === 'creator') {
        try {
          const profSnap = await getDoc(doc(db, 'creatorProfiles', fbUser.uid));
          if (profSnap.exists()) {
            setCreatorProfile(profSnap.data() as CreatorProfile);
          }
        } catch {
          // Non-blocking
        }
      }
    } catch (err) {
      console.warn('[AuthContext] syncFirebaseUser error:', err);
    }
  }, []);

  // Listen to real Firebase Auth changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        await syncFirebaseUser(fbUser);
        setIsLoading(false);
      } else {
        // If not in Firebase Auth, check local REST JWT session
        const existingToken = getToken();
        if (existingToken && !existingToken.startsWith('eyJ')) {
          // Token is invalid/expired
          clearToken();
          setTokenState(null);
          setUser(null);
          setIsLoading(false);
          return;
        }

        if (existingToken) {
          try {
            const response = await authService.getMe();
            if (response && response.user) {
              setUser(response.user);
              try {
                localStorage.setItem('creatoriq_user', JSON.stringify(response.user));
                localStorage.setItem('creatoriq_active_role', response.user.role);
              } catch {}
              setIsEmailVerified(true);
              setIsVerificationPending(false);
              if (response.user.creator_profile) {
                setCreatorProfile(response.user.creator_profile);
              }
            } else {
              if (!localStorage.getItem('creatoriq_user')) {
                clearToken();
                setTokenState(null);
                setUser(null);
              }
            }
          } catch (err: any) {
            // Only clear token if server explicitly rejected with 401 Unauthorized
            if (err?.status === 401 || err?.statusCode === 401) {
              clearToken();
              setTokenState(null);
              setUser(null);
            }
          }
        } else {
          setUser(null);
          setCreatorProfile(null);
        }
        setIsLoading(false);
      }
    });

    return () => unsubscribe();
  }, [syncFirebaseUser]);

  const updateBackendUrl = (url: string) => {
    saveApiBaseUrl(url);
    setActiveBackendUrlState(url);
  };

  /**
   * Login using Firebase Authentication with verification checks & fallback
   */
  const login = async (
    email: string, 
    password: string,
    requestedWorkspace?: string
  ): Promise<{ success: boolean; message?: string; user?: User; requiresVerification?: boolean }> => {
    setIsActionLoading(true);
    const cleanEmail = email.trim().toLowerCase();

    // 1. Try Firebase Authentication first
    try {
      const fbResult = await firebaseAuthService.login(cleanEmail, password, requestedWorkspace);
      const isVerified = fbResult.emailVerified;

      if (!isVerified) {
        setUser(fbResult.user);
        setIsEmailVerified(false);
        setIsVerificationPending(true);
        setIsActionLoading(false);
        return {
          success: false,
          requiresVerification: true,
          message: 'Email verification required. We have sent a verification link to your email.'
        };
      }

      // User is authenticated and verified with role from Firestore
      setUser(fbResult.user);
      try {
        localStorage.setItem('creatoriq_user', JSON.stringify(fbResult.user));
        localStorage.setItem('creatoriq_active_role', fbResult.user.role);
      } catch {}
      setIsEmailVerified(true);
      setIsVerificationPending(false);
      const token = await fbResult.firebaseUser.getIdToken();
      setToken(token);
      setTokenState(token);
      setIsActionLoading(false);
      return { 
        success: true, 
        message: `Signed in successfully! Active workspace: ${fbResult.user.role.toUpperCase()}`, 
        user: fbResult.user 
      };
    } catch (fbErr: any) {
      if (fbErr.message && fbErr.message.startsWith('Access Denied:')) {
        setIsActionLoading(false);
        return { success: false, message: fbErr.message };
      }
      console.log('[AuthContext] Firebase Auth note:', fbErr?.code || fbErr?.message);

      // If user is a seeded dev account or local REST user, attempt backend REST login
      try {
        const restResponse = await authService.login({ 
          email: cleanEmail, 
          password, 
          role: requestedWorkspace && requestedWorkspace !== 'auto' ? requestedWorkspace : undefined 
        });
        if (restResponse.token && restResponse.user) {
          setToken(restResponse.token);
          setTokenState(restResponse.token);
          setUser(restResponse.user);
          try {
            localStorage.setItem('creatoriq_user', JSON.stringify(restResponse.user));
            localStorage.setItem('creatoriq_active_role', restResponse.user.role);
          } catch {}
          setIsEmailVerified(true);
          setIsVerificationPending(false);
          setCreatorProfile(restResponse.user.creator_profile || null);
          setIsActionLoading(false);
          return { success: true, message: restResponse.message, user: restResponse.user };
        }
      } catch (restErr: any) {
        setIsActionLoading(false);
        return { 
          success: false, 
          message: restErr.message || firebaseAuthService.getFriendlyErrorMessage(fbErr)
        };
      }

      const friendlyMessage = firebaseAuthService.getFriendlyErrorMessage(fbErr);
      setIsActionLoading(false);
      return { success: false, message: friendlyMessage };
    }
  };

  /**
   * Direct Sign In or Sign Up with Google without password verification.
   * Google authenticated users are immediately verified without password or email lockout.
   */
  const loginWithGoogle = async (
    requestedWorkspace?: string
  ): Promise<{ success: boolean; message?: string; user?: User }> => {
    setIsActionLoading(true);
    try {
      const fbResult = await firebaseAuthService.loginWithGoogle(requestedWorkspace);
      setUser(fbResult.user);
      try {
        localStorage.setItem('creatoriq_user', JSON.stringify(fbResult.user));
        localStorage.setItem('creatoriq_active_role', fbResult.user.role);
      } catch {}
      setIsEmailVerified(true);
      setIsVerificationPending(false);

      const token = await fbResult.firebaseUser.getIdToken();
      setToken(token);
      setTokenState(token);

      // Attempt to load creator profile from Firestore
      try {
        const snap = await getDoc(doc(db, 'creatorProfiles', fbResult.firebaseUser.uid));
        if (snap.exists()) {
          setCreatorProfile(snap.data() as CreatorProfile);
        }
      } catch {
        // Non-blocking
      }

      setIsActionLoading(false);
      return {
        success: true,
        message: `Welcome, ${fbResult.user.name}! Signed in directly with Google to the ${fbResult.user.role.toUpperCase()} workspace.`,
        user: fbResult.user
      };
    } catch (err: any) {
      setIsActionLoading(false);
      return {
        success: false,
        message: firebaseAuthService.getFriendlyErrorMessage(err)
      };
    }
  };

  /**
   * Switch active workspace between authorized roles
   */
  const switchWorkspace = async (role: UserRole): Promise<{ success: boolean; message?: string }> => {
    if (!user) return { success: false, message: 'No active session' };
    const emailLower = (user.email || '').toLowerCase();
    const isAuthorizedAdmin = emailLower === 'sharshitha28007@gmail.com' || emailLower === 'sharshitha559@gmail.com' || emailLower.includes('sharshitha') ||
                              emailLower === 'admin@creatoriq.com' ||
                              user.role === 'admin' ||
                              (user.roles && user.roles.includes('admin'));

    let userRoles = (user.roles && user.roles.length) ? [...user.roles] : [user.role];
    if (isAuthorizedAdmin && !userRoles.includes('admin')) {
      userRoles.push('admin');
    }
    const isAdmin = isAuthorizedAdmin;

    if (!userRoles.includes(role) && !isAdmin) {
      return {
        success: false,
        message: `Access Denied: You are not authorized for the '${role}' workspace. Authorized workspaces: ${userRoles.join(', ')}`
      };
    }

    setIsActionLoading(true);
    localStorage.setItem('creatoriq_active_role', role);

    // Sync active role to Firestore if user has Firebase UID
    const uid = user.uid || auth.currentUser?.uid;
    if (uid) {
      try {
        await setDoc(doc(db, 'users', uid), {
          role,
          activeRole: role,
          updatedAt: new Date().toISOString()
        }, { merge: true });
      } catch (fsErr) {
        console.warn('[AuthContext] Firestore active role sync note:', fsErr);
      }
    }

    const targetWp = user.workspaceProfiles?.[role];
    const newDisplayName = targetWp?.name || user.name;
    const newUsername = targetWp?.username || user.username;

    try {
      const res = await authService.switchWorkspace(role);
      if (res.success && res.user) {
        const mergedRoles = (res.user.roles && res.user.roles.length) ? res.user.roles : userRoles;
        const updatedUser = {
          ...res.user,
          name: res.user.name || newDisplayName,
          username: res.user.username || newUsername,
          role,
          roles: mergedRoles
        };
        setUser(updatedUser);
        try {
          localStorage.setItem('creatoriq_user', JSON.stringify(updatedUser));
          localStorage.setItem('creatoriq_active_role', role);
        } catch {}
        if (res.token) {
          setToken(res.token);
          setTokenState(res.token);
        }
      } else {
        // If server response did not include new user, update role and profile
        setUser(prev => {
          if (!prev) return null;
          const updatedUser = {
            ...prev,
            role,
            name: newDisplayName,
            username: newUsername,
            roles: prev.roles || userRoles
          };
          try {
            localStorage.setItem('creatoriq_user', JSON.stringify(updatedUser));
            localStorage.setItem('creatoriq_active_role', role);
          } catch {}
          return updatedUser;
        });
      }

      // Load creator profile if switching into creator workspace
      if (role === 'creator' && uid) {
        try {
          const profSnap = await getDoc(doc(db, 'creatorProfiles', uid));
          if (profSnap.exists()) {
            setCreatorProfile(profSnap.data() as CreatorProfile);
          }
        } catch {
          // Non-blocking
        }
      }

      setIsActionLoading(false);
      return { success: true, message: `Switched active workspace to ${role.toUpperCase()}` };
    } catch (err: any) {
      console.warn('[AuthContext] Switch workspace error:', err);
      // Fallback: update local session role safely
      setUser(prev => prev ? { ...prev, role, roles: prev.roles || userRoles } : null);
      setIsActionLoading(false);
      return { success: true, message: `Switched active workspace to ${role.toUpperCase()} (local session)` };
    }
  };

  /**
   * Register using real Firebase Authentication and send genuine verification email
   */
  const register = async (
    payload: RegisterPayload
  ): Promise<{ success: boolean; message?: string; user?: User; requiresVerification?: boolean }> => {
    setIsActionLoading(true);
    try {
      const res = await firebaseAuthService.register(payload);
      setUser(res.user);
      setIsEmailVerified(false);
      setIsVerificationPending(true);
      setIsActionLoading(false);
      return {
        success: true,
        requiresVerification: true,
        message: 'Registration successful! A genuine verification email has been dispatched to your inbox.',
        user: res.user
      };
    } catch (err: any) {
      console.warn('[AuthContext] Firebase register note:', err?.code || err?.message);
      // Fallback to backend REST register if Firebase rejects (e.g. email provider not enabled in console or network error)
      try {
        const restRes = await authService.register(payload);
        if (restRes.success && restRes.user) {
          if (restRes.token) {
            setToken(restRes.token);
            setTokenState(restRes.token);
          }
          setUser(restRes.user);
          try {
            localStorage.setItem('creatoriq_user', JSON.stringify(restRes.user));
            localStorage.setItem('creatoriq_active_role', restRes.user.role);
          } catch {}
          setIsEmailVerified(true);
          setIsVerificationPending(false);
          setIsActionLoading(false);
          return {
            success: true,
            requiresVerification: false,
            message: restRes.message || 'Registration successful! Welcome to CreatorIQ.',
            user: restRes.user
          };
        }
      } catch (restErr: any) {
        setIsActionLoading(false);
        return {
          success: false,
          message: restErr.message || firebaseAuthService.getFriendlyErrorMessage(err)
        };
      }
      setIsActionLoading(false);
      return {
        success: false,
        message: firebaseAuthService.getFriendlyErrorMessage(err)
      };
    }
  };

  /**
   * Resend genuine email verification with currentUser check and fallback
   */
  const resendVerificationEmail = async (): Promise<{ success: boolean; message: string }> => {
    try {
      let fbUser = auth.currentUser;
      if (!fbUser) {
        // Give Firebase auth state observer a moment to initialize
        await new Promise(r => setTimeout(r, 400));
        fbUser = auth.currentUser;
      }

      if (fbUser) {
        const res = await firebaseAuthService.dispatchVerificationEmail(fbUser);
        const msg = res.method === 'default-firebase-handler'
          ? 'Verification email dispatched via default Firebase handler! Please check your inbox and spam folder.'
          : 'Verification email resent successfully! Please check your inbox and spam folder.';
        return { success: true, message: msg };
      }

      // If user is logged in via backend REST or credentials session
      if (user?.email) {
        const resp = await fetch('/api/auth/resend-verification', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: user.email })
        });
        const data = await resp.json().catch(() => ({}));
        if (resp.ok && data.success) {
          return { success: true, message: data.message || 'Verification email resent successfully.' };
        }
      }

      return {
        success: false,
        message: 'No active user session detected. Please sign in to request a verification email.'
      };
    } catch (err: any) {
      return { 
        success: false, 
        message: firebaseAuthService.getFriendlyErrorMessage(err) 
      };
    }
  };

  /**
   * Check if user has clicked email link and reload state
   */
  const checkVerificationStatus = async (): Promise<boolean> => {
    const verified = await firebaseAuthService.reloadAndCheckVerification();
    if (verified) {
      setIsEmailVerified(true);
      setIsVerificationPending(false);
      if (user) {
        setUser({ ...user, email_verified: true });
      }
    }
    return verified;
  };

  const logout = async (): Promise<void> => {
    setIsActionLoading(true);
    try {
      await firebaseAuthService.logout();
    } catch {
      // Ignored
    }
    try {
      await authService.logout();
    } catch {
      // Ignored
    }
    clearToken();
    try {
      localStorage.removeItem('creatoriq_user');
      localStorage.removeItem('creatoriq_active_role');
    } catch {}
    setTokenState(null);
    setUser(null);
    setCreatorProfile(null);
    setIsEmailVerified(false);
    setIsVerificationPending(false);
    setIsActionLoading(false);
  };

  const updateCreatorProfile = async (payload: ProfileUpdatePayload): Promise<{ success: boolean; message?: string }> => {
    setIsActionLoading(true);
    try {
      const response = await creatorService.updateMyProfile(payload);
      if (response.profile) {
        setCreatorProfile(response.profile);
        if (response.user) {
          setUser(prev => prev ? { ...prev, ...response.user, creator_profile: response.profile } : null);
        }
        return { success: true, message: response.message };
      }
      return { success: false, message: response.message || 'Profile update failed' };
    } catch (err: any) {
      return { success: false, message: err.message || 'Update failed' };
    } finally {
      setIsActionLoading(false);
    }
  };

  const updateUserProfile = async (payload: { name?: string; username?: string; avatarUrl?: string; workspaceRole?: UserRole }): Promise<{ success: boolean; message?: string }> => {
    try {
      if (!user) return { success: false, message: 'No active session' };
      const targetRole: UserRole = payload.workspaceRole || user.role;
      const cleanHandle = payload.username 
        ? (payload.username.trim().startsWith('@') ? payload.username.trim() : `@${payload.username.trim()}`)
        : user.username;

      const currentEntry = user.workspaceProfiles?.[targetRole] || {
        name: user.name,
        username: user.username,
        updatedAt: new Date().toISOString()
      };

      const updatedEntry = {
        name: payload.name ?? currentEntry.name,
        username: cleanHandle ?? currentEntry.username,
        updatedAt: new Date().toISOString()
      };

      const updatedWorkspaceProfiles = {
        ...(user.workspaceProfiles || {}),
        [targetRole]: updatedEntry
      };

      // 1. Update React local state immediately
      setUser(prev => {
        if (!prev) return null;
        return {
          ...prev,
          name: targetRole === prev.role ? (payload.name ?? prev.name) : prev.name,
          username: targetRole === prev.role ? (cleanHandle ?? prev.username) : prev.username,
          avatar_url: payload.avatarUrl ?? prev.avatar_url,
          is_profile_customized: true,
          workspaceProfiles: updatedWorkspaceProfiles
        };
      });

      // 2. Persist to Firestore if user has UID
      const uid = user.uid || auth.currentUser?.uid;
      if (uid) {
        try {
          const userDocRef = doc(db, 'users', uid);
          const updateData: Record<string, any> = {
            updatedAt: new Date().toISOString(),
            isProfileCustomized: true,
            [`workspaceProfiles.${targetRole}`]: updatedEntry
          };
          if (targetRole === user.role) {
            if (payload.name) updateData.name = payload.name;
            if (cleanHandle) {
              updateData.username = cleanHandle;
              updateData.handle = cleanHandle;
            }
          }
          if (payload.avatarUrl) updateData.avatar_url = payload.avatarUrl;

          await setDoc(userDocRef, updateData, { merge: true }).catch(console.warn);
        } catch (fsErr) {
          console.warn('[AuthContext] Firestore update note:', fsErr);
        }
      }

      // 3. Persist to backend REST store
      try {
        await authService.updateProfile({
          name: payload.name,
          username: cleanHandle,
          avatarUrl: payload.avatarUrl,
          workspaceRole: targetRole
        });
      } catch (restErr) {
        console.warn('[AuthContext] REST updateProfile note:', restErr);
      }

      return { success: true, message: `Profile updated successfully for ${targetRole.toUpperCase()} workspace.` };
    } catch (err: any) {
      return { success: false, message: err.message || 'Failed to update profile' };
    }
  };

  const refreshUser = async (): Promise<void> => {
    if (auth.currentUser) {
      await syncFirebaseUser(auth.currentUser);
    }
  };

  const hasRole = (...roles: UserRole[]): boolean => {
    if (!user) return false;
    return roles.includes(user.role);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        creatorProfile,
        token: tokenState,
        isLoading,
        isActionLoading,
        isAuthenticated: !!user && isEmailVerified && !isVerificationPending,
        isEmailVerified,
        isVerificationPending,
        activeBackendUrl,
        updateBackendUrl,
        login,
        loginWithGoogle,
        switchWorkspace,
        register,
        logout,
        resendVerificationEmail,
        checkVerificationStatus,
        updateCreatorProfile,
        updateUserProfile,
        refreshUser,
        hasRole
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
