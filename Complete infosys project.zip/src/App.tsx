import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DemoModeProvider } from './context/DemoModeContext';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { ToastContainer, ToastMessage } from './components/common/Toast';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { LoginPage } from './pages/auth/LoginPage';
import { RegisterPage } from './pages/auth/RegisterPage';
import { ResetPasswordPage } from './pages/auth/ResetPasswordPage';
import { CreatorDashboardPage } from './pages/creator/CreatorDashboardPage';
import { CreatorProfileViewPage } from './pages/creator/CreatorProfileViewPage';
import { CreatorProfileEditPage } from './pages/creator/CreatorProfileEditPage';
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';
import { AdminUserManagementPage } from './pages/admin/AdminUserManagementPage';
import { AgencyDashboardPage } from './pages/agency/AgencyDashboardPage';
import { MarketingDashboardPage } from './pages/marketing/MarketingDashboardPage';
import { MyProfilePage } from './pages/profile/MyProfilePage';
import { UnauthorizedPage } from './pages/common/UnauthorizedPage';
import { ContentPage } from './pages/common/ContentPage';
import { AnalyticsPage } from './pages/common/AnalyticsPage';
import { CampaignsPage } from './pages/common/CampaignsPage';
import { ReportsPage } from './pages/common/ReportsPage';
import { SettingsPage } from './pages/common/SettingsPage';
import { EmailVerificationPrompt } from './components/auth/EmailVerificationPrompt';
import { SocialAccountsManager } from './components/analytics/SocialAccountsManager';
import { GlobalSocialStatsSection } from './components/analytics/GlobalSocialStatsSection';
import { 
  RefreshCw, 
  Sparkles, 
  Share2, 
  Youtube, 
  Instagram, 
  Video, 
  Linkedin, 
  CheckCircle2, 
  FileText, 
  Download, 
  Bell, 
  Check, 
  ArrowLeft,
  IndianRupee 
} from 'lucide-react';

const AppContent: React.FC = () => {
  const { user, isAuthenticated, isLoading, isVerificationPending, isEmailVerified } = useAuth();
  const [currentPage, setCurrentPage] = useState<string>('login');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Header Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDateRange, setSelectedDateRange] = useState('30d');
  const [selectedPlatform, setSelectedPlatform] = useState('all');

  // Toast dispatch helper
  const showToast = (message: string, type: 'success' | 'error' | 'info') => {
    const id = Math.random().toString(36).substring(7);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4500);
  };

  const dismissToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Check URL query parameters for reset token or Firebase action links
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (
      params.get('page') === 'reset-password' || 
      params.get('page') === 'forgot-password' || 
      params.get('mode') === 'resetPassword' || 
      params.get('mode') === 'verifyEmail' || 
      params.has('oobCode') || 
      params.has('token') || 
      params.has('reset_token')
    ) {
      setCurrentPage('reset-password');
    }
  }, []);

  // Route & redirect synchronization
  useEffect(() => {
    if (!isLoading) {
      if (!isAuthenticated) {
        if (
          currentPage !== 'register' && 
          currentPage !== 'login' && 
          currentPage !== 'reset-password' && 
          currentPage !== 'forgot-password'
        ) {
          setCurrentPage('login');
        }
      } else {
        if (currentPage === 'login' || currentPage === 'register') {
          setCurrentPage('dashboard');
        }
      }
    }
  }, [isAuthenticated, isLoading, user?.role, currentPage]);

  // Synchronize document title with active workspace role & page
  useEffect(() => {
    const roleLabel = user?.role 
      ? (user.role === 'admin' ? 'Administrator' : user.role === 'marketing' ? 'Marketing Team' : user.role === 'agency' ? 'Growth Agency' : 'Creator')
      : 'CreatorIQ';
    const pageLabel = currentPage === 'dashboard' 
      ? 'Dashboard' 
      : currentPage.charAt(0).toUpperCase() + currentPage.slice(1).replace(/-/g, ' ');
    document.title = `${roleLabel} - ${pageLabel} | CreatorHub`;
  }, [user?.role, currentPage]);

  // Loading state during initial session verification
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-purple-50/50 text-slate-800">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-700 via-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-xl shadow-purple-500/25 mb-4 animate-bounce">
          <Sparkles className="w-7 h-7" />
        </div>
        <div className="flex items-center space-x-2 text-sm font-bold text-purple-900">
          <RefreshCw className="w-4 h-4 animate-spin text-purple-600" />
          <span>Verifying CreatorIQ JWT Authentication...</span>
        </div>
        <p className="text-xs text-slate-400 mt-1">Connecting to Backend REST API</p>
      </div>
    );
  }

  // Render role-appropriate dashboard view
  const renderDashboardByRole = () => {
    if (!user) return <LoginPage onNavigate={setCurrentPage} onShowToast={showToast} />;

    switch (user.role) {
      case 'creator':
        return (
          <CreatorDashboardPage 
            onNavigate={setCurrentPage} 
            searchQuery={searchQuery}
            selectedDateRange={selectedDateRange}
            selectedPlatform={selectedPlatform}
            currentNavSection={currentPage}
          />
        );
      case 'agency':
        return <AgencyDashboardPage onNavigate={setCurrentPage} />;
      case 'marketing':
        return <MarketingDashboardPage onNavigate={setCurrentPage} />;
      case 'admin':
        return <AdminDashboardPage onNavigate={setCurrentPage} onShowToast={showToast} />;
      default:
        return (
          <CreatorDashboardPage 
            onNavigate={setCurrentPage} 
            searchQuery={searchQuery}
            selectedDateRange={selectedDateRange}
            selectedPlatform={selectedPlatform}
            currentNavSection={currentPage}
          />
        );
    }
  };

  // Render main page
  const renderPage = () => {
    // Action code links (password reset, email verify) always take precedence
    if (currentPage === 'reset-password' || currentPage === 'forgot-password') {
      return <ResetPasswordPage onNavigate={setCurrentPage} onShowToast={showToast} initialEmail={user?.email} />;
    }

    // If user is authenticated but email is unverified, block dashboards and display verification prompt!
    if (user && (!isEmailVerified || isVerificationPending)) {
      return <EmailVerificationPrompt onShowToast={showToast} />;
    }

    // Public unauthenticated pages
    if (!isAuthenticated) {
      if (currentPage === 'register') {
        return <RegisterPage onNavigate={setCurrentPage} onShowToast={showToast} />;
      }
      return <LoginPage onNavigate={setCurrentPage} onShowToast={showToast} />;
    }

    // Authenticated pages
    switch (currentPage) {
      case 'dashboard':
        return renderDashboardByRole();

      case 'my-profile':
      case 'profile-view':
      case 'profile-edit':
        return <MyProfilePage onNavigate={setCurrentPage} onShowToast={showToast} />;

      case 'settings':
      case 'system-settings':
        return <SettingsPage onNavigate={setCurrentPage} onShowToast={showToast} />;

      case 'content':
      case 'content-library':
      case 'content-monitoring':
        return <ContentPage onNavigate={setCurrentPage} onShowToast={showToast} />;

      case 'analytics':
      case 'analytics-overview':
      case 'audience':
      case 'revenue':
        return <AnalyticsPage onNavigate={setCurrentPage} onShowToast={showToast} />;

      case 'campaigns':
      case 'marketing-campaigns':
      case 'agency-campaigns':
      case 'brand-deals':
      case 'campaign-tracking':
      case 'campaign-hub':
        return <CampaignsPage onNavigate={setCurrentPage} onShowToast={showToast} />;

      case 'reports':
        return <ReportsPage onNavigate={setCurrentPage} onShowToast={showToast} />;

      case 'agency-creators':
      case 'talent-roster':
      case 'creator-discovery':
      case 'team-members':
        if (user?.role !== 'agency' && user?.role !== 'admin') {
          return <UnauthorizedPage requiredRoles={['Agency Team', 'Admin Team']} onNavigate={setCurrentPage} />;
        }
        return <AgencyDashboardPage onNavigate={setCurrentPage} />;

      case 'influencers':
      case 'creator-sourcing':
      case 'budget-roi':
        if (user?.role !== 'marketing' && user?.role !== 'admin') {
          return <UnauthorizedPage requiredRoles={['Marketing Team', 'Admin Team']} onNavigate={setCurrentPage} />;
        }
        return <MarketingDashboardPage onNavigate={setCurrentPage} />;

      case 'admin-dashboard':
        if (user?.role !== 'admin') {
          return <UnauthorizedPage requiredRoles={['Admin Team']} onNavigate={setCurrentPage} />;
        }
        return <AdminDashboardPage onNavigate={setCurrentPage} onShowToast={showToast} />;

      case 'admin-users':
      case 'admin-roles':
      case 'admin-audit':
      case 'activity-logs':
        if (user?.role !== 'admin') {
          return <UnauthorizedPage requiredRoles={['Admin Team']} onNavigate={setCurrentPage} />;
        }
        return <AdminUserManagementPage onShowToast={showToast} onNavigate={setCurrentPage} />;

      case 'agency-dashboard':
        if (user?.role !== 'agency' && user?.role !== 'admin') {
          return <UnauthorizedPage requiredRoles={['Agency Team', 'Admin Team']} onNavigate={setCurrentPage} />;
        }
        return <AgencyDashboardPage onNavigate={setCurrentPage} />;

      case 'marketing-dashboard':
        if (user?.role !== 'marketing' && user?.role !== 'admin') {
          return <UnauthorizedPage requiredRoles={['Marketing Team', 'Admin Team']} onNavigate={setCurrentPage} />;
        }
        return <MarketingDashboardPage onNavigate={setCurrentPage} />;

      case 'creator-dashboard':
      case 'creator-media-kit':
        if (user?.role !== 'creator' && user?.role !== 'admin') {
          return <UnauthorizedPage requiredRoles={['Creator Team', 'Admin Team']} onNavigate={setCurrentPage} />;
        }
        return currentPage === 'creator-media-kit'
          ? <CreatorProfileViewPage onNavigate={setCurrentPage} onShowToast={showToast} />
          : <CreatorDashboardPage 
              onNavigate={setCurrentPage} 
              searchQuery={searchQuery}
              selectedDateRange={selectedDateRange}
              selectedPlatform={selectedPlatform}
            />;

      case 'social-accounts':
      case 'platforms':
      case 'platform-integrations':
        return (
          <div className="space-y-6 max-w-6xl mx-auto pb-10">
            <div className="flex items-center justify-between pb-4 border-b border-purple-100">
              <div>
                <button
                  onClick={() => setCurrentPage('dashboard')}
                  className="inline-flex items-center space-x-1.5 text-xs font-semibold text-slate-500 hover:text-purple-700 transition-colors mb-2 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Return to Dashboard</span>
                </button>
                <h1 className="text-2xl font-black text-slate-900 tracking-tight">Social Media Platform Integrations</h1>
                <p className="text-xs text-slate-500">Live API integrations &amp; connection statuses across 8 creator platforms</p>
              </div>
            </div>

            <SocialAccountsManager onAccountSynced={() => showToast('Platform metrics synchronized!', 'success')} />
            <GlobalSocialStatsSection />
          </div>
        );

      case 'global-stats':
        return (
          <div className="space-y-6 max-w-6xl mx-auto pb-10">
            <div className="flex items-center justify-between pb-4 border-b border-purple-100">
              <div>
                <button
                  onClick={() => setCurrentPage('dashboard')}
                  className="inline-flex items-center space-x-1.5 text-xs font-semibold text-slate-500 hover:text-purple-700 transition-colors mb-2 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Return to Dashboard</span>
                </button>
                <h1 className="text-2xl font-black text-slate-900 tracking-tight">Global Social Media Statistics</h1>
                <p className="text-xs text-slate-500">Authoritative worldwide industry benchmarks from official corporate reports</p>
              </div>
            </div>

            <GlobalSocialStatsSection />
          </div>
        );

      case 'notifications':
        return (
          <div className="space-y-6 max-w-4xl mx-auto">
            <div className="flex items-center justify-between pb-4 border-b border-purple-100">
              <div>
                <button
                  onClick={() => setCurrentPage('dashboard')}
                  className="inline-flex items-center space-x-1.5 text-xs font-semibold text-slate-500 hover:text-purple-700 transition-colors mb-2 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Return to Dashboard</span>
                </button>
                <h1 className="text-2xl font-black text-slate-900 tracking-tight">Notifications Center</h1>
                <p className="text-xs text-slate-500">Real-time alerts for viral spikes, brand partnership offers, and system events</p>
              </div>
              <button
                onClick={() => showToast('All notifications marked as read.', 'success')}
                className="text-xs font-bold text-purple-700 hover:text-purple-900 bg-purple-50 px-3 py-1.5 rounded-xl border border-purple-100 cursor-pointer"
              >
                Mark All as Read
              </button>
            </div>

            <div className="space-y-2.5">
              <div className="p-4 rounded-2xl bg-white border border-emerald-100 shadow-xs flex items-start space-x-3.5">
                <span className="p-2 rounded-xl bg-emerald-50 text-emerald-600 shrink-0">
                  <Sparkles className="w-4 h-4" />
                </span>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-slate-900">Viral Engagement Alert on TikTok</h4>
                    <span className="text-[10px] text-slate-400 font-mono">15m ago</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    Your video "Day in the Life of a Full-Time Creative Technologist" passed 480K views with a 7.8% engagement rate!
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white border border-purple-100 shadow-xs flex items-start space-x-3.5">
                <span className="p-2 rounded-xl bg-purple-50 text-purple-700 shrink-0">
                  <IndianRupee className="w-4 h-4" />
                </span>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-slate-900">New Brand Sponsorship Proposal</h4>
                    <span className="text-[10px] text-slate-400 font-mono">2h ago</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    Synthetix AI offered a ₹2,85,000 dedicated integration for your upcoming YouTube camera gear review.
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      case 'reset-password':
      case 'forgot-password':
        return <ResetPasswordPage onNavigate={setCurrentPage} onShowToast={showToast} initialEmail={user?.email} />;

      default:
        return renderDashboardByRole();
    }
  };

  return (
    <div className="min-h-screen bg-[#f8f9fc] flex flex-col selection:bg-indigo-100 selection:text-indigo-950">
      {/* Top Navbar */}
      <Navbar 
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} 
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onShowToast={showToast}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedDateRange={selectedDateRange}
        onDateRangeChange={setSelectedDateRange}
        selectedPlatform={selectedPlatform}
        onPlatformChange={setSelectedPlatform}
      />

      <div className="flex-1 flex">
        {/* Role-Specific Sidebar (when logged in & verified) */}
        {isAuthenticated && isEmailVerified && !isVerificationPending && (
          <Sidebar
            currentPage={currentPage}
            onNavigate={setCurrentPage}
            isOpen={isSidebarOpen}
            onClose={() => setIsSidebarOpen(false)}
          />
        )}

        {/* Main Content Viewport */}
        <main className={`flex-1 transition-all duration-200 ${isAuthenticated && isEmailVerified && !isVerificationPending ? 'lg:pl-56' : ''}`}>
          <div className="p-3.5 sm:p-5 lg:p-6 max-w-[1600px] mx-auto">
            <ErrorBoundary fallbackTitle="Dashboard Display Error">
              {renderPage()}
            </ErrorBoundary>
          </div>
        </main>
      </div>

      {/* Toast Notification Stack */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary fallbackTitle="Application Error">
      <AuthProvider>
        <DemoModeProvider>
          <AppContent />
        </DemoModeProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
