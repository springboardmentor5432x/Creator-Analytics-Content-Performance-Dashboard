import { useEffect, useRef, useState, useCallback } from 'react';
import { User, UserSession } from '../types/auth';
import { authService } from '../services/api';

export function formatDuration(totalSeconds: number): string {
  if (totalSeconds < 0) totalSeconds = 0;
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (hours > 0) {
    return `${hours}h ${minutes}m ${seconds}s`;
  }
  if (minutes > 0) {
    return `${minutes}m ${seconds}s`;
  }
  return `${seconds}s`;
}

export function useSessionTracker(user: User | null) {
  const [activeSession, setActiveSession] = useState<UserSession | null>(null);
  const [durationSeconds, setDurationSeconds] = useState<number>(0);
  const [lastActivityAt, setLastActivityAt] = useState<string>(new Date().toISOString());

  const activeSessionRef = useRef<UserSession | null>(null);
  const durationRef = useRef<number>(0);
  const lastHeartbeatRef = useRef<number>(Date.now());
  const userRef = useRef<User | null>(user);

  userRef.current = user;
  activeSessionRef.current = activeSession;
  durationRef.current = durationSeconds;

  // 1. Initialize or resume session when user logs in
  useEffect(() => {
    if (!user) {
      setActiveSession(null);
      setDurationSeconds(0);
      return;
    }

    let isMounted = true;

    const initSession = async () => {
      try {
        // Try getting current active session
        const current = await authService.getCurrentSession().catch(() => null);
        if (!isMounted) return;

        if (current && current.activeSession) {
          setActiveSession(current.activeSession);
          const initialDuration = Math.max(
            current.currentDurationSeconds || 0,
            Math.floor((Date.now() - new Date(current.activeSession.login_time).getTime()) / 1000)
          );
          setDurationSeconds(initialDuration);
          durationRef.current = initialDuration;
          if (current.lastActivityAt) {
            setLastActivityAt(current.lastActivityAt);
          }
        } else {
          // Start brand new session on the server
          const started = await authService.startSession().catch(() => null);
          if (!isMounted) return;
          if (started && started.session) {
            setActiveSession(started.session);
            setDurationSeconds(0);
            durationRef.current = 0;
            setLastActivityAt(started.session.last_activity);
          }
        }
      } catch (err) {
        console.warn('[SessionTracker] Init session error:', err);
      }
    };

    initSession();

    return () => {
      isMounted = false;
    };
  }, [user?.id]);

  // 2. Local 1-second timer ticker
  useEffect(() => {
    if (!user || !activeSession) return;

    const timer = setInterval(() => {
      setDurationSeconds(prev => {
        const next = prev + 1;
        durationRef.current = next;
        return next;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [user, activeSession]);

  // 3. User activity listener (debounced)
  useEffect(() => {
    if (!user) return;

    let timeoutId: any = null;

    const handleUserActivity = () => {
      if (timeoutId) return;
      timeoutId = setTimeout(() => {
        const now = new Date().toISOString();
        setLastActivityAt(now);
        timeoutId = null;
      }, 5000); // Throttled to every 5s
    };

    window.addEventListener('mousemove', handleUserActivity, { passive: true });
    window.addEventListener('keydown', handleUserActivity, { passive: true });
    window.addEventListener('scroll', handleUserActivity, { passive: true });
    window.addEventListener('click', handleUserActivity, { passive: true });

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
      window.removeEventListener('mousemove', handleUserActivity);
      window.removeEventListener('keydown', handleUserActivity);
      window.removeEventListener('scroll', handleUserActivity);
      window.removeEventListener('click', handleUserActivity);
    };
  }, [user]);

  // 4. Periodic 30s heartbeat to backend
  useEffect(() => {
    if (!user || !activeSession?.id) return;

    const heartbeatInterval = setInterval(async () => {
      const sess = activeSessionRef.current;
      if (!sess?.id) return;

      try {
        await authService.heartbeatSession(sess.id, durationRef.current);
        lastHeartbeatRef.current = Date.now();
      } catch (err) {
        console.warn('[SessionTracker] Heartbeat error:', err);
      }
    }, 30000);

    return () => clearInterval(heartbeatInterval);
  }, [user, activeSession?.id]);

  // 5. Handle unexpected tab closures and page unloads without inventing fake logout time
  useEffect(() => {
    const handleBeforeUnload = () => {
      const sess = activeSessionRef.current;
      if (sess?.id) {
        // Send beacon updating last_activity and duration.
        // Logout time remains NULL because user did not explicitly sign out!
        authService.sendSessionBeacon(sess.id, durationRef.current, 'unexpected_close');
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, []);

  // 6. Explicit logout handler
  const endSession = useCallback(async () => {
    const sess = activeSessionRef.current;
    if (sess?.id) {
      try {
        await authService.logoutSession(sess.id, durationRef.current);
      } catch (err) {
        console.warn('[SessionTracker] Logout session error:', err);
      }
    }
    setActiveSession(null);
    setDurationSeconds(0);
  }, []);

  return {
    activeSession,
    durationSeconds,
    durationFormatted: formatDuration(durationSeconds),
    lastActivityAt,
    endSession
  };
}
