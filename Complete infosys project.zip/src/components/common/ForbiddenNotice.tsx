import React from 'react';
import { ShieldAlert, ArrowRight, LockKeyhole } from 'lucide-react';
import { WorkspaceRole } from '../../types';

interface ForbiddenNoticeProps {
  currentRole: WorkspaceRole;
  requiredRoles: string[];
  message?: string;
  onSwitchRole: (role: WorkspaceRole) => void;
}

export const ForbiddenNotice: React.FC<ForbiddenNoticeProps> = ({
  currentRole,
  requiredRoles,
  message,
  onSwitchRole,
}) => {
  return (
    <div className="max-w-2xl mx-auto my-12 p-8 bg-white border border-slate-200/90 rounded-2xl shadow-xs text-center">
      <div className="w-14 h-14 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-rose-100">
        <LockKeyhole className="w-7 h-7" />
      </div>

      <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-50 text-rose-700 text-xs font-semibold rounded-full mb-3 border border-rose-200/60 font-mono">
        HTTP 403 · FORBIDDEN
      </div>

      <h2 className="text-xl font-bold text-slate-900 tracking-tight mb-2">
        Restricted Workspace Access
      </h2>

      <p className="text-sm text-slate-600 mb-6 max-w-lg mx-auto leading-relaxed">
        {message ||
          `Your active workspace role is "${currentRole}". This dashboard contains confidential campaign budgets, financial spend in INR, and proprietary ROAS metrics restricted to Marketing managers and Administrators.`}
      </p>

      <div className="bg-slate-50 border border-slate-200/70 rounded-xl p-4 text-left text-xs mb-6 space-y-2">
        <div className="flex items-center justify-between text-slate-600">
          <span className="font-medium">Active Workspace Role:</span>
          <span className="font-mono bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-800 uppercase font-semibold">
            {currentRole}
          </span>
        </div>
        <div className="flex items-center justify-between text-slate-600">
          <span className="font-medium">Required Authorized Roles:</span>
          <span className="font-mono bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-800">
            {requiredRoles.join(' or ')}
          </span>
        </div>
        <div className="flex items-center justify-between text-slate-600">
          <span className="font-medium">RBAC Security Policy:</span>
          <span className="text-emerald-700 font-medium flex items-center gap-1">
            <ShieldAlert className="w-3.5 h-3.5" /> Enforced by server middleware
          </span>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
        <button
          onClick={() => onSwitchRole('marketing')}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-lg text-xs font-semibold hover:bg-blue-700 transition-colors shadow-xs"
        >
          <span>Switch to Marketing Workspace</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={() => onSwitchRole('admin')}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-white border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50 transition-colors"
        >
          <span>Authenticate as Administrator</span>
        </button>
      </div>
    </div>
  );
};
