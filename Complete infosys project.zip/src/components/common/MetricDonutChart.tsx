import React, { useState } from 'react';
import { formatIndianNumber, formatIndianCurrency } from '../../utils/formatters';

interface DonutSlice {
  label: string;
  value: number;
  percentage?: number;
  color: string;
}

interface MetricDonutChartProps {
  data: DonutSlice[];
  title?: string;
  subtitle?: string;
  size?: number;
  isCurrency?: boolean;
  centerLabel?: string;
  centerValue?: string;
}

export const MetricDonutChart: React.FC<MetricDonutChartProps> = ({
  data,
  title,
  subtitle,
  size = 180,
  isCurrency = false,
  centerLabel = 'Total',
  centerValue,
}) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  const total = data.reduce((acc, curr) => acc + curr.value, 0) || 1;

  // Calculate angles
  let cumulativeAngle = -90; // Start at top
  const strokeWidth = 24;
  const radius = (size - strokeWidth) / 2;
  const center = size / 2;
  const circumference = 2 * Math.PI * radius;

  const slicesWithAngles = data.map(item => {
    const fraction = item.value / total;
    const strokeDasharray = `${fraction * circumference} ${circumference}`;
    const strokeDashoffset = -((cumulativeAngle + 90) / 360) * circumference;
    cumulativeAngle += fraction * 360;

    return {
      ...item,
      fraction,
      pct: item.percentage || Math.round(fraction * 100),
      strokeDasharray,
      strokeDashoffset,
    };
  });

  const displayCenterValue = centerValue
    ? centerValue
    : isCurrency
    ? formatIndianCurrency(total, true)
    : formatIndianNumber(total, true);

  return (
    <div className="w-full">
      {(title || subtitle) && (
        <div className="mb-4">
          {title && <h3 className="text-sm font-semibold text-slate-900">{title}</h3>}
          {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
        </div>
      )}

      <div className="flex flex-col sm:flex-row items-center gap-6 justify-center">
        {/* Donut SVG */}
        <div className="relative shrink-0" style={{ width: size, height: size }}>
          <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="transform -rotate-90">
            {/* Background track */}
            <circle
              cx={center}
              cy={center}
              r={radius}
              fill="transparent"
              stroke="#F1F5F9"
              strokeWidth={strokeWidth}
            />

            {/* Slices */}
            {slicesWithAngles.map((slice, idx) => (
              <circle
                key={idx}
                cx={center}
                cy={center}
                r={radius}
                fill="transparent"
                stroke={slice.color}
                strokeWidth={hoveredIdx === idx ? strokeWidth + 4 : strokeWidth}
                strokeDasharray={slice.strokeDasharray}
                strokeDashoffset={slice.strokeDashoffset}
                className="transition-all duration-200 cursor-pointer"
                onMouseEnter={() => setHoveredIdx(idx)}
                onMouseLeave={() => setHoveredIdx(null)}
              />
            ))}
          </svg>

          {/* Center text */}
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center p-2">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
              {hoveredIdx !== null ? slicesWithAngles[hoveredIdx].label : centerLabel}
            </span>
            <span className="text-base font-bold text-slate-900 tabular-nums">
              {hoveredIdx !== null
                ? isCurrency
                  ? formatIndianCurrency(slicesWithAngles[hoveredIdx].value, true)
                  : `${slicesWithAngles[hoveredIdx].pct}%`
                : displayCenterValue}
            </span>
          </div>
        </div>

        {/* Legend */}
        <div className="flex-1 w-full space-y-2.5">
          {slicesWithAngles.map((slice, idx) => {
            const isHovered = hoveredIdx === idx;
            return (
              <div
                key={idx}
                className={`flex items-center justify-between text-xs p-1.5 rounded-lg transition-colors cursor-pointer ${
                  isHovered ? 'bg-slate-100/80' : 'hover:bg-slate-50'
                }`}
                onMouseEnter={() => setHoveredIdx(idx)}
                onMouseLeave={() => setHoveredIdx(null)}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ backgroundColor: slice.color }}
                  />
                  <span className="font-medium text-slate-700 truncate">{slice.label}</span>
                </div>
                <div className="flex items-center gap-2 shrink-0 tabular-nums">
                  <span className="font-semibold text-slate-900">
                    {isCurrency
                      ? formatIndianCurrency(slice.value, true)
                      : formatIndianNumber(slice.value, true)}
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">
                    ({slice.pct}%)
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
