import React, { useState } from 'react';
import { formatIndianNumber, formatIndianCurrency } from '../../utils/formatters';

interface DataPoint {
  label: string;
  value: number;
  secondaryValue?: number;
}

interface MetricLineChartProps {
  data: DataPoint[];
  title?: string;
  subtitle?: string;
  height?: number;
  isCurrency?: boolean;
  valuePrefix?: string;
  lineColor?: string;
  secondaryLineColor?: string;
  primaryLabel?: string;
  secondaryLabel?: string;
}

export const MetricLineChart: React.FC<MetricLineChartProps> = ({
  data,
  title,
  subtitle,
  height = 240,
  isCurrency = false,
  valuePrefix = '',
  lineColor = '#3B82F6', // Blue accent
  secondaryLineColor = '#8B5CF6', // Purple accent
  primaryLabel = 'Metric',
  secondaryLabel,
}) => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-48 text-slate-400 text-sm">
        No timeline data available
      </div>
    );
  }

  const values = data.map(d => d.value);
  const secondaryValues = secondaryLabel ? data.map(d => d.secondaryValue || 0) : [];
  const allValues = [...values, ...secondaryValues];

  const minVal = 0;
  const maxVal = Math.max(...allValues) * 1.15 || 100;

  const padding = { top: 20, right: 20, bottom: 30, left: 60 };
  const width = 600; // SVG coordinate space
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;

  const getX = (index: number) => {
    return padding.left + (index / (data.length - 1)) * chartWidth;
  };

  const getY = (val: number) => {
    return padding.top + chartHeight - ((val - minVal) / (maxVal - minVal)) * chartHeight;
  };

  // Generate SVG path points
  const points = data.map((d, i) => `${getX(i)},${getY(d.value)}`).join(' ');
  const areaPoints = `${getX(0)},${padding.top + chartHeight} ${points} ${getX(data.length - 1)},${padding.top + chartHeight}`;

  let secondaryPoints = '';
  if (secondaryLabel) {
    secondaryPoints = data.map((d, i) => `${getX(i)},${getY(d.secondaryValue || 0)}`).join(' ');
  }

  // Generate 4 Y-axis ticks
  const yTicks = [0, maxVal * 0.33, maxVal * 0.66, maxVal];

  const formatValue = (num: number) => {
    if (isCurrency) {
      return formatIndianCurrency(num, true);
    }
    return `${valuePrefix}${formatIndianNumber(num, true)}`;
  };

  return (
    <div className="w-full">
      {(title || subtitle) && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 gap-2">
          <div>
            {title && <h3 className="text-sm font-semibold text-slate-900">{title}</h3>}
            {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
          </div>
          {secondaryLabel && (
            <div className="flex items-center gap-4 text-xs font-medium text-slate-600">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: lineColor }} />
                <span>{primaryLabel}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: secondaryLineColor }} />
                <span>{secondaryLabel}</span>
              </div>
            </div>
          )}
        </div>
      )}

      <div className="relative w-full overflow-hidden">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto overflow-visible select-none"
        >
          <defs>
            <linearGradient id="primaryAreaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={lineColor} stopOpacity="0.18" />
              <stop offset="100%" stopColor={lineColor} stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid lines and Y-axis labels */}
          {yTicks.map((tick, i) => {
            const y = getY(tick);
            return (
              <g key={i}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke="#E2E8F0"
                  strokeDasharray={i === 0 ? 'none' : '3 3'}
                  strokeWidth="1"
                />
                <text
                  x={padding.left - 8}
                  y={y + 4}
                  textAnchor="end"
                  className="text-[10px] fill-slate-400 font-sans tabular-nums"
                >
                  {formatValue(tick)}
                </text>
              </g>
            );
          })}

          {/* Area under line */}
          <polygon points={areaPoints} fill="url(#primaryAreaGrad)" />

          {/* Secondary Line */}
          {secondaryLabel && (
            <polyline
              points={secondaryPoints}
              fill="none"
              stroke={secondaryLineColor}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}

          {/* Primary Line */}
          <polyline
            points={points}
            fill="none"
            stroke={lineColor}
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Data Points and Interaction Bars */}
          {data.map((d, i) => {
            const x = getX(i);
            const y = getY(d.value);
            const isHovered = hoveredIndex === i;

            return (
              <g key={i}>
                {/* Vertical hover line */}
                {isHovered && (
                  <line
                    x1={x}
                    y1={padding.top}
                    x2={x}
                    y2={padding.top + chartHeight}
                    stroke="#94A3B8"
                    strokeWidth="1"
                    strokeDasharray="2 2"
                  />
                )}

                {/* Primary node */}
                <circle
                  cx={x}
                  cy={y}
                  r={isHovered ? 5 : 3.5}
                  fill="#FFFFFF"
                  stroke={lineColor}
                  strokeWidth="2.5"
                  className="transition-all duration-150 cursor-pointer"
                />

                {/* Secondary node */}
                {secondaryLabel && (
                  <circle
                    cx={x}
                    cy={getY(d.secondaryValue || 0)}
                    r={isHovered ? 5 : 3.5}
                    fill="#FFFFFF"
                    stroke={secondaryLineColor}
                    strokeWidth="2.5"
                    className="transition-all duration-150 cursor-pointer"
                  />
                )}

                {/* X Axis Label */}
                <text
                  x={x}
                  y={padding.top + chartHeight + 18}
                  textAnchor="middle"
                  className={`text-[11px] font-sans ${isHovered ? 'fill-slate-900 font-semibold' : 'fill-slate-400'}`}
                >
                  {d.label}
                </text>

                {/* Invisible hover hotspot */}
                <rect
                  x={x - chartWidth / (data.length * 2)}
                  y={padding.top}
                  width={chartWidth / data.length}
                  height={chartHeight}
                  fill="transparent"
                  onMouseEnter={() => setHoveredIndex(i)}
                  onMouseLeave={() => setHoveredIndex(null)}
                  className="cursor-pointer"
                />
              </g>
            );
          })}
        </svg>

        {/* Floating Tooltip */}
        {hoveredIndex !== null && (
          <div
            className="absolute top-2 pointer-events-none bg-slate-900/95 text-white px-3 py-2 rounded-lg shadow-lg text-xs z-10 font-sans transform -translate-x-1/2 backdrop-blur-xs"
            style={{
              left: `${(getX(hoveredIndex) / width) * 100}%`,
            }}
          >
            <div className="font-semibold text-slate-200 border-b border-slate-700/60 pb-1 mb-1">
              {data[hoveredIndex].label}
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: lineColor }} />
              <span className="text-slate-300">{primaryLabel}:</span>
              <span className="font-bold tabular-nums">
                {isCurrency
                  ? formatIndianCurrency(data[hoveredIndex].value, false)
                  : `${valuePrefix}${formatIndianNumber(data[hoveredIndex].value, false)}`}
              </span>
            </div>
            {secondaryLabel && data[hoveredIndex].secondaryValue !== undefined && (
              <div className="flex items-center gap-2 mt-0.5">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: secondaryLineColor }} />
                <span className="text-slate-300">{secondaryLabel}:</span>
                <span className="font-bold tabular-nums">
                  {isCurrency
                    ? formatIndianCurrency(data[hoveredIndex].secondaryValue || 0, false)
                    : `${valuePrefix}${formatIndianNumber(data[hoveredIndex].secondaryValue || 0, false)}`}
                </span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
