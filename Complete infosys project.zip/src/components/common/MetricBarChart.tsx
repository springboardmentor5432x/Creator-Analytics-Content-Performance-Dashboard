import React, { useState } from 'react';
import { formatIndianNumber, formatIndianCurrency } from '../../utils/formatters';

interface BarDataPoint {
  label: string;
  value: number;
  color?: string;
  subLabel?: string;
}

interface MetricBarChartProps {
  data: BarDataPoint[];
  title?: string;
  subtitle?: string;
  height?: number;
  isCurrency?: boolean;
  defaultColor?: string;
  horizontal?: boolean;
}

export const MetricBarChart: React.FC<MetricBarChartProps> = ({
  data,
  title,
  subtitle,
  height = 240,
  isCurrency = false,
  defaultColor = '#3B82F6',
  horizontal = false,
}) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return <div className="text-slate-400 text-sm py-8 text-center">No bar chart data</div>;
  }

  const maxVal = Math.max(...data.map(d => d.value)) * 1.15 || 100;

  if (horizontal) {
    return (
      <div className="w-full">
        {(title || subtitle) && (
          <div className="mb-4">
            {title && <h3 className="text-sm font-semibold text-slate-900">{title}</h3>}
            {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
          </div>
        )}
        <div className="space-y-3">
          {data.map((item, idx) => {
            const pct = Math.min(100, Math.max(4, (item.value / maxVal) * 100));
            return (
              <div key={idx} className="group">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-medium text-slate-700 truncate max-w-[200px]">
                    {item.label}
                  </span>
                  <span className="font-semibold text-slate-900 tabular-nums">
                    {isCurrency
                      ? formatIndianCurrency(item.value, true)
                      : formatIndianNumber(item.value, true)}
                  </span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500 ease-out"
                    style={{
                      width: `${pct}%`,
                      backgroundColor: item.color || defaultColor,
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // Vertical Bar Chart
  const padding = { top: 20, right: 20, bottom: 35, left: 55 };
  const width = 500;
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;
  const barWidth = Math.min(36, (chartWidth / data.length) * 0.55);

  const getY = (val: number) => {
    return padding.top + chartHeight - (val / maxVal) * chartHeight;
  };

  const yTicks = [0, maxVal * 0.33, maxVal * 0.66, maxVal];

  return (
    <div className="w-full">
      {(title || subtitle) && (
        <div className="mb-4">
          {title && <h3 className="text-sm font-semibold text-slate-900">{title}</h3>}
          {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
        </div>
      )}

      <div className="relative">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible select-none">
          {/* Grid lines */}
          {yTicks.map((tick, i) => {
            const y = getY(tick);
            return (
              <g key={i}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke="#E2E8F0"
                  strokeDasharray={i === 0 ? 'none' : '3 3'}
                  strokeWidth="1"
                />
                <text
                  x={padding.left - 8}
                  y={y + 4}
                  textAnchor="end"
                  className="text-[10px] fill-slate-400 font-sans tabular-nums"
                >
                  {isCurrency ? formatIndianCurrency(tick, true) : formatIndianNumber(tick, true)}
                </text>
              </g>
            );
          })}

          {/* Bars */}
          {data.map((item, idx) => {
            const xCenter = padding.left + ((idx + 0.5) / data.length) * chartWidth;
            const x = xCenter - barWidth / 2;
            const barH = (item.value / maxVal) * chartHeight;
            const y = padding.top + chartHeight - barH;
            const isHovered = hoveredIdx === idx;

            return (
              <g
                key={idx}
                onMouseEnter={() => setHoveredIdx(idx)}
                onMouseLeave={() => setHoveredIdx(null)}
                className="cursor-pointer"
              >
                <rect
                  x={x}
                  y={y}
                  width={barWidth}
                  height={barH}
                  rx="4"
                  fill={item.color || defaultColor}
                  opacity={isHovered ? 1 : 0.85}
                  className="transition-all duration-150"
                />

                {/* X Axis label */}
                <text
                  x={xCenter}
                  y={padding.top + chartHeight + 16}
                  textAnchor="middle"
                  className={`text-[11px] font-sans ${isHovered ? 'fill-slate-900 font-semibold' : 'fill-slate-500'}`}
                >
                  {item.label}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Tooltip */}
        {hoveredIdx !== null && (
          <div
            className="absolute top-1 pointer-events-none bg-slate-900/95 text-white px-2.5 py-1.5 rounded-lg shadow-md text-xs z-10 transform -translate-x-1/2 backdrop-blur-xs font-sans tabular-nums"
            style={{
              left: `${
                ((padding.left + ((hoveredIdx + 0.5) / data.length) * chartWidth) / width) * 100
              }%`,
            }}
          >
            <div className="font-semibold text-slate-300">{data[hoveredIdx].label}</div>
            <div className="font-bold text-white">
              {isCurrency
                ? formatIndianCurrency(data[hoveredIdx].value, false)
                : formatIndianNumber(data[hoveredIdx].value, false)}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
