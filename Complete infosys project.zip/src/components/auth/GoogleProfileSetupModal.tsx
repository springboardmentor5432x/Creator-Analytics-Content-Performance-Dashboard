import React, { useState } from 'react';
import { User, UserRole } from '../../types/auth';
import { authService } from '../../services/api';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../../config/firebase';
import { Sparkles, Check, AlertCircle, Shield, Briefcase, Video, TrendingUp, X } from 'lucide-react';

interface GoogleProfileSetupModalProps {
  user: User;
  isOpen: boolean;
  onComplete: (updatedUser: User) => void;
  onClose?: () => void;
}

const AVAILABLE_ROLES: { id: UserRole; label: string; description: string; icon: any; color: string }[] = [
  {
    id: 'creator',
    label: 'Creator',
    description: 'Track YouTube, Instagram, TikTok stats, views, reach & earnings',
    icon: Video,
    color: 'text-blue-600 bg-blue-50 border-blue-200'
  },
  {
    id: 'agency',
    label: 'Agency',
    description: 'Manage creator rosters, client campaigns, tasks & contracts',
    icon: Briefcase,
    color: 'text-purple-600 bg-purple-50 border-purple-200'
  },
  {
    id: 'marketing',
    label: 'Marketing Team',
    description: 'Launch influencer campaigns, track conversions, spend & ROAS',
    icon: TrendingUp,
    color: 'text-sky-600 bg-sky-50 border-sky-200'
  },
  {
    id: 'admin',
    label: 'Admin',
    description: 'System health, user management, RBAC controls & platform logs',
    icon: Shield,
    color: 'text-indigo-600 bg-indigo-50 border-indigo-200'
  }
];

export const GoogleProfileSetupModal: React.FC<GoogleProfileSetupModalProps> = ({
  user,
  isOpen,
  onComplete,
  onClose
}) => {
  const [displayName, setDisplayName] = useState(user.name || '');
  const [username, setUsername] = useState(
    (user.username || `@${(user.name || user.email.split('@')[0]).toLowerCase().replace(/[^a-z0-9_]/g, '')}`)
  );
  const [selectedRoles, setSelectedRoles] = useState<UserRole[]>(() => {
    if (user.roles && user.roles.length > 0) return user.roles.slice(0, 3);
    return [user.role || 'creator'];
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const isEligibleAdmin = user.role === 'admin' || (user.roles && user.roles.includes('admin')) || (user.email === 'sharshitha28007@gmail.com' || user.email === 'sharshitha559@gmail.com' || user.email?.includes('sharshitha')) || user.email === 'admin@creatoriq.com';
  const rolesList = AVAILABLE_ROLES.filter(r => r.id !== 'admin' || isEligibleAdmin);

  const handleRoleToggle = (roleId: UserRole) => {
    if (roleId === 'admin' && !isEligibleAdmin) {
      setError('Admin access can only be assigned by an existing system administrator.');
      return;
    }

    if (selectedRoles.includes(roleId)) {
      if (selectedRoles.length === 1) {
        setError('At least one authorized role must remain selected.');
        return;
      }
      setError(null);
      setSelectedRoles(prev => prev.filter(r => r !== roleId));
    } else {
      const maxRoles = isEligibleAdmin ? 4 : 3;
      if (selectedRoles.length >= maxRoles) {
        setError(`You can select a maximum of ${maxRoles} authorized roles per account.`);
        return;
      }
      setError(null);
      setSelectedRoles(prev => [...prev, roleId]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = displayName.trim();
    const cleanHandle = username.trim().replace(/^@+/, '');

    if (!cleanName) {
      setError('Display name is required.');
      return;
    }
    if (!cleanHandle) {
      setError('Username handle is required.');
      return;
    }
    if (selectedRoles.length === 0) {
      setError('Please select at least 1 authorized role.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    const formattedHandle = `@${cleanHandle}`;

    try {
      // 1. Update backend REST database & issue fresh JWT
      const res = await authService.setupGoogleProfile({
        name: cleanName,
        username: formattedHandle,
        roles: selectedRoles
      });

      // 2. Also persist to Firestore user document
      if (user.uid) {
        await updateDoc(doc(db, 'users', user.uid), {
          name: cleanName,
          username: formattedHandle,
          roles: selectedRoles,
          role: selectedRoles[0],
          isProfileCustomized: true,
          updatedAt: new Date().toISOString()
        }).catch(console.warn);
      }

      const updatedUserData: User = {
        ...user,
        name: cleanName,
        username: formattedHandle,
        roles: selectedRoles,
        role: res.user?.role || selectedRoles[0],
        is_profile_customized: true
      };

      onComplete(updatedUserData);
    } catch (err: any) {
      console.error('Failed to setup Google profile:', err);
      setError(err.message || 'Failed to save profile details. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-sky-100 relative">
        {onClose && (
          <button 
            onClick={onClose}
            className="absolute top-5 right-5 p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-2xl bg-sky-50 border border-sky-200 flex items-center justify-center text-sky-600">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">Customize Your Profile</h2>
            <p className="text-xs text-slate-500">Configure your display name, handle, and dashboard permissions.</p>
          </div>
        </div>

        {error && (
          <div className="my-4 p-3 rounded-xl bg-red-50 border border-red-200 flex items-start gap-2.5 text-xs text-red-700">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
            <div className="flex-1">{error}</div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 mt-5">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Display Name
            </label>
            <input
              type="text"
              required
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="e.g. Harshitha S"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Username Handle
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-sm font-semibold text-slate-400">@</span>
              <input
                type="text"
                required
                value={username.replace(/^@/, '')}
                onChange={(e) => setUsername(`@${e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '')}`)}
                placeholder="harshitha_s"
                className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm font-mono focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">Unique handle across creator analytics, reports, and team collaborations.</p>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-xs font-semibold text-slate-700">
                Authorized Roles (Choose up to 3)
              </label>
              <span className="text-[11px] font-bold text-sky-600 bg-sky-50 px-2 py-0.5 rounded-full border border-sky-100">
                {selectedRoles.length}/3 Selected
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {rolesList.map((r) => {
                const isSelected = selectedRoles.includes(r.id);
                const Icon = r.icon;
                return (
                  <button
                    type="button"
                    key={r.id}
                    onClick={() => handleRoleToggle(r.id)}
                    className={`p-3 rounded-2xl border text-left transition-all relative flex flex-col justify-between ${
                      isSelected
                        ? 'border-sky-500 bg-sky-50/50 shadow-xs ring-1 ring-sky-500'
                        : 'border-slate-200 bg-slate-50/40 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full mb-1">
                      <div className="flex items-center gap-2">
                        <div className={`p-1.5 rounded-lg border ${r.color}`}>
                          <Icon className="w-3.5 h-3.5" />
                        </div>
                        <span className="text-xs font-bold text-slate-900">{r.label}</span>
                      </div>
                      <div className={`w-4 h-4 rounded-full flex items-center justify-center border transition-colors ${
                        isSelected ? 'bg-sky-600 border-sky-600 text-white' : 'border-slate-300 bg-white'
                      }`}>
                        {isSelected && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                      </div>
                    </div>
                    <p className="text-[11px] text-slate-500 leading-tight mt-1">{r.description}</p>
                  </button>
                );
              })}
            </div>
            <p className="text-[11px] text-slate-400 mt-2">
              You will be able to switch between your authorized dashboards anytime directly from the top navigation bar without logging in again.
            </p>
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 transition-colors"
              >
                Skip for Now
              </button>
            )}
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-md shadow-sky-600/20 transition-all disabled:opacity-50 flex items-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Saving Details...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Save &amp; Continue</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
