import React, { useState, useEffect } from 'react';
import { 
  Mail, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  LogOut, 
  Send, 
  ExternalLink,
  ShieldAlert
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface EmailVerificationPromptProps {
  onShowToast: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const EmailVerificationPrompt: React.FC<EmailVerificationPromptProps> = ({ onShowToast }) => {
  const { user, resendVerificationEmail, checkVerificationStatus, logout, loginWithGoogle, isActionLoading } = useAuth();
  const [isResending, setIsResending] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    setStatusMessage(null);
    try {
      const res = await loginWithGoogle(user?.role || 'creator');
      if (res.success) {
        onShowToast(`Signed in directly with Google! Verified access granted.`, 'success');
      } else {
        setStatusMessage(res.message || 'Google sign-in could not be completed.');
        onShowToast(res.message || 'Google sign-in failed', 'error');
      }
    } catch (err: any) {
      setStatusMessage(err.message || 'An error occurred during Google sign in.');
      onShowToast(err.message || 'Google sign-in error', 'error');
    }
  };

  useEffect(() => {
    if (cooldown <= 0) return;
    const interval = setInterval(() => {
      setCooldown(prev => Math.max(0, prev - 1));
    }, 1000);
    return () => clearInterval(interval);
  }, [cooldown]);

  // Automatically check verification status when user returns to this browser tab after clicking the link in their email
  useEffect(() => {
    const handleFocus = async () => {
      try {
        const verified = await checkVerificationStatus();
        if (verified) {
          onShowToast('Email verified successfully! Welcome to your dashboard.', 'success');
        }
      } catch {
        // Non-blocking auto-check
      }
    };

    window.addEventListener('focus', handleFocus);
    const interval = setInterval(handleFocus, 10000); // Periodic check every 10s

    return () => {
      window.removeEventListener('focus', handleFocus);
      clearInterval(interval);
    };
  }, [checkVerificationStatus, onShowToast]);

  const handleResend = async () => {
    if (cooldown > 0 || isResending) return;
    setIsResending(true);
    setStatusMessage(null);
    try {
      const res = await resendVerificationEmail();
      if (res.success) {
        setStatusMessage(res.message || 'Verification email dispatched! Please check your inbox and spam folder.');
        setCooldown(45);
        onShowToast(res.message || 'Verification email resent successfully.', 'success');
      } else {
        setStatusMessage(res.message);
        onShowToast(res.message, 'error');
      }
    } catch (err: any) {
      setStatusMessage(err.message || 'Failed to resend verification email.');
      onShowToast(err.message || 'Failed to send verification email.', 'error');
    } finally {
      setIsResending(false);
    }
  };

  const handleCheckNow = async () => {
    setIsChecking(true);
    setStatusMessage(null);
    try {
      const verified = await checkVerificationStatus();
      if (verified) {
        onShowToast('Email verified successfully! Welcome to your dashboard.', 'success');
      } else {
        setStatusMessage('Email is not yet verified. Please click the confirmation link in the email sent to your inbox.');
        onShowToast('Email still unverified. Please check your inbox or click Resend.', 'info');
      }
    } catch (err: any) {
      setStatusMessage(err.message || 'Could not verify status. Please try again.');
    } finally {
      setIsChecking(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl border border-purple-100 p-8 text-center animate-in fade-in">
        {/* Badge Icon */}
        <div className="w-16 h-16 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mx-auto mb-4 shadow-sm">
          <ShieldAlert className="w-8 h-8" />
        </div>

        <h2 className="text-xl font-black text-slate-900 tracking-tight mb-2">
          Verify Your Email Address
        </h2>

        <p className="text-xs text-slate-600 leading-relaxed mb-4">
          A genuine verification email has been sent to:
        </p>

        <div className="p-3 rounded-2xl bg-purple-50/80 border border-purple-200 mb-5 font-mono text-xs font-bold text-purple-900 break-all">
          {user?.email || 'your registered email'}
        </div>

        <p className="text-xs text-slate-500 leading-relaxed mb-6">
          To protect account security and access the <span className="font-bold text-purple-700 capitalize">{user?.role || 'authorized'} Team Dashboard</span>, please open the verification link in your inbox or spam folder.
        </p>

        {statusMessage && (
          <div className="mb-5 p-3 rounded-xl bg-purple-50 border border-purple-200 text-purple-950 text-xs font-medium flex items-start space-x-2 text-left">
            <AlertCircle className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
            <span>{statusMessage}</span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-3">
          <button
            onClick={handleCheckNow}
            disabled={isChecking}
            className="w-full py-3 px-4 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 shadow-lg shadow-purple-500/25 transition-all disabled:opacity-50"
          >
            {isChecking ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Checking Verification Status...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>I Have Clicked The Verification Link</span>
              </>
            )}
          </button>

          <button
            onClick={handleResend}
            disabled={cooldown > 0 || isResending}
            className="w-full py-2.5 px-4 rounded-xl border border-purple-200 hover:bg-purple-50/50 text-purple-700 font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 transition-all disabled:text-slate-400 disabled:border-slate-200"
          >
            {isResending ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Sending Email...</span>
              </>
            ) : (
              <>
                <Send className="w-3.5 h-3.5" />
                <span>{cooldown > 0 ? `Resend Email in ${cooldown}s` : 'Resend Verification Email'}</span>
              </>
            )}
          </button>

          <div className="flex items-center space-x-2 text-slate-400 my-2">
            <div className="flex-1 h-px bg-slate-200"></div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">or bypass verification</span>
            <div className="flex-1 h-px bg-slate-200"></div>
          </div>

          {/* Continue with Google directly */}
          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={isActionLoading}
            className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-slate-50 border-2 border-slate-200 hover:border-purple-300 text-slate-800 font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 shadow-xs transition-all disabled:opacity-50 cursor-pointer"
          >
            {isActionLoading ? (
              <RefreshCw className="w-4 h-4 animate-spin text-purple-600" />
            ) : (
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
            )}
            <span>Continue with Google Instead</span>
          </button>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-center">
            <button
              onClick={() => logout()}
              className="text-xs text-slate-500 hover:text-rose-600 font-semibold flex items-center space-x-1.5 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign out and use another account</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
