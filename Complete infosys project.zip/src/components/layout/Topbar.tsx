import React from 'react';
import {
  Calendar,
  Layers,
  Link2,
  RefreshCw,
  Download,
  IndianRupee,
  Clock,
} from 'lucide-react';
import { WorkspaceRole } from '../../types';
import { formatIndianDate } from '../../utils/formatters';

interface TopbarProps {
  currentTab: 'creator' | 'agency' | 'marketing' | 'admin';
  activeRole: WorkspaceRole;
  connectedAccountsCount: number;
  onOpenIntegrations: () => void;
  onOpenRoleSwitch: () => void;
  onRefreshData: () => void;
  isRefreshing: boolean;
}

export const Topbar: React.FC<TopbarProps> = ({
  currentTab,
  activeRole,
  connectedAccountsCount,
  onOpenIntegrations,
  onOpenRoleSwitch,
  onRefreshData,
  isRefreshing,
}) => {
  const titles = {
    creator: {
      title: 'Creator Analytics & Performance',
      category: 'Audience & Growth',
    },
    agency: {
      title: 'Agency Operations & Talent Hub',
      category: 'Client Roster & Revenue',
    },
    marketing: {
      title: 'Marketing Performance & ROAS Intelligence',
      category: 'Campaign Attribution & Spend',
    },
    admin: {
      title: 'System Administration & Security Console',
      category: 'Platform Governance',
    },
  }[currentTab];

  // Current timestamp formatted for Asia/Kolkata
  const now = new Date();
  const formattedToday = formatIndianDate(now, true);

  return (
    <header className="h-16 bg-white border-b border-slate-200/90 px-6 flex items-center justify-between gap-6 shrink-0 z-20">
      {/* Zone 1: Context Title and Breadcrumb */}
      <div className="flex items-center gap-3 min-w-0">
        <div>
          <div className="flex items-center gap-2 text-[11px] text-slate-400 font-medium">
            <span>CreatorIQ</span>
            <span aria-hidden="true">/</span>
            <span className="text-slate-600">{titles.category}</span>
          </div>
          <h1 className="text-base font-bold text-slate-900 tracking-tight leading-tight truncate">
            {titles.title}
          </h1>
        </div>
      </div>

      {/* Zone 2: Indian Locale & Status Indicators */}
      <div className="hidden lg:flex items-center gap-4 text-xs text-slate-500 font-medium">
        <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200/80 px-2.5 py-1 rounded-lg">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span className="tabular-nums font-mono text-[11px]">{formattedToday} IST</span>
        </div>

        <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200/80 px-2.5 py-1 rounded-lg">
          <IndianRupee className="w-3.5 h-3.5 text-blue-600" />
          <span className="text-[11px] text-slate-700">en-IN (INR)</span>
        </div>
      </div>

      {/* Zone 3: Interactive Controls & Actions */}
      <div className="flex items-center gap-2.5 shrink-0">
        <button
          onClick={onOpenRoleSwitch}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors text-slate-700"
          title="Change active workspace role"
        >
          <Layers className="w-3.5 h-3.5 text-slate-500" />
          <span className="capitalize hidden sm:inline">{activeRole} Role</span>
        </button>

        <button
          onClick={onOpenIntegrations}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors text-slate-700"
          title="Manage connected social media platforms"
        >
          <Link2 className="w-3.5 h-3.5 text-blue-600" />
          <span className="hidden sm:inline">{connectedAccountsCount} Accounts</span>
        </button>

        <button
          onClick={onRefreshData}
          disabled={isRefreshing}
          className="p-1.5 sm:px-3 sm:py-1.5 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors flex items-center gap-1.5 shadow-xs disabled:opacity-50"
          title="Refresh verified dashboard metrics"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
          <span className="hidden sm:inline">Sync Data</span>
        </button>
      </div>
    </header>
  );
};
