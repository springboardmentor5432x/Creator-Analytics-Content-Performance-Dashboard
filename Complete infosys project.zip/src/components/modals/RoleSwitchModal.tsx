import React, { useState } from 'react';
import { X, ShieldCheck, CheckCircle2, AlertTriangle, ArrowRight, Play } from 'lucide-react';
import { WorkspaceRole } from '../../types';

interface RoleSwitchModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentRole: WorkspaceRole;
  onRoleSelected: (role: WorkspaceRole) => void;
}

export const RoleSwitchModal: React.FC<RoleSwitchModalProps> = ({
  isOpen,
  onClose,
  currentRole,
  onRoleSelected,
}) => {
  const [testResult, setTestResult] = useState<{
    roleTested: string;
    status: number;
    message: string;
    allowed: boolean;
  } | null>(null);
  const [testing, setTesting] = useState(false);

  if (!isOpen) return null;

  const roles: {
    id: WorkspaceRole;
    name: string;
    description: string;
    permissions: string[];
    badgeColor: string;
  }[] = [
    {
      id: 'marketing',
      name: 'Marketing Brand Manager',
      description: 'Authorized to view campaign spend in INR, impressions, ROI, ROAS, and conversions.',
      permissions: ['marketing:view', 'marketing:spend:read', 'marketing:campaigns:read'],
      badgeColor: 'bg-blue-50 text-blue-700 border-blue-200',
    },
    {
      id: 'agency',
      name: 'Agency Account Lead',
      description: 'Manages creator rosters, active client campaigns, deliverables, and INR commissions.',
      permissions: ['agency:view', 'agency:creators:read', 'agency:commission:read'],
      badgeColor: 'bg-purple-50 text-purple-700 border-purple-200',
    },
    {
      id: 'creator',
      name: 'Independent Creator',
      description: 'Views organic audience reach, followers, content engagement, and platform analytics.',
      permissions: ['creator:view', 'creator:analytics:read'],
      badgeColor: 'bg-orange-50 text-orange-700 border-orange-200',
    },
    {
      id: 'admin',
      name: 'Platform Administrator',
      description: 'Unrestricted super-user access across all workspaces, audit logs, and system health.',
      permissions: ['* (All System Permissions)'],
      badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    },
  ];

  const runRbacTest = async (roleToTest: WorkspaceRole) => {
    setTesting(true);
    setTestResult(null);
    try {
      const response = await fetch('/api/marketing/dashboard', {
        headers: {
          'X-Workspace-Role': roleToTest,
          'Authorization': 'Bearer verified_test_token',
        },
      });

      const data = await response.json().catch(() => ({}));

      if (response.status === 200) {
        setTestResult({
          roleTested: roleToTest,
          status: 200,
          message: 'HTTP 200 OK — User authorized. Full Marketing Dashboard and campaign spend data accessible.',
          allowed: true,
        });
      } else if (response.status === 403) {
        setTestResult({
          roleTested: roleToTest,
          status: 403,
          message: data.message || `HTTP 403 Forbidden — Unauthorized role "${roleToTest}" correctly blocked by RBAC middleware.`,
          allowed: false,
        });
      } else {
        setTestResult({
          roleTested: roleToTest,
          status: response.status,
          message: `Unexpected response status: ${response.status}`,
          allowed: false,
        });
      }
    } catch (err: any) {
      setTestResult({
        roleTested: roleToTest,
        status: 500,
        message: err.message,
        allowed: false,
      });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl max-w-xl w-full border border-slate-200 shadow-xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Workspace Role & RBAC Access Console
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Switch your active role or verify role-based permissions on backend endpoints.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="space-y-2.5">
            {roles.map(role => {
              const isSelected = currentRole === role.id;
              return (
                <div
                  key={role.id}
                  onClick={() => onRoleSelected(role.id)}
                  className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-blue-50/50 border-blue-300 ring-2 ring-blue-100'
                      : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-slate-900">{role.name}</span>
                        <span
                          className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded border ${role.badgeColor}`}
                        >
                          {role.id}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                        {role.description}
                      </p>
                    </div>
                    {isSelected ? (
                      <div className="p-1 bg-blue-600 text-white rounded-full shrink-0">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                    ) : (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onRoleSelected(role.id);
                        }}
                        className="text-xs font-semibold text-slate-600 hover:text-blue-600 px-2.5 py-1 rounded bg-slate-100 hover:bg-blue-50 transition-colors shrink-0"
                      >
                        Select
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* RBAC Verification Box */}
          <div className="mt-6 pt-4 border-t border-slate-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2 flex items-center justify-between">
              <span>RBAC Endpoint Verification Test</span>
              <span className="text-[11px] font-normal text-slate-400">/api/marketing/dashboard</span>
            </h4>
            <p className="text-xs text-slate-500 mb-3">
              Test how the server authorization middleware handles requests from different roles:
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {roles.map(r => (
                <button
                  key={r.id}
                  disabled={testing}
                  onClick={() => runRbacTest(r.id)}
                  className="px-2.5 py-2 text-xs font-medium rounded-lg border border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50 text-slate-700 flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Play className="w-3 h-3 text-slate-400" />
                  <span>Test {r.id}</span>
                </button>
              ))}
            </div>

            {testResult && (
              <div
                className={`mt-3 p-3 rounded-xl border text-xs font-sans ${
                  testResult.allowed
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-amber-50 border-amber-200 text-amber-800'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold mb-1">
                  {testResult.allowed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                  )}
                  <span>
                    Role &quot;{testResult.roleTested}&quot; — Status {testResult.status}
                  </span>
                </div>
                <div className="text-xs opacity-90 leading-relaxed font-mono">
                  {testResult.message}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>Active Role: <strong className="text-slate-800 uppercase">{currentRole}</strong></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors shadow-xs"
          >
            Confirm & Close
          </button>
        </div>
      </div>
    </div>
  );
};
