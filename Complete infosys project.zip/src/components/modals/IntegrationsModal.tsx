import React, { useState } from 'react';
import { X, RefreshCw, CheckCircle2, AlertCircle, Link2, ExternalLink } from 'lucide-react';
import { SocialAccount } from '../../types';
import { formatIndianNumber, formatIndianDate } from '../../utils/formatters';
import { api } from '../../api/client';

interface IntegrationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: SocialAccount[];
  onAccountsUpdated: (updatedAccounts: SocialAccount[]) => void;
}

export const IntegrationsModal: React.FC<IntegrationsModalProps> = ({
  isOpen,
  onClose,
  accounts,
  onAccountsUpdated,
}) => {
  const [syncingPlatform, setSyncingPlatform] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleConnect = async (platform: string) => {
    try {
      setSyncingPlatform(platform);
      const res = await api.connectSocialAccount(platform);
      const updated = accounts.map(a => (a.platform === platform ? res.account : a));
      onAccountsUpdated(updated);
      setActionMessage(`Connected ${res.account.platformName} authorized API token.`);
      setTimeout(() => setActionMessage(null), 3500);
    } catch (err: any) {
      setActionMessage(`Connection error: ${err.message}`);
    } finally {
      setSyncingPlatform(null);
    }
  };

  const handleDisconnect = async (platform: string) => {
    try {
      setSyncingPlatform(platform);
      const res = await api.disconnectSocialAccount(platform);
      const updated = accounts.map(a => (a.platform === platform ? res.account : a));
      onAccountsUpdated(updated);
      setActionMessage(`Revoked OAuth access token for ${res.account.platformName}.`);
      setTimeout(() => setActionMessage(null), 3500);
    } catch (err: any) {
      setActionMessage(`Disconnect error: ${err.message}`);
    } finally {
      setSyncingPlatform(null);
    }
  };

  const handleSync = async (platform: string) => {
    try {
      setSyncingPlatform(platform);
      const res = await api.syncSocialAccount(platform);
      const updated = accounts.map(a => (a.platform === platform ? res.account : a));
      onAccountsUpdated(updated);
      setActionMessage(`Synchronized latest metrics for ${res.account.platformName}.`);
      setTimeout(() => setActionMessage(null), 3500);
    } catch (err: any) {
      setActionMessage(`Sync error: ${err.message}`);
    } finally {
      setSyncingPlatform(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl max-w-2xl w-full border border-slate-200 shadow-xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Social Platform Integrations & OAuth
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Verified API connection status for YouTube, Instagram, X, LinkedIn, and TikTok.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action feedback */}
        {actionMessage && (
          <div className="px-6 py-2.5 bg-blue-50/80 border-b border-blue-100 text-xs font-medium text-blue-700 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
            <span>{actionMessage}</span>
          </div>
        )}

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="bg-slate-50 border border-slate-200/70 rounded-xl p-3 text-xs text-slate-600 leading-relaxed">
            <strong className="text-slate-800">Data Integrity Guarantee:</strong> Accounts are marked
            as connected only when valid OAuth credentials exist. Unconnected platforms are reported
            transparently without fabricated figures.
          </div>

          <div className="space-y-3">
            {accounts.map(account => {
              const isSyncing = syncingPlatform === account.platform;

              return (
                <div
                  key={account.id}
                  className={`p-4 rounded-xl border transition-all ${
                    account.connected
                      ? 'bg-white border-slate-200/90 shadow-2xs'
                      : 'bg-slate-50/50 border-slate-200/60'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img
                          src={account.avatar}
                          alt={account.platformName}
                          className="w-10 h-10 rounded-full object-cover border border-slate-200"
                        />
                        <span
                          className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-white ${
                            account.connected ? 'bg-emerald-500' : 'bg-slate-300'
                          }`}
                        />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-sm font-bold text-slate-900">
                            {account.platformName}
                          </span>
                          {account.connected && account.metrics.verified && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 fill-blue-50" />
                          )}
                        </div>
                        <div className="text-xs text-slate-500 font-mono">
                          {account.connected ? account.handle : 'Not Connected'}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {account.connected ? (
                        <>
                          <button
                            onClick={() => handleSync(account.platform)}
                            disabled={isSyncing}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors disabled:opacity-50"
                          >
                            <RefreshCw
                              className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`}
                            />
                            <span>Sync</span>
                          </button>
                          <button
                            onClick={() => handleDisconnect(account.platform)}
                            disabled={isSyncing}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-rose-600 hover:bg-rose-50 text-xs font-medium rounded-lg transition-colors"
                          >
                            Disconnect
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={() => handleConnect(account.platform)}
                          disabled={isSyncing}
                          className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg transition-colors shadow-xs"
                        >
                          <Link2 className="w-3.5 h-3.5" />
                          <span>Connect Account</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {account.connected && (
                    <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                      <div>
                        <span className="text-slate-400 block text-[11px]">Followers</span>
                        <span className="font-semibold text-slate-800 tabular-nums font-mono">
                          {formatIndianNumber(account.metrics.followers, false)}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Engagement</span>
                        <span className="font-semibold text-slate-800 tabular-nums font-mono">
                          {account.metrics.engagementRate}%
                        </span>
                      </div>
                      <div className="col-span-2 sm:col-span-1">
                        <span className="text-slate-400 block text-[11px]">Last Sync (IST)</span>
                        <span className="text-slate-600 font-sans text-[11px]">
                          {account.lastSyncAt ? formatIndianDate(account.lastSyncAt) : 'Never'}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>Indian Locale: en-IN · Timezone: Asia/Kolkata</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-white border border-slate-300 text-slate-700 rounded-lg font-medium hover:bg-slate-100 transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
