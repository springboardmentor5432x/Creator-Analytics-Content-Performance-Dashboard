import React, { useState } from 'react';
import {
  Users,
  Briefcase,
  IndianRupee,
  CheckSquare,
  TrendingUp,
  Search,
  Clock,
  ArrowUpRight,
  Calendar,
} from 'lucide-react';
import { AgencyDashboardData } from '../../types';
import {
  formatIndianNumber,
  formatIndianCurrency,
} from '../../utils/formatters';
import { StatCard } from '../common/StatCard';
import { MetricLineChart } from '../common/MetricLineChart';
import { MetricBarChart } from '../common/MetricBarChart';

interface AgencyDashboardProps {
  data: AgencyDashboardData;
}

export const AgencyDashboard: React.FC<AgencyDashboardProps> = ({ data }) => {
  const [creatorSearch, setCreatorSearch] = useState('');
  const { summary, monthlyRevenue, creators, campaigns, tasks } = data;

  const filteredCreators = creators.filter(c =>
    c.name.toLowerCase().includes(creatorSearch.toLowerCase()) ||
    c.niche.toLowerCase().includes(creatorSearch.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* KPI Cards in INR */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Agency Revenue"
          value={formatIndianCurrency(summary.totalRevenueINR, true)}
          change={summary.revenueGrowth}
          subtitle={`Full: ${formatIndianCurrency(summary.totalRevenueINR, false)}`}
          icon={<IndianRupee className="w-5 h-5" />}
          accentColor="purple"
        />
        <StatCard
          title="Agency Commission"
          value={formatIndianCurrency(summary.agencyCommissionINR, true)}
          change={summary.commissionGrowth}
          subtitle={`Net take: ${formatIndianCurrency(summary.agencyCommissionINR, false)}`}
          icon={<TrendingUp className="w-5 h-5" />}
          accentColor="blue"
        />
        <StatCard
          title="Assigned Creators"
          value={`${summary.activeCreators} / ${summary.totalAssignedCreators}`}
          subtitle="Active roster talent"
          icon={<Users className="w-5 h-5" />}
          accentColor="orange"
          badgeText="Active"
        />
        <StatCard
          title="Deliverables Rate"
          value={`${summary.deliverablesCompletedPercent}%`}
          subtitle={`${summary.pendingTasks} tasks pending review`}
          icon={<CheckSquare className="w-5 h-5" />}
          accentColor="emerald"
        />
      </div>

      {/* Revenue Growth Line Chart & Campaign Progress */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs">
          <MetricLineChart
            data={monthlyRevenue.map(item => ({
              label: item.month,
              value: item.revenue,
              secondaryValue: item.commission,
            }))}
            title="Monthly Gross Billing & Commission (INR)"
            subtitle="Verified brand campaign invoice receipts"
            isCurrency={true}
            primaryLabel="Gross Revenue"
            secondaryLabel="Commission"
            lineColor="#8B5CF6"
            secondaryLineColor="#3B82F6"
            height={260}
          />
        </div>

        {/* Active Client Campaigns & Progress */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">Active Campaigns</h3>
                <p className="text-xs text-slate-500 mt-0.5">{campaigns.length} campaigns in flight</p>
              </div>
              <span className="text-[11px] font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200/60 font-mono">
                Q4 Blitz
              </span>
            </div>

            <div className="space-y-4 mt-3">
              {campaigns.map(cmp => (
                <div key={cmp.id} className="p-3 bg-slate-50/70 rounded-xl border border-slate-200/60">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="text-xs font-bold text-slate-900 leading-tight">
                        {cmp.title}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">{cmp.brand}</div>
                    </div>
                    <span className="text-[10px] font-semibold text-slate-700 bg-white px-2 py-0.5 rounded border border-slate-200 shrink-0">
                      {cmp.status}
                    </span>
                  </div>

                  <div className="mt-3">
                    <div className="flex items-center justify-between text-[11px] mb-1">
                      <span className="text-slate-500">
                        Spend: {formatIndianCurrency(cmp.spendINR, true)} / {formatIndianCurrency(cmp.budgetINR, true)}
                      </span>
                      <span className="font-semibold text-purple-700 tabular-nums">
                        {cmp.progressPercent}%
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-purple-600 rounded-full"
                        style={{ width: `${cmp.progressPercent}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Creators Deployed:</span>
            <span className="font-semibold text-slate-800">15 Talent Nodes</span>
          </div>
        </div>
      </div>

      {/* Assigned Creators Roster & Operations Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Creators Table */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200/80 shadow-2xs overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Assigned Creator Roster
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Talent profiles, contract values in INR, and delivery reliability scores.
              </p>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 transform -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={creatorSearch}
                onChange={e => setCreatorSearch(e.target.value)}
                placeholder="Search creator or niche..."
                className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-purple-500 text-slate-800 placeholder-slate-400 w-48 sm:w-60"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/70 border-b border-slate-200/80 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  <th className="py-3 px-4">Creator</th>
                  <th className="py-3 px-3">Niche & Platform</th>
                  <th className="py-3 px-3 text-right">Followers</th>
                  <th className="py-3 px-3 text-right">Active Deals</th>
                  <th className="py-3 px-3 text-right">Contract Value</th>
                  <th className="py-3 px-4 text-right">Fulfillment</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredCreators.map(cr => (
                  <tr key={cr.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={cr.avatar}
                          alt={cr.name}
                          className="w-8 h-8 rounded-full object-cover border border-slate-200 shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="font-semibold text-slate-900">{cr.name}</div>
                          <div className="text-[11px] text-slate-400 capitalize">{cr.status}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="text-slate-800 font-medium">{cr.niche}</div>
                      <div className="text-[11px] text-purple-600 font-medium">{cr.primaryPlatform}</div>
                    </td>
                    <td className="py-3 px-3 text-right font-semibold text-slate-800 tabular-nums font-mono">
                      {formatIndianNumber(cr.followers, true)}
                    </td>
                    <td className="py-3 px-3 text-right text-slate-700 font-medium tabular-nums">
                      {cr.activeCampaigns}
                    </td>
                    <td className="py-3 px-3 text-right font-bold text-slate-900 tabular-nums font-mono">
                      {formatIndianCurrency(cr.contractValueINR, true)}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/60 font-mono">
                        {cr.completionRate}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Agency Action Tasks */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">Operational Tasks</h3>
                <p className="text-xs text-slate-500 mt-0.5">Deliverable approvals & payouts</p>
              </div>
              <span className="text-xs font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                {tasks.length} Pending
              </span>
            </div>

            <div className="space-y-3">
              {tasks.map(t => (
                <div key={t.id} className="p-3 rounded-lg border border-slate-200/70 hover:border-slate-300 transition-colors">
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-xs font-medium text-slate-800 leading-snug">
                      {t.title}
                    </span>
                    <span
                      className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded shrink-0 ${
                        t.priority === 'Urgent'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                          : t.priority === 'High'
                          ? 'bg-orange-50 text-orange-700 border border-orange-200'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {t.priority}
                    </span>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      {t.due}
                    </span>
                    <span className="font-medium text-purple-600">{t.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100">
            <button className="w-full py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-semibold transition-colors border border-slate-200">
              Manage Agency Tasks
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
