import React, { useState } from 'react';
import {
  DollarSign,
  TrendingUp,
  MousePointer,
  Target,
  BarChart2,
  PieChart,
  ArrowUpRight,
  ShieldCheck,
  Search,
  IndianRupee,
  Layers,
} from 'lucide-react';
import { MarketingDashboardData, WorkspaceRole } from '../../types';
import {
  formatIndianNumber,
  formatIndianCurrency,
} from '../../utils/formatters';
import { StatCard } from '../common/StatCard';
import { MetricLineChart } from '../common/MetricLineChart';
import { MetricBarChart } from '../common/MetricBarChart';
import { MetricDonutChart } from '../common/MetricDonutChart';

interface MarketingDashboardProps {
  data: MarketingDashboardData;
  activeRole: WorkspaceRole;
  onOpenRoleSwitch: () => void;
}

export const MarketingDashboard: React.FC<MarketingDashboardProps> = ({
  data,
  activeRole,
  onOpenRoleSwitch,
}) => {
  const [campaignSearch, setCampaignSearch] = useState('');
  const { summary, monthlyPerformance, channelSpendBreakdown, campaignComparisons } = data;

  const filteredCampaigns = campaignComparisons.filter(c =>
    c.name.toLowerCase().includes(campaignSearch.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Role authorization confirmation banner */}
      <div className="bg-emerald-50/60 border border-emerald-200/80 rounded-xl p-3 px-4 flex items-center justify-between text-xs text-emerald-800">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>
            Authorized Session: Authenticated as <strong className="uppercase font-mono">{activeRole}</strong>.
            Financial spend and ROAS metrics verified via RBAC middleware.
          </span>
        </div>
        <button
          onClick={onOpenRoleSwitch}
          className="text-emerald-700 hover:text-emerald-900 font-semibold underline shrink-0 hidden sm:inline"
        >
          Verify Permissions
        </button>
      </div>

      {/* KPI Cards in INR and Indian numbering */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Campaign Spend"
          value={formatIndianCurrency(summary.totalSpendINR, true)}
          change={summary.spendChangePercent}
          subtitle={`Full: ${formatIndianCurrency(summary.totalSpendINR, false)}`}
          icon={<IndianRupee className="w-5 h-5" />}
          accentColor="blue"
        />
        <StatCard
          title="Total Impressions"
          value={formatIndianNumber(summary.totalImpressions, true)}
          change={summary.impressionsChangePercent}
          subtitle={`Reach: ${formatIndianNumber(summary.totalReach, true)} unique users`}
          icon={<TrendingUp className="w-5 h-5" />}
          accentColor="purple"
        />
        <StatCard
          title="Paid Click Traffic"
          value={formatIndianNumber(summary.totalClicks, true)}
          change={summary.clicksChangePercent}
          subtitle={`CPC: ${formatIndianCurrency(summary.costPerClickINR, false)}`}
          icon={<MousePointer className="w-5 h-5" />}
          accentColor="orange"
        />
        <StatCard
          title="Average ROAS / ROI"
          value={`${summary.averageROI.toFixed(2)}x`}
          change={summary.roiChangePercent}
          subtitle={`CPA: ${formatIndianCurrency(summary.costPerAcquisitionINR, false)}`}
          icon={<Target className="w-5 h-5" />}
          accentColor="emerald"
        />
      </div>

      {/* Charts Row: Monthly Spend vs Impressions & Channel Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs">
          <MetricLineChart
            data={monthlyPerformance.map(m => ({
              label: m.month,
              value: m.spendINR,
              secondaryValue: m.conversions * 100, // Normalized for dual curve
            }))}
            title="Monthly Campaign Spend & Conversions"
            subtitle="Financial outlay in INR against acquisition volume"
            isCurrency={true}
            primaryLabel="Spend (INR)"
            secondaryLabel="Conversions (Scale 1:100)"
            lineColor="#3B82F6"
            secondaryLineColor="#10B981"
            height={260}
          />
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">Channel Spend Breakdown</h3>
                <p className="text-xs text-slate-500 mt-0.5">Media budget allocation (INR)</p>
              </div>
              <span className="text-[11px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200/60 font-mono">
                en-IN
              </span>
            </div>

            <MetricDonutChart
              data={channelSpendBreakdown.map(ch => ({
                label: ch.channel,
                value: ch.spendINR,
                percentage: ch.percentage,
                color: ch.color,
              }))}
              isCurrency={true}
              centerLabel="Total Spend"
              centerValue={formatIndianCurrency(summary.totalSpendINR, true)}
              size={170}
            />
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Primary Driver:</span>
            <span className="font-semibold text-slate-800">YouTube Video & Shorts (44.9%)</span>
          </div>
        </div>
      </div>

      {/* Campaign Comparisons Table */}
      <div className="bg-white rounded-xl border border-slate-200/80 shadow-2xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Campaign Comparisons & ROI Attribution
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Individual marketing sprint performance with revenue generated and ROAS in INR.
            </p>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 transform -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={campaignSearch}
              onChange={e => setCampaignSearch(e.target.value)}
              placeholder="Search campaigns..."
              className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500 text-slate-800 placeholder-slate-400 w-48 sm:w-64"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/70 border-b border-slate-200/80 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                <th className="py-3 px-4">Campaign Name</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3 text-right">Spend (INR)</th>
                <th className="py-3 px-3 text-right">Impressions</th>
                <th className="py-3 px-3 text-right">Clicks</th>
                <th className="py-3 px-3 text-right">Conversions</th>
                <th className="py-3 px-3 text-right">Revenue (INR)</th>
                <th className="py-3 px-3 text-right">CPC</th>
                <th className="py-3 px-3 text-right">CPA</th>
                <th className="py-3 px-4 text-right">ROAS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCampaigns.map(cmp => (
                <tr key={cmp.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3.5 px-4 font-semibold text-slate-900 max-w-xs">
                    {cmp.name}
                  </td>
                  <td className="py-3.5 px-3">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        cmp.status === 'Active'
                          ? 'bg-blue-50 text-blue-700 border border-blue-200'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {cmp.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-3 text-right font-bold text-slate-900 tabular-nums font-mono">
                    {formatIndianCurrency(cmp.spendINR, true)}
                  </td>
                  <td className="py-3.5 px-3 text-right text-slate-700 tabular-nums font-mono">
                    {formatIndianNumber(cmp.impressions, true)}
                  </td>
                  <td className="py-3.5 px-3 text-right text-slate-700 tabular-nums font-mono">
                    {formatIndianNumber(cmp.clicks, true)}
                  </td>
                  <td className="py-3.5 px-3 text-right font-semibold text-slate-800 tabular-nums font-mono">
                    {formatIndianNumber(cmp.conversions, true)}
                  </td>
                  <td className="py-3.5 px-3 text-right font-bold text-emerald-700 tabular-nums font-mono">
                    {formatIndianCurrency(cmp.revenueGeneratedINR, true)}
                  </td>
                  <td className="py-3.5 px-3 text-right text-slate-600 tabular-nums font-mono">
                    {formatIndianCurrency(cmp.cpcINR, false)}
                  </td>
                  <td className="py-3.5 px-3 text-right text-slate-600 tabular-nums font-mono">
                    {formatIndianCurrency(cmp.cpaINR, false)}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200/60 tabular-nums font-mono">
                      {cmp.roas.toFixed(2)}x
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
