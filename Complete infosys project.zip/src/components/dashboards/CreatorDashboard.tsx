import React, { useState } from 'react';
import {
  Users,
  Eye,
  Heart,
  MessageCircle,
  Share2,
  TrendingUp,
  IndianRupee,
  PlaySquare,
  Search,
  Filter,
} from 'lucide-react';
import { CreatorDashboardData, SocialAccount } from '../../types';
import {
  formatIndianNumber,
  formatIndianCurrency,
  formatIndianDate,
} from '../../utils/formatters';
import { StatCard } from '../common/StatCard';
import { MetricLineChart } from '../common/MetricLineChart';
import { MetricDonutChart } from '../common/MetricDonutChart';

interface CreatorDashboardProps {
  data: CreatorDashboardData;
  socialAccounts: SocialAccount[];
  onOpenIntegrations: () => void;
}

export const CreatorDashboard: React.FC<CreatorDashboardProps> = ({
  data,
  socialAccounts,
  onOpenIntegrations,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [platformFilter, setPlatformFilter] = useState<string>('all');

  const { summary, growthTimeline, platformBreakdown, topContent } = data;

  const filteredContent = topContent.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPlatform = platformFilter === 'all' || item.platform.toLowerCase() === platformFilter.toLowerCase();
    return matchesSearch && matchesPlatform;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* KPI Grid - Top 4 Primary Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Followers"
          value={formatIndianNumber(summary.totalFollowers, true)}
          change={summary.totalFollowersChange}
          subtitle={`Full: ${formatIndianNumber(summary.totalFollowers, false)}`}
          icon={<Users className="w-5 h-5" />}
          accentColor="blue"
        />
        <StatCard
          title="Total Views"
          value={formatIndianNumber(summary.totalViews, true)}
          change={summary.totalViewsChange}
          subtitle={`Full: ${formatIndianNumber(summary.totalViews, false)}`}
          icon={<Eye className="w-5 h-5" />}
          accentColor="purple"
        />
        <StatCard
          title="Total Reach"
          value={formatIndianNumber(summary.totalReach, true)}
          change={summary.totalReachChange}
          subtitle={`Audience across platforms`}
          icon={<TrendingUp className="w-5 h-5" />}
          accentColor="orange"
        />
        <StatCard
          title="Est. Creator Earnings"
          value={formatIndianCurrency(summary.estimatedEarningsINR, true)}
          change={summary.estimatedEarningsChange}
          subtitle={`Full: ${formatIndianCurrency(summary.estimatedEarningsINR, false)}`}
          icon={<IndianRupee className="w-5 h-5" />}
          accentColor="emerald"
        />
      </div>

      {/* Secondary Engagement Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white p-4 rounded-xl border border-slate-200/80 shadow-2xs">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-rose-50 text-rose-600">
            <Heart className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[11px] font-medium text-slate-500 uppercase">Total Likes</div>
            <div className="text-base font-bold text-slate-900 tabular-nums">
              {formatIndianNumber(summary.totalLikes, true)}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
            <MessageCircle className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[11px] font-medium text-slate-500 uppercase">Comments</div>
            <div className="text-base font-bold text-slate-900 tabular-nums">
              {formatIndianNumber(summary.totalComments, true)}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-purple-50 text-purple-600">
            <Share2 className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[11px] font-medium text-slate-500 uppercase">Shares</div>
            <div className="text-base font-bold text-slate-900 tabular-nums">
              {formatIndianNumber(summary.totalShares, true)}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
            <TrendingUp className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[11px] font-medium text-slate-500 uppercase">Avg Engagement</div>
            <div className="text-base font-bold text-slate-900 tabular-nums">
              {summary.engagementRate.toFixed(2)}%
            </div>
          </div>
        </div>
      </div>

      {/* Visual Charts: Growth Timeline & Platform Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs">
          <MetricLineChart
            data={growthTimeline.map(item => ({
              label: item.month,
              value: item.views,
              secondaryValue: item.followers,
            }))}
            title="Audience Reach & Viewership Growth"
            subtitle="Monthly verified growth metrics (en-IN scale)"
            primaryLabel="Monthly Views"
            secondaryLabel="Followers"
            lineColor="#3B82F6"
            secondaryLineColor="#8B5CF6"
            height={260}
          />
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">Platform Breakdown</h3>
                <p className="text-xs text-slate-500 mt-0.5">Follower share by network</p>
              </div>
              <button
                onClick={onOpenIntegrations}
                className="text-xs text-blue-600 font-semibold hover:underline"
              >
                Integrations
              </button>
            </div>

            <MetricDonutChart
              data={platformBreakdown.map(p => ({
                label: p.platform,
                value: p.followers,
                color: p.color,
                percentage: p.sharePercent,
              }))}
              centerLabel="Total Reach"
              centerValue={formatIndianNumber(summary.totalFollowers, true)}
              size={170}
            />
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Connected Networks:</span>
            <span className="font-semibold text-slate-800">
              {socialAccounts.filter(a => a.connected).length} of {socialAccounts.length}
            </span>
          </div>
        </div>
      </div>

      {/* Content Performance Section */}
      <div className="bg-white rounded-xl border border-slate-200/80 shadow-2xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Recent Content Performance
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Verified analytics for published videos, posts, and threads with earnings in INR.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 transform -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search content..."
                className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500 text-slate-800 placeholder-slate-400 w-44 sm:w-56"
              />
            </div>

            {/* Filter */}
            <select
              value={platformFilter}
              onChange={e => setPlatformFilter(e.target.value)}
              className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 focus:outline-hidden"
            >
              <option value="all">All Channels</option>
              <option value="youtube">YouTube</option>
              <option value="instagram">Instagram</option>
              <option value="x">X</option>
            </select>
          </div>
        </div>

        {/* Content Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/70 border-b border-slate-200/80 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                <th className="py-3 px-4">Content Title</th>
                <th className="py-3 px-3">Platform</th>
                <th className="py-3 px-3 text-right">Views</th>
                <th className="py-3 px-3 text-right">Likes</th>
                <th className="py-3 px-3 text-right">Comments</th>
                <th className="py-3 px-3 text-right">Shares</th>
                <th className="py-3 px-3 text-right">Engagement</th>
                <th className="py-3 px-4 text-right">Earnings (INR)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredContent.map(item => (
                <tr key={item.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3.5 px-4 font-medium text-slate-900 max-w-xs">
                    <div className="truncate font-semibold">{item.title}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {formatIndianDate(item.publishedAt, false)}
                    </div>
                  </td>
                  <td className="py-3.5 px-3">
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700">
                      {item.platform}
                    </span>
                  </td>
                  <td className="py-3.5 px-3 text-right font-semibold text-slate-800 tabular-nums font-mono">
                    {formatIndianNumber(item.views, true)}
                  </td>
                  <td className="py-3.5 px-3 text-right text-slate-600 tabular-nums font-mono">
                    {formatIndianNumber(item.likes, true)}
                  </td>
                  <td className="py-3.5 px-3 text-right text-slate-600 tabular-nums font-mono">
                    {formatIndianNumber(item.comments, true)}
                  </td>
                  <td className="py-3.5 px-3 text-right text-slate-600 tabular-nums font-mono">
                    {formatIndianNumber(item.shares, true)}
                  </td>
                  <td className="py-3.5 px-3 text-right font-medium text-emerald-600 tabular-nums font-mono">
                    {item.engagementRate}%
                  </td>
                  <td className="py-3.5 px-4 text-right font-bold text-slate-900 tabular-nums font-mono">
                    {formatIndianCurrency(item.revenueINR, false)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
