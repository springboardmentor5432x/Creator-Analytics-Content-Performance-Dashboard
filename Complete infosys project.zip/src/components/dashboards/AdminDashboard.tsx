import React, { useState } from 'react';
import {
  Users,
  ShieldAlert,
  Server,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Search,
  Lock,
  Cpu,
  Database,
  RefreshCw,
} from 'lucide-react';
import { AdminDashboardData } from '../../types';
import {
  formatIndianNumber,
  formatIndianDate,
} from '../../utils/formatters';
import { StatCard } from '../common/StatCard';
import { MetricDonutChart } from '../common/MetricDonutChart';

interface AdminDashboardProps {
  data: AdminDashboardData;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ data }) => {
  const [logSearch, setLogSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const { summary, roleDistribution, systemHealth, auditLogs } = data;

  const filteredLogs = auditLogs.filter(log => {
    const matchesSearch =
      log.action.toLowerCase().includes(logSearch.toLowerCase()) ||
      log.user.toLowerCase().includes(logSearch.toLowerCase()) ||
      log.details.toLowerCase().includes(logSearch.toLowerCase());
    const matchesStatus =
      statusFilter === 'all' || log.status.toLowerCase() === statusFilter.toLowerCase();
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Registered Users"
          value={formatIndianNumber(summary.totalRegisteredUsers, false)}
          change={summary.activeUsersGrowth}
          subtitle={`Active Today: ${formatIndianNumber(summary.activeUsersToday, false)}`}
          icon={<Users className="w-5 h-5" />}
          accentColor="blue"
        />
        <StatCard
          title="Active Workspaces"
          value={`${summary.activeWorkspaces} / ${summary.totalWorkspaces}`}
          subtitle="Enterprise & Agency tenants"
          icon={<Server className="w-5 h-5" />}
          accentColor="purple"
          badgeText="Healthy"
        />
        <StatCard
          title="API Requests (24h)"
          value={formatIndianNumber(summary.apiRequestsToday, true)}
          subtitle={`Avg latency: ${summary.averageLatencyMs}ms`}
          icon={<Activity className="w-5 h-5" />}
          accentColor="orange"
        />
        <StatCard
          title="System Availability"
          value={`${summary.apiUptimePercent}%`}
          subtitle={`${summary.securityAlertsCount} security flags`}
          icon={<CheckCircle2 className="w-5 h-5" />}
          accentColor="emerald"
        />
      </div>

      {/* System Health Indicators & Role Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* System Health */}
        <div className="lg:col-span-2 bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">Platform System Health</h3>
              <p className="text-xs text-slate-500 mt-0.5">Real-time infrastructure & database telemetry</p>
            </div>
            <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200/60 font-mono">
              ALL SYSTEMS OPERATIONAL
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-2">
            <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200/60">
              <div className="flex items-center gap-2 text-slate-500 text-xs mb-1">
                <Server className="w-3.5 h-3.5 text-blue-600" />
                <span>API Status</span>
              </div>
              <div className="text-base font-bold text-slate-900">{systemHealth.apiStatus}</div>
              <div className="text-[11px] text-slate-400 mt-0.5 font-mono">Cloud Run (IN-West)</div>
            </div>

            <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200/60">
              <div className="flex items-center gap-2 text-slate-500 text-xs mb-1">
                <Database className="w-3.5 h-3.5 text-purple-600" />
                <span>DB Latency</span>
              </div>
              <div className="text-base font-bold text-slate-900 tabular-nums font-mono">{systemHealth.dbLatency}</div>
              <div className="text-[11px] text-slate-400 mt-0.5 font-mono">Firestore & Relational</div>
            </div>

            <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200/60">
              <div className="flex items-center gap-2 text-slate-500 text-xs mb-1">
                <Cpu className="w-3.5 h-3.5 text-orange-600" />
                <span>Cache Hit Rate</span>
              </div>
              <div className="text-base font-bold text-slate-900 tabular-nums font-mono">{systemHealth.cacheHitRate}</div>
              <div className="text-[11px] text-slate-400 mt-0.5 font-mono">Edge CDN active</div>
            </div>

            <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200/60">
              <div className="flex items-center gap-2 text-slate-500 text-xs mb-1">
                <RefreshCw className="w-3.5 h-3.5 text-emerald-600" />
                <span>Rate Limits</span>
              </div>
              <div className="text-base font-bold text-slate-900 tabular-nums font-mono">{systemHealth.rateLimitHeadroom}</div>
              <div className="text-[11px] text-slate-400 mt-0.5 font-mono">Headroom remaining</div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Last Automated Cloud Snapshot:</span>
            <span className="font-mono text-[11px] text-slate-700">
              {formatIndianDate(systemHealth.lastBackupAt)}
            </span>
          </div>
        </div>

        {/* Workspace Roles Distribution */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">Workspace Roles</h3>
                <p className="text-xs text-slate-500 mt-0.5">Active user distribution</p>
              </div>
              <span className="text-[11px] font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded font-mono">
                RBAC
              </span>
            </div>

            <MetricDonutChart
              data={roleDistribution.map(r => ({
                label: r.role,
                value: r.count,
                percentage: r.percentage,
                color: r.color,
              }))}
              centerLabel="Total Users"
              centerValue={formatIndianNumber(summary.totalRegisteredUsers, true)}
              size={170}
            />
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>RBAC Verification:</span>
            <span className="font-semibold text-emerald-700">Active Strict</span>
          </div>
        </div>
      </div>

      {/* Security & Audit Logs Table */}
      <div className="bg-white rounded-xl border border-slate-200/80 shadow-2xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Security & Workspace Audit Logs
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Immutable audit trail of authentication events, data exports, and RBAC actions.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 transform -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={logSearch}
                onChange={e => setLogSearch(e.target.value)}
                placeholder="Search audit trail..."
                className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-slate-800 placeholder-slate-400 w-44 sm:w-56"
              />
            </div>

            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 focus:outline-hidden"
            >
              <option value="all">All Statuses</option>
              <option value="success">Success</option>
              <option value="blocked">Blocked</option>
              <option value="warning">Warning</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/70 border-b border-slate-200/80 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                <th className="py-3 px-4">Event Action</th>
                <th className="py-3 px-3">User & Role</th>
                <th className="py-3 px-4">Details</th>
                <th className="py-3 px-3">IP / Location</th>
                <th className="py-3 px-3">Timestamp (IST)</th>
                <th className="py-3 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLogs.map(log => (
                <tr key={log.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                    {log.action}
                  </td>
                  <td className="py-3.5 px-3">
                    <div className="font-medium text-slate-900">{log.user}</div>
                    <div className="text-[10px] text-slate-400 uppercase font-mono">{log.role}</div>
                  </td>
                  <td className="py-3.5 px-4 text-slate-600 max-w-xs truncate">
                    {log.details}
                  </td>
                  <td className="py-3.5 px-3 text-slate-500 font-mono text-[11px]">
                    {log.ipAddress}
                  </td>
                  <td className="py-3.5 px-3 text-slate-600 font-mono text-[11px]">
                    {formatIndianDate(log.timestamp, true)}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        log.status === 'Success'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60'
                          : log.status === 'Blocked'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200/60'
                          : 'bg-amber-50 text-amber-700 border border-amber-200/60'
                      }`}
                    >
                      {log.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
