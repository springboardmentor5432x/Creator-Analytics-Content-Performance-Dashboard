import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  RefreshCw, 
  ExternalLink, 
  Key, 
  ShieldCheck, 
  Unlink, 
  Link as LinkIcon, 
  Sparkles,
  ChevronRight,
  Info,
  Sliders,
  Check,
  AlertTriangle,
  Copy,
  Shield
} from 'lucide-react';
import { socialService } from '../../services/api';
import { 
  SupportedPlatform, 
  ConnectedPlatformAccount, 
  PlatformDeveloperConfig,
  PlatformConnectionStatus,
  OAuthUrlResponse
} from '../../types/auth';

interface SocialAccountsManagerProps {
  onAccountSynced?: () => void;
  className?: string;
}

export const SocialAccountsManager: React.FC<SocialAccountsManagerProps> = ({ 
  onAccountSynced,
  className = '' 
}) => {
  const [accounts, setAccounts] = useState<ConnectedPlatformAccount[]>([]);
  const [developerConfigs, setDeveloperConfigs] = useState<Record<SupportedPlatform, PlatformDeveloperConfig>>({} as any);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSyncingAll, setIsSyncingAll] = useState<boolean>(false);
  const [syncingPlatform, setSyncingPlatform] = useState<SupportedPlatform | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Modal states
  const [selectedConfigForModal, setSelectedConfigForModal] = useState<PlatformDeveloperConfig | null>(null);
  const [connectModalPlatform, setConnectModalPlatform] = useState<SupportedPlatform | null>(null);
  const [connectHandleInput, setConnectHandleInput] = useState<string>('');
  const [connectApiKeyInput, setConnectApiKeyInput] = useState<string>('');
  const [isConnecting, setIsConnecting] = useState<boolean>(false);
  const [oauthStatus, setOauthStatus] = useState<OAuthUrlResponse | null>(null);
  const [isLoadingOAuth, setIsLoadingOAuth] = useState<boolean>(false);
  const [copiedRedirectUri, setCopiedRedirectUri] = useState<boolean>(false);
  const [connectMode, setConnectMode] = useState<'oauth' | 'token' | 'handle'>('oauth');

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [platformsRes, accountsRes] = await Promise.all([
        socialService.getPlatforms(),
        socialService.getConnectedAccounts()
      ]);

      if (platformsRes.success && platformsRes.platforms) {
        const configMap = platformsRes.platforms.reduce((acc, curr) => {
          acc[curr.platform] = curr;
          return acc;
        }, {} as Record<SupportedPlatform, PlatformDeveloperConfig>);
        setDeveloperConfigs(configMap);
      }

      if (accountsRes.success && accountsRes.accounts) {
        setAccounts(accountsRes.accounts);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load social platform connections.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();

    // Listen for OAuth completion from popup window
    const handleAuthMessage = (event: MessageEvent) => {
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS' || event.data?.type === 'YOUTUBE_AUTH_SUCCESS') {
        const platform = event.data?.platform || 'youtube';
        triggerToast(`${platform.toUpperCase()} authorized and connected successfully via Official OAuth!`);
        setConnectModalPlatform(null);
        loadData();
        if (onAccountSynced) onAccountSynced();
      }
    };
    window.addEventListener('message', handleAuthMessage);
    return () => window.removeEventListener('message', handleAuthMessage);
  }, []);

  // When connect modal opens, query OAuth configuration state
  useEffect(() => {
    if (!connectModalPlatform) {
      setOauthStatus(null);
      return;
    }
    const checkOAuth = async () => {
      setIsLoadingOAuth(true);
      try {
        const res = await socialService.getAuthUrl(connectModalPlatform);
        setOauthStatus(res);
        if (res.configured) {
          setConnectMode('oauth');
        } else {
          setConnectMode('oauth');
        }
      } catch {
        setOauthStatus(null);
        setConnectMode('handle');
      } finally {
        setIsLoadingOAuth(false);
      }
    };
    checkOAuth();
  }, [connectModalPlatform]);

  const handleStartOAuthPopup = async (platform: SupportedPlatform) => {
    setIsLoadingOAuth(true);
    try {
      const res = await socialService.getAuthUrl(platform);
      setOauthStatus(res);
      if (res.success && res.configured && res.authUrl) {
        const width = 600;
        const height = 700;
        const left = window.screenX + (window.outerWidth - width) / 2;
        const top = window.screenY + (window.outerHeight - height) / 2;
        window.open(
          res.authUrl,
          `oauth_${platform}`,
          `width=${width},height=${height},left=${left},top=${top},status=yes,scrollbars=yes`
        );
      }
    } catch (err: any) {
      setError(`OAuth initialization failed: ${err.message}`);
    } finally {
      setIsLoadingOAuth(false);
    }
  };

  const triggerToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 4000);
  };

  const handleSyncPlatform = async (platform: SupportedPlatform) => {
    setSyncingPlatform(platform);
    try {
      const res = await socialService.syncAccount(platform);
      if (res.success && res.account) {
        setAccounts(prev => prev.map(acc => acc.platform === platform ? res.account : acc));
        triggerToast(`${res.account.displayName} successfully synchronized!`);
        if (onAccountSynced) onAccountSynced();
      }
    } catch (err: any) {
      setError(`Failed to synchronize ${platform}: ${err.message}`);
    } finally {
      setSyncingPlatform(null);
    }
  };

  const handleSyncAll = async () => {
    setIsSyncingAll(true);
    try {
      const res = await socialService.syncAll();
      if (res.success && res.accounts) {
        setAccounts(res.accounts);
        triggerToast(`All ${res.syncedCount} connected accounts synchronized!`);
        if (onAccountSynced) onAccountSynced();
      }
    } catch (err: any) {
      setError(`Sync all failed: ${err.message}`);
    } finally {
      setIsSyncingAll(false);
    }
  };

  const handleDisconnect = async (platform: SupportedPlatform) => {
    if (!window.confirm(`Are you sure you want to disconnect ${platform}? Analytics snapshots will be retained.`)) {
      return;
    }
    try {
      const res = await socialService.disconnectAccount(platform);
      if (res.success) {
        setAccounts(prev => prev.map(acc => 
          acc.platform === platform 
            ? { ...acc, status: 'disconnected', followersOrSubscribers: 0, postsOrVideosCount: 0 } 
            : acc
        ));
        triggerToast(`${platform} account disconnected.`);
        if (onAccountSynced) onAccountSynced();
      }
    } catch (err: any) {
      setError(`Failed to disconnect: ${err.message}`);
    }
  };

  const handleConnectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!connectModalPlatform || !connectHandleInput.trim()) return;

    setIsConnecting(true);
    try {
      const res = await socialService.connectAccount(connectModalPlatform, {
        handleOrIdentifier: connectHandleInput.trim(),
        apiKeyOrToken: connectApiKeyInput.trim() || undefined
      });

      if (res.success && res.account) {
        setAccounts(prev => {
          const exists = prev.some(a => a.platform === connectModalPlatform);
          if (exists) {
            return prev.map(a => a.platform === connectModalPlatform ? res.account : a);
          }
          return [...prev, res.account];
        });
        triggerToast(`Successfully connected @${res.account.accountHandle} on ${res.account.displayName}!`);
        setConnectModalPlatform(null);
        setConnectHandleInput('');
        setConnectApiKeyInput('');
        if (onAccountSynced) onAccountSynced();
      }
    } catch (err: any) {
      setError(`Connection failed: ${err.message}`);
    } finally {
      setIsConnecting(false);
    }
  };

  const getPlatformIcon = (platform: SupportedPlatform) => {
    switch (platform) {
      case 'youtube':
        return '▶️';
      case 'instagram':
        return '📸';
      case 'tiktok':
        return '🎵';
      case 'facebook':
        return '👥';
      case 'whatsapp':
        return '💬';
      case 'snapchat':
        return '👻';
      case 'x':
      case 'twitter' as any:
        return '𝕏';
      case 'linkedin':
        return '💼';
      default:
        return '🌐';
    }
  };

  const getStatusBadge = (status: PlatformConnectionStatus) => {
    switch (status) {
      case 'connected':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <CheckCircle2 className="w-3 h-3" /> Connected
          </span>
        );
      case 'syncing':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">
            <RefreshCw className="w-3 h-3 animate-spin" /> Syncing
          </span>
        );
      case 'setup_required':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <AlertCircle className="w-3 h-3" /> Setup Needed
          </span>
        );
      case 'error':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-red-500/10 text-red-400 border border-red-500/20">
            <AlertTriangle className="w-3 h-3" /> Sync Error
          </span>
        );
      case 'disconnected':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-700/50 text-slate-400 border border-slate-700">
            <Unlink className="w-3 h-3" /> Not Connected
          </span>
        );
    }
  };

  // Quick summary counts
  const connectedCount = accounts.filter(a => a.status === 'connected').length;
  const totalFollowers = accounts.reduce((acc, curr) => acc + (curr.followersOrSubscribers || 0), 0);

  return (
    <div className={`bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl ${className}`}>
      {/* Toast Alert */}
      {successToast && (
        <div className="mb-4 p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center justify-between">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            {successToast}
          </span>
          <button onClick={() => setSuccessToast(null)} className="text-emerald-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Global Error Banner */}
      {error && (
        <div className="mb-4 p-3 bg-red-500/15 border border-red-500/30 rounded-xl text-xs text-red-300 flex items-center justify-between">
          <span className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
            {error}
          </span>
          <button onClick={() => setError(null)} className="text-red-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Header and Sync All Action */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-xl font-bold text-white tracking-tight">Connected Social Media Accounts</h3>
            <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              {connectedCount} of {accounts.length || 8} Active
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Official OAuth integrations, live follower counts, and multi-channel synchronization across 8 major creator platforms.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden sm:block text-right pr-2">
            <div className="text-[11px] text-slate-400">Total Combined Reach</div>
            <div className="text-sm font-bold text-white font-mono">{totalFollowers.toLocaleString()} audience</div>
          </div>

          <button
            onClick={handleSyncAll}
            disabled={isSyncingAll || connectedCount === 0}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 disabled:opacity-50 disabled:pointer-events-none rounded-xl transition-all shadow-md shadow-indigo-600/20"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncingAll ? 'animate-spin' : ''}`} />
            <span>{isSyncingAll ? 'Syncing All...' : 'Sync All Accounts'}</span>
          </button>
        </div>
      </div>

      {/* Platform Cards Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 py-8">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="animate-pulse bg-slate-800/40 rounded-xl p-4 border border-slate-800 h-48" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          {accounts.map((acc) => {
            const config = developerConfigs[acc.platform];
            const isCurrentlySyncing = syncingPlatform === acc.platform || isSyncingAll;
            const isConnected = acc.status === 'connected';

            return (
              <div 
                key={acc.platform}
                className={`flex flex-col justify-between bg-slate-800/30 hover:bg-slate-800/60 border rounded-xl p-4 transition-all duration-200 ${
                  isConnected ? 'border-slate-700/80' : 'border-slate-800/60 opacity-85 hover:opacity-100'
                }`}
              >
                <div>
                  {/* Top: Icon, Name & Status */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700/70 flex items-center justify-center text-xl flex-shrink-0">
                        {getPlatformIcon(acc.platform)}
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white flex items-center gap-1">
                          {acc.displayName}
                        </h4>
                        <span className="text-[11px] text-slate-400 font-mono block truncate max-w-[110px]">
                          {acc.accountHandle ? `@${acc.accountHandle}` : 'Unconnected'}
                        </span>
                      </div>
                    </div>
                    {getStatusBadge(isCurrentlySyncing ? 'syncing' : acc.status)}
                  </div>

                  {/* WhatsApp Distinction Notice */}
                  {acc.platform === 'whatsapp' && (
                    <div className="mb-2 p-1.5 bg-emerald-500/5 border border-emerald-500/15 rounded-lg text-[10px] text-emerald-300/80 leading-tight">
                      <strong>Enterprise API:</strong> Cloud messaging interactions (not consumer chats).
                    </div>
                  )}

                  {/* Metrics preview if connected */}
                  {isConnected ? (
                    <div className="space-y-1.5 my-3 p-2.5 bg-slate-900/60 rounded-lg border border-slate-800 text-xs">
                      <div className="flex items-center justify-between text-slate-300">
                        <span className="text-[11px] text-slate-400">
                          {acc.platform === 'youtube' ? 'Subscribers' : acc.platform === 'whatsapp' ? 'Subscribed Contacts' : 'Followers'}:
                        </span>
                        <strong className="text-white font-mono">
                          {acc.followersOrSubscribers.toLocaleString()}
                        </strong>
                      </div>
                      <div className="flex items-center justify-between text-slate-300">
                        <span className="text-[11px] text-slate-400">
                          {acc.platform === 'whatsapp' ? 'Broadcasts / Campaigns' : 'Published Content'}:
                        </span>
                        <span className="text-slate-300 font-mono">
                          {acc.postsOrVideosCount.toLocaleString()}
                        </span>
                      </div>
                      {acc.engagementRate !== undefined && (
                        <div className="flex items-center justify-between text-slate-300">
                          <span className="text-[11px] text-slate-400">Engagement:</span>
                          <span className="text-emerald-400 font-mono font-medium">
                            {acc.engagementRate}%
                          </span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="my-3 p-3 bg-slate-900/30 rounded-lg border border-slate-800/80 text-[11px] text-slate-400 text-center">
                      <p>Connect your account to sync followers, engagement, and post reach.</p>
                    </div>
                  )}

                  {/* Sync Timestamp */}
                  <div className="text-[10px] text-slate-500 flex items-center gap-1 mb-3">
                    <Clock className="w-3 h-3 flex-shrink-0" />
                    <span className="truncate">
                      {acc.lastSyncedAt 
                        ? `Last synced: ${new Date(acc.lastSyncedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` 
                        : 'Never synced'}
                    </span>
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="space-y-2 pt-3 border-t border-slate-800/80">
                  <div className="flex items-center gap-1.5">
                    {isConnected ? (
                      <>
                        <button
                          onClick={() => handleSyncPlatform(acc.platform)}
                          disabled={isCurrentlySyncing}
                          className="flex-1 flex items-center justify-center gap-1 py-1.5 px-2 bg-slate-800 hover:bg-slate-700 active:bg-slate-800 text-white text-xs font-medium rounded-lg transition-colors border border-slate-700 disabled:opacity-50"
                          title="Fetch latest platform metrics"
                        >
                          <RefreshCw className={`w-3 h-3 ${isCurrentlySyncing ? 'animate-spin text-indigo-400' : ''}`} />
                          <span>{isCurrentlySyncing ? 'Syncing...' : 'Sync'}</span>
                        </button>
                        <button
                          onClick={() => handleDisconnect(acc.platform)}
                          className="p-1.5 bg-slate-800/60 hover:bg-red-500/20 text-slate-400 hover:text-red-400 rounded-lg transition-colors border border-slate-700/60"
                          title="Disconnect account"
                        >
                          <Unlink className="w-3.5 h-3.5" />
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => {
                          setConnectModalPlatform(acc.platform);
                          setConnectHandleInput('');
                          setConnectApiKeyInput('');
                        }}
                        className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 bg-indigo-600/90 hover:bg-indigo-600 active:bg-indigo-700 text-white text-xs font-semibold rounded-lg transition-colors shadow-sm"
                      >
                        <LinkIcon className="w-3 h-3" />
                        <span>Connect {acc.displayName}</span>
                      </button>
                    )}
                  </div>

                  {/* Developer Guide Trigger */}
                  {config && (
                    <button
                      onClick={() => setSelectedConfigForModal(config)}
                      className="w-full text-center text-[10px] text-slate-400 hover:text-indigo-300 font-medium transition-colors flex items-center justify-center gap-1"
                    >
                      <Info className="w-2.5 h-2.5" />
                      <span>API Requirements & Permissions</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Developer API & Scopes Guide Modal */}
      {selectedConfigForModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <span className="text-2xl">{getPlatformIcon(selectedConfigForModal.platform)}</span>
                <div>
                  <h4 className="text-base font-bold text-white">
                    {selectedConfigForModal.displayName} Integration Architecture
                  </h4>
                  <p className="text-xs text-slate-400 font-mono">
                    {selectedConfigForModal.officialApiName}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedConfigForModal(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs">
              {/* Review status and Auth method badge */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-1 bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 rounded-lg font-semibold">
                  Auth: {selectedConfigForModal.authMethod}
                </span>
                <span className="px-2.5 py-1 bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 rounded-lg font-semibold">
                  Status: {selectedConfigForModal.reviewStatus}
                </span>
              </div>

              {/* Prerequisites & Developer App */}
              <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-800">
                <span className="text-slate-400 font-medium block mb-1">Developer Requirements & Approval:</span>
                <p className="text-slate-200 leading-relaxed">
                  {selectedConfigForModal.prerequisites}
                </p>
              </div>

              {/* Required OAuth Scopes */}
              <div>
                <span className="text-slate-400 font-medium block mb-1.5">Required OAuth Scopes:</span>
                <div className="flex flex-wrap gap-1.5">
                  {selectedConfigForModal.requiredScopes.map((scope, idx) => (
                    <span 
                      key={idx}
                      className="px-2 py-0.5 bg-slate-800 text-slate-300 font-mono text-[10px] rounded border border-slate-700"
                    >
                      {scope}
                    </span>
                  ))}
                </div>
              </div>

              {/* Supported Platform Metrics */}
              <div>
                <span className="text-slate-400 font-medium block mb-1.5">Supported Data Metrics:</span>
                <div className="grid grid-cols-2 gap-1.5">
                  {selectedConfigForModal.supportedMetrics.map((metric, idx) => (
                    <div key={idx} className="flex items-center gap-1.5 text-slate-300 text-[11px]">
                      <Check className="w-3 h-3 text-emerald-400 flex-shrink-0" />
                      <span>{metric}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Rate Limits & Policies */}
              <div className="p-2.5 bg-slate-800/30 rounded-lg border border-slate-800 text-[11px] text-slate-400">
                <strong className="text-slate-300">Rate Limits & Policies:</strong> {selectedConfigForModal.rateLimits}
              </div>

              {selectedConfigForModal.notes && (
                <div className="p-2.5 bg-amber-500/10 rounded-lg border border-amber-500/20 text-[11px] text-amber-200">
                  <strong className="text-amber-300">Note:</strong> {selectedConfigForModal.notes}
                </div>
              )}

              {/* Developer Portal Link */}
              <div className="pt-2 flex items-center justify-between">
                <span className="text-slate-400">Official Developer Documentation:</span>
                <a
                  href={selectedConfigForModal.developerPortalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-semibold"
                >
                  <span>Developer Portal</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedConfigForModal(null)}
                className="px-4 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition-colors"
              >
                Close Guide
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Connect Account Form Modal */}
      {connectModalPlatform && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-2xl shrink-0">
                  {getPlatformIcon(connectModalPlatform)}
                </div>
                <div>
                  <h4 className="text-base font-bold text-white flex items-center gap-2">
                    Connect {developerConfigs[connectModalPlatform]?.displayName || connectModalPlatform}
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-mono">
                      Official API
                    </span>
                  </h4>
                  <p className="text-xs text-slate-400">
                    Authorize real-time follower counts, views, reach, and performance
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setConnectModalPlatform(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
              >
                ✕
              </button>
            </div>

            {/* Connection Method Tabs */}
            <div className="flex border-b border-slate-800 mt-4 mb-4">
              <button
                type="button"
                onClick={() => setConnectMode('oauth')}
                className={`flex-1 py-2 text-xs font-semibold border-b-2 transition-all flex items-center justify-center gap-1.5 ${
                  connectMode === 'oauth'
                    ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
                    : 'border-transparent text-slate-400 hover:text-slate-300'
                }`}
              >
                <Shield className="w-3.5 h-3.5" />
                <span>Official OAuth 2.0</span>
              </button>
              <button
                type="button"
                onClick={() => setConnectMode('token')}
                className={`flex-1 py-2 text-xs font-semibold border-b-2 transition-all flex items-center justify-center gap-1.5 ${
                  connectMode === 'token'
                    ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
                    : 'border-transparent text-slate-400 hover:text-slate-300'
                }`}
              >
                <Key className="w-3.5 h-3.5" />
                <span>API Key / Token</span>
              </button>
              <button
                type="button"
                onClick={() => setConnectMode('handle')}
                className={`flex-1 py-2 text-xs font-semibold border-b-2 transition-all flex items-center justify-center gap-1.5 ${
                  connectMode === 'handle'
                    ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
                    : 'border-transparent text-slate-400 hover:text-slate-300'
                }`}
              >
                <LinkIcon className="w-3.5 h-3.5" />
                <span>Channel / Handle</span>
              </button>
            </div>

            {/* Mode 1: Official OAuth 2.0 Flow */}
            {connectMode === 'oauth' && (
              <div className="space-y-4 text-xs">
                {isLoadingOAuth ? (
                  <div className="py-8 text-center text-slate-400">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-400" />
                    <span>Verifying OAuth endpoints and environment secrets...</span>
                  </div>
                ) : oauthStatus?.configured && oauthStatus?.authUrl ? (
                  <div className="space-y-3">
                    <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-start gap-2.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <div>
                        <strong className="block font-semibold">Official OAuth Ready</strong>
                        Click below to open the secure authorization popup. Tokens will be exchanged server-side and kept strictly confidential.
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleStartOAuthPopup(connectModalPlatform)}
                      className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <ExternalLink className="w-4 h-4" />
                      <span>Authorize with {developerConfigs[connectModalPlatform]?.displayName || connectModalPlatform}</span>
                    </button>

                    <p className="text-[11px] text-slate-400 text-center">
                      Authorizes read-only permissions for views, follower counts, and reach. CreatorIQ never requests write or billing access.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2.5">
                      <div className="flex items-center gap-2 text-indigo-300 font-semibold">
                        <Info className="w-4 h-4 text-indigo-400 shrink-0" />
                        <span>Google Cloud / Developer OAuth Setup Required</span>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        To enable one-click OAuth login, configure your developer app credentials in the server environment variables.
                      </p>

                      {/* Required Env Vars */}
                      <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 font-mono text-[11px] text-slate-300">
                        <span className="text-slate-500 text-[10px] block uppercase font-bold mb-1">Required Environment Variables:</span>
                        {connectModalPlatform === 'youtube' && (
                          <div className="space-y-0.5">
                            <div><code className="text-indigo-400 font-bold">YOUTUBE_CLIENT_ID</code>: Google OAuth Client ID</div>
                            <div><code className="text-indigo-400 font-bold">YOUTUBE_CLIENT_SECRET</code>: Google OAuth Client Secret</div>
                            <div><code className="text-slate-400 font-bold">YOUTUBE_API_KEY</code>: (Optional) YouTube Data API v3 key</div>
                          </div>
                        )}
                        {connectModalPlatform === 'instagram' && (
                          <div><code className="text-indigo-400 font-bold">META_APP_ID</code> &amp; <code className="text-indigo-400 font-bold">META_APP_SECRET</code></div>
                        )}
                        {connectModalPlatform === 'facebook' && (
                          <div><code className="text-indigo-400 font-bold">META_APP_ID</code> &amp; <code className="text-indigo-400 font-bold">META_APP_SECRET</code></div>
                        )}
                        {connectModalPlatform === 'whatsapp' && (
                          <div><code className="text-indigo-400 font-bold">WHATSAPP_PHONE_NUMBER_ID</code> &amp; <code className="text-indigo-400 font-bold">WHATSAPP_ACCESS_TOKEN</code></div>
                        )}
                        {(connectModalPlatform === 'x' || (connectModalPlatform as any) === 'twitter') && (
                          <div><code className="text-indigo-400 font-bold">X_CLIENT_ID</code> &amp; <code className="text-indigo-400 font-bold">X_CLIENT_SECRET</code></div>
                        )}
                        {connectModalPlatform === 'linkedin' && (
                          <div><code className="text-indigo-400 font-bold">LINKEDIN_CLIENT_ID</code> &amp; <code className="text-indigo-400 font-bold">LINKEDIN_CLIENT_SECRET</code></div>
                        )}
                        {connectModalPlatform === 'tiktok' && (
                          <div><code className="text-indigo-400 font-bold">TIKTOK_CLIENT_KEY</code> &amp; <code className="text-indigo-400 font-bold">TIKTOK_CLIENT_SECRET</code></div>
                        )}
                      </div>

                      {/* Redirect URI Box with Copy */}
                      <div>
                        <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                          <span>Authorized OAuth Redirect URI:</span>
                          <button
                            type="button"
                            onClick={() => {
                              const uri = `${window.location.origin}/oauth/${connectModalPlatform}/callback`;
                              navigator.clipboard.writeText(uri);
                              setCopiedRedirectUri(true);
                              setTimeout(() => setCopiedRedirectUri(false), 2000);
                            }}
                            className="text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1 text-[11px] cursor-pointer"
                          >
                            <Copy className="w-3 h-3" />
                            <span>{copiedRedirectUri ? 'Copied to Clipboard!' : 'Copy URI'}</span>
                          </button>
                        </div>
                        <div className="p-2 bg-slate-950 border border-slate-800 rounded-lg text-emerald-400 font-mono text-[11px] break-all select-all">
                          {`${window.location.origin}/oauth/${connectModalPlatform}/callback`}
                        </div>
                      </div>

                      {/* Alt Redirect URI for Preview */}
                      <div className="text-[10px] text-slate-500">
                        Shared preview URL redirect URI:
                        <code className="block mt-0.5 text-slate-400 break-all">
                          https://ais-pre-rpxknsvrx7vw27s2wo3lyk-84160821721.asia-southeast1.run.app/oauth/{connectModalPlatform}/callback
                        </code>
                      </div>
                    </div>

                    <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-[11px] text-indigo-300 flex items-start gap-2">
                      <Sparkles className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                      <span>
                        You can also connect instantly right now using an <strong>API Key / Access Token</strong> or <strong>Channel Handle</strong> via the tabs above!
                      </span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Mode 2: Direct Token / API Key */}
            {connectMode === 'token' && (
              <form onSubmit={handleConnectSubmit} className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    {connectModalPlatform === 'youtube'
                      ? 'Channel Handle or Channel ID (e.g. @HarshithaTech)'
                      : connectModalPlatform === 'whatsapp'
                      ? 'WhatsApp Business Phone Number ID'
                      : 'Account Handle / Username'}
                  </label>
                  <input
                    type="text"
                    required
                    value={connectHandleInput}
                    onChange={(e) => setConnectHandleInput(e.target.value)}
                    placeholder={
                      connectModalPlatform === 'youtube' ? '@HarshithaTech' :
                      connectModalPlatform === 'whatsapp' ? '+15550198372' :
                      '@username'
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    API Key or OAuth Access Token
                  </label>
                  <input
                    type="password"
                    required
                    value={connectApiKeyInput}
                    onChange={(e) => setConnectApiKeyInput(e.target.value)}
                    placeholder="Enter bearer token or API key for live calls"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Credential is encrypted and stored in backend memory. Stripped from client responses.
                  </p>
                </div>

                <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-[11px] text-emerald-300">
                  <strong>Live Validation:</strong> Backend will execute a live test query against the official {developerConfigs[connectModalPlatform]?.displayName || connectModalPlatform} API before confirming connection.
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setConnectModalPlatform(null)}
                    className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isConnecting || !connectHandleInput.trim() || !connectApiKeyInput.trim()}
                    className="px-4 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-xl transition-colors disabled:opacity-50"
                  >
                    {isConnecting ? 'Validating Token...' : 'Validate & Connect'}
                  </button>
                </div>
              </form>
            )}

            {/* Mode 3: Channel / Account Handle */}
            {connectMode === 'handle' && (
              <form onSubmit={handleConnectSubmit} className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    {connectModalPlatform === 'youtube'
                      ? 'Channel Handle or Channel ID (e.g. @HarshithaTech or UC...)'
                      : connectModalPlatform === 'whatsapp'
                      ? 'WhatsApp Business Display Name / Phone ID'
                      : 'Public Handle / Username'}
                  </label>
                  <input
                    type="text"
                    required
                    value={connectHandleInput}
                    onChange={(e) => setConnectHandleInput(e.target.value)}
                    placeholder={
                      connectModalPlatform === 'youtube' ? '@HarshithaTech' :
                      connectModalPlatform === 'whatsapp' ? '+15550198372' :
                      '@username'
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Connects public profile metadata using server-configured API access keys.
                  </p>
                </div>

                <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-[11px] text-indigo-300">
                  <strong>Read-Only Access:</strong> Pulls public subscriber counts, views, and aggregate follower metrics without requesting account editing permissions.
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setConnectModalPlatform(null)}
                    className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isConnecting || !connectHandleInput.trim()}
                    className="px-4 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-xl transition-colors disabled:opacity-50"
                  >
                    {isConnecting ? 'Connecting...' : 'Connect Channel'}
                  </button>
                </div>
              </form>
            )}

            {/* Close footer when in OAuth mode */}
            {connectMode === 'oauth' && (
              <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
                <button
                  type="button"
                  onClick={() => setConnectModalPlatform(null)}
                  className="px-4 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition-colors"
                >
                  Close
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
