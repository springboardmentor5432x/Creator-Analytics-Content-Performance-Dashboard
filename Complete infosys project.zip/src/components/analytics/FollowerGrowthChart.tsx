import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Area,
  AreaChart
} from 'recharts';
import { 
  TrendingUp, 
  Users, 
  HelpCircle, 
  Calendar, 
  Sparkles, 
  ArrowUp, 
  Check, 
  Layers,
  Activity,
  Maximize2
} from 'lucide-react';

export interface GrowthSnapshotPoint {
  date: string;
  fullDate?: string;
  youtube: number;
  instagram: number;
  tiktok: number;
  linkedin: number;
  total?: number;
  views?: number;
  engagementRate?: number;
}

export type ChartDateRange = '7d' | '28d' | '30d' | '90d' | '1y' | 'custom';

interface FollowerGrowthChartProps {
  growthPoints: GrowthSnapshotPoint[];
  growthTimeRange: ChartDateRange;
  onRangeChange: (range: ChartDateRange, customStart?: string, customEnd?: string) => void;
  isLoading?: boolean;
  rawSnapshots?: any[];
  title?: string;
  subtitle?: string;
  customStartDate?: string;
  customEndDate?: string;
}

// Custom Tooltip component for Recharts
const CustomGrowthTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const dataPoint = payload[0]?.payload as GrowthSnapshotPoint;
    const total = (dataPoint?.youtube || 0) + (dataPoint?.instagram || 0) + (dataPoint?.tiktok || 0) + (dataPoint?.linkedin || 0);

    return (
      <div className="bg-slate-900/95 backdrop-blur-md text-white p-3.5 rounded-2xl shadow-2xl border border-slate-700/80 text-xs min-w-[200px] animate-in fade-in-50">
        <div className="flex items-center justify-between border-b border-slate-700/80 pb-2 mb-2">
          <span className="font-bold text-purple-300 flex items-center space-x-1.5">
            <Calendar className="w-3.5 h-3.5 text-purple-400" />
            <span>{dataPoint.fullDate || label}</span>
          </span>
          <span className="text-[10px] text-slate-400 font-mono">YouTube Snapshot</span>
        </div>

        <div className="space-y-1.5 font-medium">
          {payload.map((entry: any, index: number) => (
            <div key={`item-${index}`} className="flex items-center justify-between text-[11px]">
              <span className="flex items-center space-x-1.5" style={{ color: entry.color }}>
                <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: entry.color }} />
                <span>{entry.name}:</span>
              </span>
              <span className="font-mono font-bold text-white">
                {Number(entry.value).toLocaleString()}
              </span>
            </div>
          ))}

          {total > 0 && (
            <div className="border-t border-slate-700/80 pt-1.5 mt-2 flex items-center justify-between text-[11px] font-bold text-slate-200">
              <span>Combined Total:</span>
              <span className="text-emerald-400 font-mono font-black">{total.toLocaleString()}</span>
            </div>
          )}
        </div>
      </div>
    );
  }
  return null;
};

export const FollowerGrowthChart: React.FC<FollowerGrowthChartProps> = ({
  growthPoints,
  growthTimeRange,
  onRangeChange,
  isLoading = false,
  rawSnapshots = [],
  title = "Follower & Subscriber Growth Trends",
  subtitle = "Multi-platform reach expansion based on dated historical snapshots",
  customStartDate,
  customEndDate
}) => {
  // Visible lines filter state
  const [visiblePlatforms, setVisiblePlatforms] = useState({
    youtube: true,
    instagram: true,
    tiktok: true,
    linkedin: true
  });

  const [chartMode, setChartMode] = useState<'line' | 'area'>('line');
  const [showSnapshotsTable, setShowSnapshotsTable] = useState(false);
  const [showCustomRangePicker, setShowCustomRangePicker] = useState(growthTimeRange === 'custom');
  
  // Custom date picker states
  const today = new Date().toISOString().split('T')[0];
  const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0];
  const [localStart, setLocalStart] = useState<string>(customStartDate || thirtyDaysAgo);
  const [localEnd, setLocalEnd] = useState<string>(customEndDate || today);

  // Toggle single platform
  const togglePlatform = (key: keyof typeof visiblePlatforms) => {
    setVisiblePlatforms(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  // Compute summary stats from growthPoints
  const stats = useMemo(() => {
    if (!growthPoints || growthPoints.length === 0) {
      return { startYt: 0, endYt: 0, netGain: 0, pctGain: '0', avgDaily: 0, hasData: false };
    }
    const first = growthPoints[0];
    const last = growthPoints[growthPoints.length - 1];
    const startYt = first.youtube || 0;
    const endYt = last.youtube || 0;
    const netGain = endYt - startYt;
    const pctGain = startYt > 0 ? ((netGain / startYt) * 100).toFixed(1) : '0';
    const days = growthTimeRange === '7d' ? 7 : growthTimeRange === '28d' ? 28 : growthTimeRange === '90d' ? 90 : 30;
    const avgDaily = Math.round(netGain / (days || 1));

    return { startYt, endYt, netGain, pctGain, avgDaily, hasData: true };
  }, [growthPoints, growthTimeRange]);

  // Formatter for YAxis tick labels
  const formatYAxis = (tickItem: number) => {
    if (tickItem >= 1000000) return `${(tickItem / 1000000).toFixed(1)}M`;
    if (tickItem >= 1000) return `${Math.round(tickItem / 1000)}K`;
    return tickItem.toString();
  };

  const handleApplyCustomRange = () => {
    if (localStart && localEnd) {
      onRangeChange('custom', localStart, localEnd);
    }
  };

  return (
    <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-2xs flex flex-col justify-between">
      {/* 1. Header Bar: Title, Range Switcher & Mode Toggle */}
      <div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 gap-3 border-b border-slate-100">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center border border-purple-100">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-slate-900">{title}</h3>
                <span className="text-[10px] font-mono bg-purple-100 text-purple-800 font-semibold px-2 py-0.5 rounded-full">
                  YouTube Analytics API
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">{subtitle}</p>
            </div>
          </div>

          {/* Controls: Range pills, View type toggle */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Time range selector pills */}
            <div className="flex items-center bg-slate-100/80 p-0.5 rounded-lg text-[10px] font-semibold border border-slate-200/60">
              {(['7d', '28d', '90d', 'custom'] as const).map(tr => (
                <button
                  key={tr}
                  onClick={() => {
                    if (tr === 'custom') {
                      setShowCustomRangePicker(true);
                      onRangeChange('custom', localStart, localEnd);
                    } else {
                      setShowCustomRangePicker(false);
                      onRangeChange(tr);
                    }
                  }}
                  className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                    growthTimeRange === tr
                      ? 'bg-purple-600 text-white shadow-2xs font-bold'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {tr === 'custom' ? 'Custom' : tr.toUpperCase()}
                </button>
              ))}
            </div>

            {/* Area vs Line chart toggle */}
            <div className="flex items-center bg-slate-100/80 p-0.5 rounded-lg text-[10px] font-semibold border border-slate-200/60">
              <button
                onClick={() => setChartMode('line')}
                className={`px-2 py-1 rounded-md transition-all cursor-pointer ${
                  chartMode === 'line'
                    ? 'bg-white text-purple-700 shadow-2xs font-bold'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
                title="Standard Multi-Line Chart"
              >
                Line
              </button>
              <button
                onClick={() => setChartMode('area')}
                className={`px-2 py-1 rounded-md transition-all cursor-pointer ${
                  chartMode === 'area'
                    ? 'bg-white text-purple-700 shadow-2xs font-bold'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
                title="Gradient Area Chart"
              >
                Area
              </button>
            </div>

            {/* Toggle Snapshots table drawer */}
            {rawSnapshots && rawSnapshots.length > 0 && (
              <button
                onClick={() => setShowSnapshotsTable(prev => !prev)}
                className={`px-2.5 py-1 text-[10px] font-bold rounded-lg border transition-all cursor-pointer flex items-center space-x-1 ${
                  showSnapshotsTable
                    ? 'bg-purple-50 text-purple-700 border-purple-200'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                <Layers className="w-3 h-3" />
                <span>Snapshots ({rawSnapshots.length})</span>
              </button>
            )}
          </div>
        </div>

        {/* Custom Date Range Picker Bar */}
        {(growthTimeRange === 'custom' || showCustomRangePicker) && (
          <div className="flex flex-wrap items-center gap-2 p-2.5 my-2.5 bg-purple-50/60 border border-purple-100 rounded-xl text-xs">
            <span className="font-semibold text-purple-900 flex items-center space-x-1">
              <Calendar className="w-3.5 h-3.5 text-purple-600" />
              <span>Custom Range:</span>
            </span>
            <div className="flex items-center space-x-1.5">
              <label className="text-[10px] font-medium text-slate-500">From:</label>
              <input
                type="date"
                value={localStart}
                max={localEnd || today}
                onChange={(e) => setLocalStart(e.target.value)}
                className="px-2 py-1 rounded-md bg-white border border-slate-200 text-xs text-slate-800 font-mono focus:outline-none focus:ring-1 focus:ring-purple-500"
              />
            </div>
            <div className="flex items-center space-x-1.5">
              <label className="text-[10px] font-medium text-slate-500">To:</label>
              <input
                type="date"
                value={localEnd}
                min={localStart}
                max={today}
                onChange={(e) => setLocalEnd(e.target.value)}
                className="px-2 py-1 rounded-md bg-white border border-slate-200 text-xs text-slate-800 font-mono focus:outline-none focus:ring-1 focus:ring-purple-500"
              />
            </div>
            <button
              onClick={handleApplyCustomRange}
              className="px-3 py-1 rounded-md bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs transition-colors cursor-pointer"
            >
              Apply Filter
            </button>
          </div>
        )}

        {/* 2. Key Metrics Summary Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 my-3.5">
          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] text-slate-400 font-medium block">YouTube Metric</span>
            <span className="text-base font-black text-slate-900 font-mono">
              {stats.hasData && stats.endYt > 0 ? stats.endYt.toLocaleString() : 'Data unavailable'}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] text-slate-400 font-medium block">
              Period Growth ({growthTimeRange === 'custom' ? 'Custom' : growthTimeRange.toUpperCase()})
            </span>
            <div className="flex items-baseline space-x-1">
              <span className={`text-base font-black font-mono ${stats.netGain >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                {stats.hasData ? (stats.netGain >= 0 ? `+${stats.netGain.toLocaleString()}` : stats.netGain.toLocaleString()) : 'Data unavailable'}
              </span>
              {stats.hasData && stats.startYt > 0 && (
                <span className="text-[10px] font-bold text-emerald-600">
                  (+{stats.pctGain}%)
                </span>
              )}
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] text-slate-400 font-medium block">Avg Daily Metric</span>
            <span className="text-base font-black text-purple-700 font-mono">
              {stats.hasData ? `+${stats.avgDaily.toLocaleString()} / day` : 'Data unavailable'}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] text-slate-400 font-medium block">Daily Data Points</span>
            <span className="text-base font-black text-slate-800 font-mono">
              {growthPoints.length > 0 ? `${growthPoints.length} points` : '0 points'}
            </span>
          </div>
        </div>

        {/* 3. Platform Interactive Legend & Toggles */}
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs pb-2">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => togglePlatform('youtube')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center space-x-1.5 border transition-all cursor-pointer ${
                visiblePlatforms.youtube 
                  ? 'bg-red-50 text-red-700 border-red-200' 
                  : 'bg-slate-50 text-slate-400 border-slate-200 opacity-60'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-red-600 inline-block" />
              <span>YouTube</span>
              {visiblePlatforms.youtube && <Check className="w-3 h-3 text-red-600" />}
            </button>

            <button
              onClick={() => togglePlatform('instagram')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center space-x-1.5 border transition-all cursor-pointer ${
                visiblePlatforms.instagram 
                  ? 'bg-pink-50 text-pink-700 border-pink-200' 
                  : 'bg-slate-50 text-slate-400 border-slate-200 opacity-60'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-pink-500 inline-block" />
              <span>Instagram</span>
              {visiblePlatforms.instagram && <Check className="w-3 h-3 text-pink-500" />}
            </button>

            <button
              onClick={() => togglePlatform('tiktok')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center space-x-1.5 border transition-all cursor-pointer ${
                visiblePlatforms.tiktok 
                  ? 'bg-slate-100 text-slate-900 border-slate-300' 
                  : 'bg-slate-50 text-slate-400 border-slate-200 opacity-60'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-slate-900 inline-block" />
              <span>TikTok</span>
              {visiblePlatforms.tiktok && <Check className="w-3 h-3 text-slate-900" />}
            </button>

            <button
              onClick={() => togglePlatform('linkedin')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center space-x-1.5 border transition-all cursor-pointer ${
                visiblePlatforms.linkedin 
                  ? 'bg-sky-50 text-sky-700 border-sky-200' 
                  : 'bg-slate-50 text-slate-400 border-slate-200 opacity-60'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-sky-600 inline-block" />
              <span>LinkedIn</span>
              {visiblePlatforms.linkedin && <Check className="w-3 h-3 text-sky-600" />}
            </button>
          </div>

          <span className="text-[10px] text-slate-400 italic">
            Click platform badges to show or hide curves
          </span>
        </div>

        {/* 4. Recharts Container */}
        <div className="w-full h-64 mt-2">
          {isLoading ? (
            <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 text-xs">
              <Activity className="w-6 h-6 animate-spin text-purple-600 mb-2" />
              <span>Loading snapshot points...</span>
            </div>
          ) : growthPoints.length === 0 ? (
            <div className="w-full h-full flex flex-col items-center justify-center bg-slate-50/70 rounded-xl border border-dashed border-slate-200 text-center p-6">
              <div className="w-10 h-10 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center mb-2.5">
                <TrendingUp className="w-5 h-5" />
              </div>
              <p className="text-xs font-bold text-slate-800">Data unavailable for this period</p>
              <p className="text-[11px] text-slate-500 max-w-sm mt-1">
                No YouTube analytics reports or snapshots were found for the selected {growthTimeRange === 'custom' ? 'custom' : growthTimeRange.toUpperCase()} range. Connect your YouTube account and click &ldquo;Sync YouTube Data&rdquo; to fetch fresh performance records.
              </p>
            </div>
          ) : chartMode === 'line' ? (
            <ResponsiveContainer width="100%" height={256}>
              <LineChart data={growthPoints} margin={{ top: 10, right: 15, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 10, fill: '#94a3b8' }} 
                  axisLine={{ stroke: '#e2e8f0' }}
                  tickLine={false}
                />
                <YAxis 
                  tickFormatter={formatYAxis} 
                  tick={{ fontSize: 10, fill: '#94a3b8' }}
                  axisLine={false}
                  tickLine={false}
                  domain={[0, 'auto']}
                />
                <Tooltip content={<CustomGrowthTooltip />} />

                {visiblePlatforms.youtube && (
                  <Line 
                    type="monotone" 
                    dataKey="youtube" 
                    name="YouTube" 
                    stroke="#ef4444" 
                    strokeWidth={2.5}
                    dot={{ r: 3.5, fill: '#ef4444', stroke: '#ffffff', strokeWidth: 1.5 }}
                    activeDot={{ r: 6, fill: '#ef4444', stroke: '#ffffff', strokeWidth: 2 }}
                  />
                )}

                {visiblePlatforms.instagram && (
                  <Line 
                    type="monotone" 
                    dataKey="instagram" 
                    name="Instagram" 
                    stroke="#ec4899" 
                    strokeWidth={2.5}
                    dot={{ r: 3.5, fill: '#ec4899', stroke: '#ffffff', strokeWidth: 1.5 }}
                    activeDot={{ r: 6, fill: '#ec4899', stroke: '#ffffff', strokeWidth: 2 }}
                  />
                )}

                {visiblePlatforms.tiktok && (
                  <Line 
                    type="monotone" 
                    dataKey="tiktok" 
                    name="TikTok" 
                    stroke="#0f172a" 
                    strokeWidth={2.5}
                    dot={{ r: 3.5, fill: '#0f172a', stroke: '#ffffff', strokeWidth: 1.5 }}
                    activeDot={{ r: 6, fill: '#0f172a', stroke: '#ffffff', strokeWidth: 2 }}
                  />
                )}

                {visiblePlatforms.linkedin && (
                  <Line 
                    type="monotone" 
                    dataKey="linkedin" 
                    name="LinkedIn" 
                    stroke="#0284c7" 
                    strokeWidth={2.5}
                    dot={{ r: 3.5, fill: '#0284c7', stroke: '#ffffff', strokeWidth: 1.5 }}
                    activeDot={{ r: 6, fill: '#0284c7', stroke: '#ffffff', strokeWidth: 2 }}
                  />
                )}
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <ResponsiveContainer width="100%" height={256}>
              <AreaChart data={growthPoints} margin={{ top: 10, right: 15, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="ytGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="igGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ec4899" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#ec4899" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 10, fill: '#94a3b8' }} 
                  axisLine={{ stroke: '#e2e8f0' }}
                  tickLine={false}
                />
                <YAxis 
                  tickFormatter={formatYAxis} 
                  tick={{ fontSize: 10, fill: '#94a3b8' }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip content={<CustomGrowthTooltip />} />

                {visiblePlatforms.youtube && (
                  <Area 
                    type="monotone" 
                    dataKey="youtube" 
                    name="YouTube" 
                    stroke="#ef4444" 
                    strokeWidth={2.5}
                    fillOpacity={1} 
                    fill="url(#ytGrad)" 
                  />
                )}

                {visiblePlatforms.instagram && (
                  <Area 
                    type="monotone" 
                    dataKey="instagram" 
                    name="Instagram" 
                    stroke="#ec4899" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#igGrad)" 
                  />
                )}

                {visiblePlatforms.tiktok && (
                  <Area 
                    type="monotone" 
                    dataKey="tiktok" 
                    name="TikTok" 
                    stroke="#0f172a" 
                    strokeWidth={2}
                    fillOpacity={0.1} 
                    fill="#0f172a" 
                  />
                )}

                {visiblePlatforms.linkedin && (
                  <Area 
                    type="monotone" 
                    dataKey="linkedin" 
                    name="LinkedIn" 
                    stroke="#0284c7" 
                    strokeWidth={2}
                    fillOpacity={0.1} 
                    fill="#0284c7" 
                  />
                )}
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* 5. Historical Snapshots Table Drawer (when toggled) */}
        {showSnapshotsTable && rawSnapshots && rawSnapshots.length > 0 && (
          <div className="mt-4 pt-3 border-t border-slate-100 animate-in fade-in-50">
            <div className="flex items-center justify-between pb-2">
              <span className="text-xs font-bold text-slate-800">
                Historical Snapshot Records ({rawSnapshots.length})
              </span>
              <span className="text-[10px] text-slate-400">
                Dated records captured in PostgreSQL / Server memory
              </span>
            </div>

            <div className="max-h-48 overflow-y-auto border border-slate-100 rounded-xl">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-[10px] font-bold text-slate-500 uppercase sticky top-0">
                  <tr>
                    <th className="py-2 px-3">Date</th>
                    <th className="py-2 px-3 text-right">Subscribers</th>
                    <th className="py-2 px-3 text-right">Total Views</th>
                    <th className="py-2 px-3 text-right">Likes</th>
                    <th className="py-2 px-3 text-right">Comments</th>
                    <th className="py-2 px-3 text-right">Shares</th>
                    <th className="py-2 px-3 text-center">Engagement</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                  {rawSnapshots.map((snap: any, idx: number) => (
                    <tr key={idx} className="hover:bg-slate-50/70">
                      <td className="py-1.5 px-3 font-semibold text-slate-800">{snap.snapshotDate}</td>
                      <td className="py-1.5 px-3 text-right font-bold text-red-600">{Number(snap.subscribers).toLocaleString()}</td>
                      <td className="py-1.5 px-3 text-right text-slate-600">{Number(snap.totalViews).toLocaleString()}</td>
                      <td className="py-1.5 px-3 text-right text-slate-600">{Number(snap.totalLikes).toLocaleString()}</td>
                      <td className="py-1.5 px-3 text-right text-slate-600">{Number(snap.totalComments).toLocaleString()}</td>
                      <td className="py-1.5 px-3 text-right text-slate-600">{Number(snap.totalShares).toLocaleString()}</td>
                      <td className="py-1.5 px-3 text-center">
                        <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-emerald-50 text-emerald-700 font-bold">
                          {snap.engagementRate}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
