import React, { useState, useEffect } from 'react';
import { 
  Globe2, 
  ExternalLink, 
  Info, 
  RefreshCw, 
  ShieldCheck, 
  Search,
  Filter,
  CheckCircle,
  HelpCircle,
  BarChart,
  Calendar,
  Layers
} from 'lucide-react';
import { globalStatsService } from '../../services/api';
import { GlobalSocialStat } from '../../types/auth';

interface GlobalSocialStatsSectionProps {
  compact?: boolean;
}

export const GlobalSocialStatsSection: React.FC<GlobalSocialStatsSectionProps> = ({ compact = false }) => {
  const [stats, setStats] = useState<GlobalSocialStat[]>([]);
  const [sourceMetadata, setSourceMetadata] = useState<{
    methodology: string;
    lastVerified: string;
    citations: string[];
  } | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'MAU' | 'Members' | 'DAU'>('all');
  const [selectedStatInfo, setSelectedStatInfo] = useState<GlobalSocialStat | null>(null);

  const fetchStats = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await globalStatsService.getGlobalStats();
      if (res.success && res.stats) {
        setStats(res.stats);
        if (res.sourceMetadata) {
          setSourceMetadata(res.sourceMetadata);
        }
      } else {
        setError('Unable to fetch official global statistics at this time.');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to connect to global statistics service.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  const filteredStats = stats.filter(stat => {
    const matchesSearch = 
      stat.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      stat.sourceName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      stat.reportingPeriod.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (selectedFilter === 'all') return true;
    if (selectedFilter === 'MAU') return stat.metricType.includes('MAU');
    if (selectedFilter === 'Members') return stat.metricType.includes('Members');
    if (selectedFilter === 'DAU') return stat.metricType.includes('DAU');
    return true;
  });

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'youtube':
        return '▶️';
      case 'instagram':
        return '📸';
      case 'tiktok':
        return '🎵';
      case 'facebook':
        return '👥';
      case 'whatsapp':
        return '💬';
      case 'snapchat':
        return '👻';
      case 'twitter':
        return '𝕏';
      case 'linkedin':
        return '💼';
      default:
        return '🌐';
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
      {/* Background ambient gradient */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Globe2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-bold text-white tracking-tight">Worldwide Social Media Statistics</h3>
                <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> Verified Benchmarks
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Authoritative public industry metrics from official quarterly earnings & verified regulatory disclosures. Distinct from your private account audience.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchStats}
            disabled={isLoading}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700 rounded-lg transition-colors disabled:opacity-50"
            title="Refresh verified global benchmarks"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-indigo-400' : ''}`} />
            <span>{isLoading ? 'Updating...' : 'Refresh Sources'}</span>
          </button>
        </div>
      </div>

      {/* Methodology notice & distinction banner */}
      <div className="my-4 p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-start gap-3">
        <Info className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
        <div className="text-xs text-amber-200/90 leading-relaxed">
          <span className="font-semibold text-amber-300">Methodology & Distinction:</span> Metrics are not directly interchangeable. For example, Facebook and YouTube report Monthly Active Users (MAU), LinkedIn reports Registered Members (which includes inactive profiles), and WhatsApp Business API metrics reflect enterprise customer interactions rather than the consumer messaging base.
        </div>
      </div>

      {/* Controls: Search & Filter Tabs */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-5">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search platform, report, or source..."
            className="w-full bg-slate-800/60 border border-slate-700/80 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-1.5 bg-slate-800/40 p-1 rounded-xl border border-slate-800 text-xs">
          <span className="text-[11px] text-slate-400 px-2 font-medium flex items-center gap-1">
            <Filter className="w-3 h-3" /> Filter:
          </span>
          {(['all', 'MAU', 'Members', 'DAU'] as const).map((filterKey) => (
            <button
              key={filterKey}
              onClick={() => setSelectedFilter(filterKey)}
              className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                selectedFilter === filterKey
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {filterKey === 'all' ? 'All (8 Platforms)' : filterKey}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Global Platform Stats */}
      {isLoading && stats.length === 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 py-8">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="animate-pulse bg-slate-800/50 rounded-xl p-4 border border-slate-800 h-44" />
          ))}
        </div>
      ) : error ? (
        <div className="p-8 text-center bg-red-500/10 border border-red-500/20 rounded-xl my-4">
          <p className="text-sm text-red-400 mb-2 font-medium">{error}</p>
          <button
            onClick={fetchStats}
            className="text-xs px-3 py-1.5 bg-red-500/20 text-red-300 rounded-lg hover:bg-red-500/30 transition-colors"
          >
            Retry Fetching Benchmarks
          </button>
        </div>
      ) : filteredStats.length === 0 ? (
        <div className="py-12 text-center text-slate-400 text-xs">
          No platform matches your search or filter criteria.
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredStats.map((stat) => (
            <div
              key={stat.platform}
              className="group relative bg-slate-800/40 hover:bg-slate-800/70 border border-slate-800 hover:border-slate-700 rounded-xl p-4 transition-all duration-200 flex flex-col justify-between"
            >
              <div>
                {/* Platform header */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xl" role="img" aria-label={stat.name}>
                      {getPlatformIcon(stat.platform)}
                    </span>
                    <div>
                      <h4 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                        {stat.name}
                      </h4>
                      <p className="text-[10px] text-slate-400 font-mono">
                        {stat.reportingPeriod}
                      </p>
                    </div>
                  </div>
                  <span 
                    className="px-2 py-0.5 rounded-full text-[10px] font-semibold border"
                    style={{
                      backgroundColor: `${stat.badgeColor}15`,
                      color: stat.badgeColor,
                      borderColor: `${stat.badgeColor}30`
                    }}
                  >
                    {stat.metricType.split(' ')[0]}
                  </span>
                </div>

                {/* Big Metric Display */}
                <div className="mb-2">
                  <div className="text-2xl font-black text-white tracking-tight flex items-baseline gap-1.5">
                    <span>{stat.userCountFormatted}</span>
                    <span className="text-[11px] font-normal text-slate-400">users</span>
                  </div>
                  <div className="text-[11px] font-medium text-slate-300 mt-0.5 flex items-center gap-1">
                    <span>{stat.metricType}</span>
                  </div>
                </div>

                {/* Metric Definition Snippet */}
                <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed mt-1">
                  {stat.definition}
                </p>
              </div>

              {/* Source & Link footer */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-1 text-slate-400 truncate max-w-[170px]" title={stat.sourceName}>
                  <Calendar className="w-3 h-3 text-slate-500 flex-shrink-0" />
                  <span className="truncate">{stat.sourceName}</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedStatInfo(stat)}
                    className="text-slate-400 hover:text-indigo-300 transition-colors p-1"
                    title="View metric details & definition"
                  >
                    <Info className="w-3.5 h-3.5" />
                  </button>
                  <a
                    href={stat.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-indigo-400 hover:text-indigo-300 flex items-center gap-0.5 font-medium transition-colors p-1"
                    title={`Open official report: ${stat.sourceName}`}
                  >
                    <span className="text-[10px]">Source</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Footer verification stamp */}
      {sourceMetadata && (
        <div className="mt-5 pt-4 border-t border-slate-800/70 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>Audit Status: Last verified by CreatorIQ Data Engine on <strong className="text-slate-300">{sourceMetadata.lastVerified}</strong></span>
          </div>
          <div className="text-slate-400 font-mono text-[10px]">
            Data Sources: SEC 10-K/Q, Alphabet, Meta, ByteDance, Snap Inc., Microsoft, X Corp
          </div>
        </div>
      )}

      {/* Details Modal */}
      {selectedStatInfo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{getPlatformIcon(selectedStatInfo.platform)}</span>
                <div>
                  <h4 className="text-base font-bold text-white">{selectedStatInfo.name} Global Audience</h4>
                  <p className="text-xs text-slate-400">{selectedStatInfo.reportingPeriod}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedStatInfo(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="p-3 bg-slate-800/60 rounded-xl">
                <div className="text-slate-400 font-medium">Reported Figure:</div>
                <div className="text-xl font-bold text-white mt-0.5">
                  {selectedStatInfo.userCountFormatted} ({selectedStatInfo.userCountRaw.toLocaleString()} users)
                </div>
                <div className="text-indigo-400 font-medium mt-0.5">
                  {selectedStatInfo.metricType}
                </div>
              </div>

              <div>
                <span className="text-slate-400 font-medium">Metric Definition:</span>
                <p className="text-slate-300 mt-1 leading-relaxed bg-slate-800/40 p-2.5 rounded-lg border border-slate-800">
                  {selectedStatInfo.definition}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2">
                <div className="bg-slate-800/40 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-slate-400">Reporting Period:</span>
                  <div className="text-white font-medium mt-0.5">{selectedStatInfo.reportingPeriod}</div>
                </div>
                <div className="bg-slate-800/40 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-slate-400">Last Verified:</span>
                  <div className="text-white font-medium mt-0.5">{selectedStatInfo.lastUpdated}</div>
                </div>
              </div>

              <div className="pt-2">
                <span className="text-slate-400 font-medium">Verified Source:</span>
                <div className="text-white font-medium mt-0.5 flex items-center justify-between">
                  <span>{selectedStatInfo.sourceName}</span>
                  <a
                    href={selectedStatInfo.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-semibold"
                  >
                    Open Publication <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedStatInfo(null)}
                className="px-4 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
