export type UserRole = 'creator' | 'agency' | 'marketing' | 'admin';
export type UserStatus = 'active' | 'pending' | 'suspended';

export interface CreatorProfile {
  id?: number;
  userId?: number;
  handle?: string;
  bio?: string;
  niche?: string;
  location?: string;
  website?: string;
  contactEmail?: string;
  baseRate?: number;
  collaborationStatus?: 'open' | 'booked' | 'selective';
  youtubeHandle?: string;
  youtubeSubscribers?: number;
  instagramHandle?: string;
  instagramFollowers?: number;
  tiktokHandle?: string;
  tiktokFollowers?: number;
  twitterHandle?: string;
  engagementRate?: number;
  monthlyReach?: number;
  verified?: boolean;
}

export interface AgencyProfile {
  agencyName?: string;
  licenseNumber?: string;
  rosterSize?: number;
  commissionRate?: number;
  specialties?: string;
  businessAddress?: string;
  website?: string;
  phone?: string;
  keyClients?: string;
  taxId?: string;
}

export interface MarketingProfile {
  brandName?: string;
  industrySector?: string;
  annualBudget?: number;
  targetAudience?: string;
  campaignKPIs?: string;
  corporateWebsite?: string;
  phone?: string;
  taxId?: string;
  headOfGrowth?: string;
}

export interface AdminProfile {
  department?: string;
  clearanceLevel?: string;
  accessScopes?: string[];
  twoFactorStatus?: boolean;
  emergencyContact?: string;
  complianceAuditDate?: string;
  employeeId?: string;
}

export interface PersonalDetails {
  phone?: string;
  location?: string;
  bio?: string;
  language?: string;
  timezone?: string;
}

export interface WorkspaceProfileEntry {
  name: string;
  username?: string;
  updatedAt?: string;
}

export interface User {
  id: number | string;
  uid?: string;
  name: string;
  username?: string;
  email: string;
  role: UserRole;
  roles?: UserRole[];
  status: UserStatus;
  avatar_url: string;
  created_at: string;
  last_login: string | null;
  email_verified?: boolean;
  creator_profile?: CreatorProfile;
  current_session_started_at?: string | null;
  last_activity_at?: string | null;
  last_logout_at?: string | null;
  session_duration_seconds?: number;
  is_profile_customized?: boolean;
  workspaceProfiles?: Partial<Record<UserRole, WorkspaceProfileEntry>>;
}

export interface DashboardMetricDelta {
  name: string;
  current: number;
  previous: number;
  delta: number;
}

export interface DashboardDeltaRecord {
  success: boolean;
  role: UserRole;
  isFirstVisit: boolean;
  lastVisitedAt: string | null;
  lastSyncedAt: string;
  currentVisitAt: string;
  deltas: {
    primary: DashboardMetricDelta;
    secondary: DashboardMetricDelta;
    tertiary: DashboardMetricDelta;
  };
}

export interface UserSession {
  id: string;
  user_id: number | string;
  user_email: string;
  user_name: string;
  user_role: UserRole;
  login_time: string;
  logout_time?: string | null;
  last_activity: string;
  session_duration_seconds: number;
  ip_address?: string;
  user_agent?: string;
  status: 'active' | 'completed' | 'closed_unexpectedly';
}

export interface AuthResponse {
  success: boolean;
  message: string;
  token?: string;
  user?: User;
}

export interface RegisterPayload {
  name: string;
  email: string;
  password: string;
  confirm_password: string;
  role: UserRole;
  roles?: UserRole[];
  niche?: string;
}

export interface LoginPayload {
  email: string;
  password: string;
  role?: UserRole | string;
}

export interface ProfileUpdatePayload {
  name?: string;
  avatar_url?: string;
  workspaceRole?: UserRole;
  personal?: PersonalDetails;
  professional?: any;
  handle?: string;
  bio?: string;
  niche?: string;
  location?: string;
  website?: string;
  contact_email?: string;
  base_rate?: number;
  collaboration_status?: 'open' | 'booked' | 'selective';
  youtube_handle?: string;
  instagram_handle?: string;
  tiktok_handle?: string;
  twitter_handle?: string;
}

export interface AdminUserUpdatePayload {
  name?: string;
  username?: string;
  role?: UserRole;
  roles?: UserRole[];
  status?: UserStatus;
  password?: string;
}

export interface AuditLog {
  id: number;
  user_id: number | null;
  action: string;
  details: string;
  ip_address?: string;
  created_at: string;
}

export interface AdminStats {
  total_users: number;
  active_users: number;
  suspended_users: number;
  roles: {
    creator: number;
    agency: number;
    marketing: number;
    admin: number;
  };
  registrations_last_30_days: number;
  audit_logs?: AuditLog[];
}

export interface Campaign {
  id: number;
  title: string;
  clientOrBrand: string;
  brand?: string;
  deliverables?: string;
  agencyId?: number;
  marketingId?: number;
  budget: number;
  spend: number;
  status: 'draft' | 'active' | 'in_review' | 'completed';
  startDate: string;
  endDate: string;
  assignedCreators: string[];
  assignedCreatorNames?: string[];
  reach: number;
  engagement: number;
  impressions: number;
  clicks?: number;
  conversions?: number;
  roas?: number;
  deliverablesCount: number;
  platform?: string;
  hasSpendData?: boolean;
}

export interface ContentItem {
  id: number;
  creatorId: number;
  title: string;
  platform: 'youtube' | 'instagram' | 'tiktok' | 'linkedin';
  type: 'video' | 'post' | 'reel' | 'article' | 'short';
  publishedAt?: string;
  scheduledDate?: string;
  status: 'published' | 'scheduled' | 'draft';
  views: number;
  likes: number;
  comments: number;
  shares: number;
  engagementRate: number;
  revenue?: number;
  url?: string;
}

export interface TaskItem {
  id: number;
  title: string;
  campaignId: number;
  campaignTitle: string;
  assignee: string;
  dueDate: string;
  completed: boolean;
  priority: 'high' | 'medium' | 'low';
}

export interface NotificationItem {
  id: number;
  userId?: number;
  role?: UserRole | 'all';
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'viral' | 'deal' | 'system' | 'campaign';
}

export interface SystemSettings {
  sessionTimeoutMinutes: number;
  allowPublicRegistration: boolean;
  requireTwoFactor: boolean;
  maintenanceMode: boolean;
}

export type SupportedPlatform = 
  | 'youtube' 
  | 'tiktok' 
  | 'instagram' 
  | 'facebook' 
  | 'whatsapp' 
  | 'snapchat' 
  | 'x' 
  | 'twitter'
  | 'linkedin';

export type PlatformConnectionStatus = 
  | 'connected' 
  | 'disconnected' 
  | 'syncing' 
  | 'error' 
  | 'setup_required';

export interface PlatformDeveloperConfig {
  platform: SupportedPlatform;
  displayName: string;
  category: 'video' | 'short_form' | 'visual' | 'social_network' | 'messaging' | 'professional';
  iconColor: string;
  officialApiName: string;
  authMethod: 'OAuth 2.0' | 'OAuth 2.0 / API Key' | 'Meta Graph API' | 'Cloud API';
  requiredScopes: string[];
  developerPortalUrl: string;
  prerequisites: string;
  supportedMetrics: string[];
  rateLimits: string;
  reviewStatus: 'Ready / Live' | 'Developer App Required' | 'Business Review Required';
  notes?: string;
}

export interface ConnectedPlatformAccount {
  id: string | number;
  userId: number;
  platform: SupportedPlatform;
  displayName: string;
  accountHandle: string;
  avatarUrl?: string;
  status: PlatformConnectionStatus;
  followersOrSubscribers: number;
  postsOrVideosCount: number;
  totalViews?: number;
  totalLikes?: number;
  totalComments?: number;
  totalShares?: number;
  engagementRate?: number;
  lastSyncedAt: string | null;
  errorMessage?: string;
  connectedAt?: string;
  apiSource?: 'official_live' | 'profile_roster' | 'unverified';
  authMethod?: 'oauth2' | 'token' | 'api_key' | 'handle';
  credentialsConfigured?: boolean;
  metadata?: Record<string, any>;
}

export interface OAuthUrlResponse {
  success: boolean;
  platform: SupportedPlatform;
  url?: string;
  authUrl?: string | null;
  configured?: boolean;
  setupRequired?: boolean;
  message?: string;
  redirectUri: string;
  requiredScopes: string[];
  developerPortalUrl: string;
}

export interface GlobalSocialStat {
  platform: SupportedPlatform;
  name: string;
  metricType: 'Monthly Active Users (MAU)' | 'Daily Active Users (DAU)' | 'Registered Members' | 'Estimated Global Users';
  userCountFormatted: string;
  userCountRaw: number;
  reportingPeriod: string;
  sourceName: string;
  sourceUrl: string;
  lastUpdated: string;
  definition: string;
  badgeColor: string;
}

export interface AgencyCreatorCard {
  id: number;
  name: string;
  handle: string;
  avatarUrl: string;
  niche: string;
  totalFollowers: number;
  totalViews: number;
  avgEngagementRate: number;
  connectedPlatforms: SupportedPlatform[];
  campaignCount: number;
  collaborationStatus: 'open' | 'booked' | 'selective';
}

export interface AgencyDashboardData {
  summary: {
    totalCreators: number;
    totalFollowers: number;
    totalViews: number;
    activeCampaigns: number;
    totalRevenue: number;
    growthPct: number;
  };
  creators: AgencyCreatorCard[];
  campaigns: Campaign[];
  performanceTrend: {
    date: string;
    followers: number;
    views: number;
    engagement: number;
  }[];
}

export interface MarketingDashboardData {
  summary: {
    totalCampaigns: number;
    activeCampaigns: number;
    totalReach: number;
    totalImpressions: number;
    totalClicks: number;
    totalEngagement: number;
    totalSpend: number;
    averageRoi: number;
    missingSpendCount: number;
  };
  campaigns: (Campaign & {
    conversions?: number;
    clicks?: number;
    ctr?: number;
    cpc?: number;
    hasSpendData: boolean;
  })[];
  platformPerformance: {
    platform: SupportedPlatform;
    displayName: string;
    reach: number;
    engagement: number;
    spend: number;
    campaignsCount: number;
  }[];
  trendData: {
    date: string;
    reach: number;
    engagement: number;
    conversions: number;
    spend: number;
  }[];
}

export interface SystemHealthStatus {
  status: 'healthy' | 'degraded' | 'offline';
  uptimeSeconds: number;
  version: string;
  activeUsersCount: number;
  totalConnectedAccounts: number;
  databaseConnected: boolean;
  timestamp: string;
  platformSyncStatus: {
    platform: SupportedPlatform;
    connectedCount: number;
    lastSuccessfulSync: string | null;
    status: 'operational' | 'pending_setup' | 'rate_limited';
  }[];
  recentErrors: {
    id: string;
    timestamp: string;
    platform: string;
    error: string;
    statusCode?: number;
  }[];
}

export interface YouTubeDailyReport {
  date: string;
  views: number;
  watchTimeMinutes: number;
  averageViewDurationSeconds: number;
  subscribersGained: number;
  subscribersLost: number;
  netSubscribers: number;
  likes: number;
  comments: number;
  shares: number;
  estimatedRevenue?: number | null;
}

export interface YouTubeAnalyticsMetrics {
  totalVideos: number;
  totalViews: number;
  watchTimeMinutes: number | null;
  watchTimeHours: number | null;
  watchTimeReason?: string | null;
  averageViewDurationSeconds: number | null;
  subscribersGained: number | null;
  subscribersLost: number | null;
  netSubscribers: number | null;
  totalLikes: number;
  totalComments: number;
  totalShares: number;
  totalReach?: number;
  engagementRate: number;
  estimatedRevenue: number | null;
  revenueCurrency?: string;
  hasRevenueData: boolean;
  revenueReason?: string | null;
  formula?: string;
}

export interface YouTubeAnalyticsResponse {
  success: boolean;
  connected: boolean;
  message?: string;
  channel: any;
  range?: string;
  startDate?: string;
  endDate?: string;
  analyticsApiSource?: string;
  analyticsNotice?: string;
  errorType?: string;
  reconnectRequired?: boolean;
  metrics: YouTubeAnalyticsMetrics;
  dailyReports?: YouTubeDailyReport[];
  historicalSnapshots: Array<{
    id: number;
    snapshotDate: string;
    subscribers: number;
    totalViews: number;
    totalLikes: number;
    totalComments: number;
    totalShares: number;
    avgEngagementRate: number;
    videoCount: number;
  }>;
  topPosts?: {
    byViews: any[];
    byEngagement: any[];
  };
  demographics?: {
    isAuthorized: boolean;
    status?: string;
    message?: string;
    available?: boolean;
  };
}

