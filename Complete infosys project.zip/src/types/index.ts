export type WorkspaceRole = 'creator' | 'agency' | 'marketing' | 'admin';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar: string;
  roles: WorkspaceRole[];
  currentRole: WorkspaceRole;
  workspaceId: string;
}

export interface SocialAccount {
  id: string;
  platform: 'youtube' | 'instagram' | 'tiktok' | 'linkedin' | 'x';
  platformName: string;
  handle: string;
  displayName: string;
  avatar: string;
  connected: boolean;
  connectedAt: string | null;
  lastSyncAt: string | null;
  metrics: {
    followers: number;
    subscribers?: number;
    connections?: number;
    engagementRate: number;
    monthlyImpressions: number;
    verified: boolean;
  };
}

// 1. Creator Dashboard Types
export interface CreatorSummary {
  totalFollowers: number;
  totalFollowersChange: number;
  totalViews: number;
  totalViewsChange: number;
  totalLikes: number;
  totalLikesChange: number;
  totalComments: number;
  totalCommentsChange: number;
  totalShares: number;
  totalSharesChange: number;
  totalReach: number;
  totalReachChange: number;
  engagementRate: number;
  engagementRateChange: number;
  estimatedEarningsINR: number;
  estimatedEarningsChange: number;
}

export interface CreatorTimelinePoint {
  month: string;
  followers: number;
  views: number;
  reach: number;
  engagement: number;
}

export interface ContentItem {
  id: string;
  title: string;
  platform: string;
  publishedAt: string;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  engagementRate: number;
  revenueINR: number;
}

export interface CreatorDashboardData {
  summary: CreatorSummary;
  growthTimeline: CreatorTimelinePoint[];
  platformBreakdown: { platform: string; followers: number; sharePercent: number; color: string }[];
  topContent: ContentItem[];
}

// 2. Agency Dashboard Types
export interface AgencySummary {
  totalAssignedCreators: number;
  activeCreators: number;
  totalCampaigns: number;
  activeCampaigns: number;
  totalRevenueINR: number;
  revenueGrowth: number;
  agencyCommissionINR: number;
  commissionGrowth: number;
  pendingTasks: number;
  deliverablesCompletedPercent: number;
}

export interface AgencyCreator {
  id: string;
  name: string;
  niche: string;
  avatar: string;
  followers: number;
  primaryPlatform: string;
  activeCampaigns: number;
  contractValueINR: number;
  completionRate: number;
  status: 'active' | 'paused' | 'onboarding';
}

export interface AgencyCampaign {
  id: string;
  title: string;
  brand: string;
  budgetINR: number;
  spendINR: number;
  assignedCreatorsCount: number;
  progressPercent: number;
  dueDate: string;
  status: string;
}

export interface AgencyTask {
  id: string;
  title: string;
  due: string;
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  status: string;
}

export interface AgencyDashboardData {
  summary: AgencySummary;
  monthlyRevenue: { month: string; revenue: number; commission: number }[];
  creators: AgencyCreator[];
  campaigns: AgencyCampaign[];
  tasks: AgencyTask[];
}

// 3. Marketing Dashboard Types
export interface MarketingSummary {
  totalSpendINR: number;
  spendChangePercent: number;
  totalImpressions: number;
  impressionsChangePercent: number;
  totalReach: number;
  reachChangePercent: number;
  totalClicks: number;
  clicksChangePercent: number;
  totalConversions: number;
  conversionsChangePercent: number;
  costPerClickINR: number;
  costPerAcquisitionINR: number;
  averageROI: number;
  roiChangePercent: number;
}

export interface MarketingCampaignComparison {
  id: string;
  name: string;
  status: 'Active' | 'Completed' | 'Paused';
  spendINR: number;
  impressions: number;
  clicks: number;
  conversions: number;
  revenueGeneratedINR: number;
  roas: number;
  cpcINR: number;
  cpaINR: number;
}

export interface MarketingDashboardData {
  workspaceRole: string;
  summary: MarketingSummary;
  monthlyPerformance: {
    month: string;
    spendINR: number;
    impressions: number;
    conversions: number;
    roi: number;
  }[];
  channelSpendBreakdown: {
    channel: string;
    spendINR: number;
    percentage: number;
    cpaINR: number;
    color: string;
  }[];
  campaignComparisons: MarketingCampaignComparison[];
}

// 4. Admin Dashboard Types
export interface AdminSummary {
  totalRegisteredUsers: number;
  activeUsersToday: number;
  activeUsersGrowth: number;
  totalWorkspaces: number;
  activeWorkspaces: number;
  apiRequestsToday: number;
  apiUptimePercent: number;
  averageLatencyMs: number;
  securityAlertsCount: number;
}

export interface AuditLog {
  id: string;
  user: string;
  role: string;
  action: string;
  details: string;
  ipAddress: string;
  timestamp: string;
  status: 'Success' | 'Blocked' | 'Warning';
}

export interface AdminDashboardData {
  summary: AdminSummary;
  roleDistribution: { role: string; count: number; percentage: number; color: string }[];
  systemHealth: {
    apiStatus: string;
    dbLatency: string;
    cacheHitRate: string;
    rateLimitHeadroom: string;
    lastBackupAt: string;
  };
  auditLogs: AuditLog[];
}
