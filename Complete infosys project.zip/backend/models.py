from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(db.Model):
    """User account model for CreatorIQ with role-based authorization"""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(30), nullable=False, default='creator')  # 'creator', 'agency', 'marketing', 'admin'
    status = db.Column(db.String(20), nullable=False, default='active')  # 'active', 'pending', 'suspended'
    avatar_url = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)

    # One-to-one relationship with CreatorProfile
    creator_profile = db.relationship('CreatorProfile', backref='user', uselist=False, cascade='all, delete-orphan')

    def set_password(self, password: str):
        """Hash and store the password securely using pbkdf2:sha256 / bcrypt"""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        """Verify password against securely stored hash"""
        if not self.password_hash:
            return False
        return check_password_hash(self.password_hash, password)

    def to_dict(self, include_profile: bool = True):
        """Serialize user object without sensitive password hash"""
        data = {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'role': self.role,
            'status': self.status,
            'avatar_url': self.avatar_url or f"https://api.dicebear.com/7.x/avataaars/svg?seed={self.email}",
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }
        if include_profile and self.creator_profile:
            data['creator_profile'] = self.creator_profile.to_dict()
        return data


class CreatorProfile(db.Model):
    """Detailed profile data for creator accounts"""
    __tablename__ = 'creator_profiles'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, unique=True)
    handle = db.Column(db.String(80), nullable=False, default='@creator')
    bio = db.Column(db.Text, nullable=True, default='')
    niche = db.Column(db.String(100), nullable=True, default='Digital Content & Tech')
    location = db.Column(db.String(100), nullable=True, default='Global / Remote')
    website = db.Column(db.String(200), nullable=True, default='')
    contact_email = db.Column(db.String(120), nullable=True, default='')
    base_rate = db.Column(db.Float, nullable=False, default=1500.0)
    collaboration_status = db.Column(db.String(30), nullable=False, default='open')  # 'open', 'booked', 'selective'
    
    # Social channels & performance metrics
    youtube_handle = db.Column(db.String(80), nullable=True, default='')
    youtube_subscribers = db.Column(db.Integer, nullable=False, default=125000)
    
    instagram_handle = db.Column(db.String(80), nullable=True, default='')
    instagram_followers = db.Column(db.Integer, nullable=False, default=85400)
    
    tiktok_handle = db.Column(db.String(80), nullable=True, default='')
    tiktok_followers = db.Column(db.Integer, nullable=False, default=240000)
    
    twitter_handle = db.Column(db.String(80), nullable=True, default='')
    
    engagement_rate = db.Column(db.Float, nullable=False, default=4.8)
    monthly_reach = db.Column(db.Integer, nullable=False, default=1250000)
    verified = db.Column(db.Boolean, nullable=False, default=True)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'handle': self.handle,
            'bio': self.bio,
            'niche': self.niche,
            'location': self.location,
            'website': self.website,
            'contact_email': self.contact_email,
            'base_rate': self.base_rate,
            'collaboration_status': self.collaboration_status,
            'youtube_handle': self.youtube_handle,
            'youtube_subscribers': self.youtube_subscribers,
            'instagram_handle': self.instagram_handle,
            'instagram_followers': self.instagram_followers,
            'tiktok_handle': self.tiktok_handle,
            'tiktok_followers': self.tiktok_followers,
            'twitter_handle': self.twitter_handle,
            'engagement_rate': self.engagement_rate,
            'monthly_reach': self.monthly_reach,
            'verified': self.verified
        }


class AuditLog(db.Model):
    """Audit logs for user management actions and administrative events"""
    __tablename__ = 'audit_logs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    action = db.Column(db.String(100), nullable=False)
    details = db.Column(db.Text, nullable=True)
    ip_address = db.Column(db.String(45), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'action': self.action,
            'details': self.details,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class ConnectedAccount(db.Model):
    """Connected third-party platform account (e.g. YouTube OAuth2 Channel)"""
    __tablename__ = 'connected_accounts'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    platform = db.Column(db.String(50), nullable=False, default='youtube')
    channel_id = db.Column(db.String(120), nullable=False)
    channel_title = db.Column(db.String(200), nullable=False)
    channel_handle = db.Column(db.String(100), nullable=True)
    channel_description = db.Column(db.Text, nullable=True)
    thumbnail_url = db.Column(db.String(255), nullable=True)
    subscriber_count = db.Column(db.Integer, default=0)
    video_count = db.Column(db.Integer, default=0)
    view_count = db.Column(db.BigInteger, default=0)
    uploads_playlist_id = db.Column(db.String(120), nullable=True)
    access_token = db.Column(db.Text, nullable=True)  # Server-side encrypted or protected
    refresh_token = db.Column(db.Text, nullable=True)  # Server-side encrypted or protected
    token_expiry = db.Column(db.BigInteger, nullable=True)
    status = db.Column(db.String(30), default='connected')  # 'connected', 'expired', 'revoked'
    connected_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_synced_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    videos = db.relationship('VideoPost', backref='connected_account', cascade='all, delete-orphan')
    snapshots = db.relationship('AnalyticsSnapshot', backref='connected_account', cascade='all, delete-orphan')

    def to_dict(self, include_tokens: bool = False):
        """Serialize connected account without leaking secrets to frontend"""
        data = {
            'id': self.id,
            'user_id': self.user_id,
            'platform': self.platform,
            'channel_id': self.channel_id,
            'channel_title': self.channel_title,
            'channel_handle': self.channel_handle,
            'channel_description': self.channel_description,
            'thumbnail_url': self.thumbnail_url,
            'subscriber_count': self.subscriber_count,
            'video_count': self.video_count,
            'view_count': self.view_count,
            'status': self.status,
            'connected_at': self.connected_at.isoformat() if self.connected_at else None,
            'last_synced_at': self.last_synced_at.isoformat() if self.last_synced_at else None
        }
        if include_tokens:
            data['access_token'] = self.access_token
            data['token_expiry'] = self.token_expiry
        return data


class VideoPost(db.Model):
    """Creator uploaded video or post synchronized from authorized platform"""
    __tablename__ = 'video_posts'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    connected_account_id = db.Column(db.Integer, db.ForeignKey('connected_accounts.id', ondelete='CASCADE'), nullable=True)
    platform = db.Column(db.String(50), nullable=False, default='youtube')
    video_id = db.Column(db.String(120), nullable=False, index=True)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    published_at = db.Column(db.DateTime, nullable=False, index=True)
    thumbnail_url = db.Column(db.String(255), nullable=True)
    duration = db.Column(db.String(30), nullable=True)
    views = db.Column(db.BigInteger, default=0)
    likes = db.Column(db.Integer, default=0)
    comments = db.Column(db.Integer, default=0)
    shares = db.Column(db.Integer, default=0)
    engagement_rate = db.Column(db.Float, default=0.0)
    privacy_status = db.Column(db.String(30), default='public')  # 'public', 'unlisted', 'private'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def calculate_engagement(self) -> float:
        """
        Documented Engagement Rate formula:
        Engagement Rate (%) = ((Likes + Comments + Shares) / Total Views) * 100
        When shares are unavailable from the platform API, (Likes + Comments) / Views * 100 is computed.
        """
        if not self.views or self.views <= 0:
            return 0.0
        eng = ((self.likes + self.comments + (self.shares or 0)) / self.views) * 100.0
        return round(eng, 2)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'connected_account_id': self.connected_account_id,
            'platform': self.platform,
            'video_id': self.video_id,
            'title': self.title,
            'description': self.description,
            'published_at': self.published_at.isoformat() if self.published_at else None,
            'thumbnail_url': self.thumbnail_url,
            'duration': self.duration,
            'views': self.views,
            'likes': self.likes,
            'comments': self.comments,
            'shares': self.shares,
            'engagement_rate': self.engagement_rate or self.calculate_engagement(),
            'privacy_status': self.privacy_status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class AnalyticsSnapshot(db.Model):
    """Periodic dated snapshot of channel & creator metrics for historical trend charts"""
    __tablename__ = 'analytics_snapshots'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    connected_account_id = db.Column(db.Integer, db.ForeignKey('connected_accounts.id', ondelete='CASCADE'), nullable=True)
    platform = db.Column(db.String(50), nullable=False, default='youtube')
    snapshot_date = db.Column(db.Date, nullable=False, index=True)
    subscribers = db.Column(db.Integer, default=0)
    total_views = db.Column(db.BigInteger, default=0)
    total_likes = db.Column(db.Integer, default=0)
    total_comments = db.Column(db.Integer, default=0)
    total_shares = db.Column(db.Integer, default=0)
    avg_engagement_rate = db.Column(db.Float, default=0.0)
    video_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'platform': self.platform,
            'snapshot_date': self.snapshot_date.isoformat() if self.snapshot_date else None,
            'subscribers': self.subscribers,
            'total_views': self.total_views,
            'total_likes': self.total_likes,
            'total_comments': self.total_comments,
            'total_shares': self.total_shares,
            'avg_engagement_rate': self.avg_engagement_rate,
            'video_count': self.video_count
        }


class AudienceDemographic(db.Model):
    """Platform authorized demographic breakdown (only populated when platform API provides it)"""
    __tablename__ = 'audience_demographics'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    platform = db.Column(db.String(50), nullable=False, default='youtube')
    report_date = db.Column(db.Date, nullable=False)
    is_authorized = db.Column(db.Boolean, default=False)
    notes = db.Column(db.String(255), nullable=True)
    age_json = db.Column(db.Text, nullable=True)  # JSON serialized segments
    gender_json = db.Column(db.Text, nullable=True)  # JSON serialized segments
    geography_json = db.Column(db.Text, nullable=True)  # JSON serialized segments
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
