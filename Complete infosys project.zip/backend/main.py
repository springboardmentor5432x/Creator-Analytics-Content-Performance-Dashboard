import os
from datetime import datetime, timedelta
from typing import Optional, List
import jwt
from fastapi import FastAPI, Depends, HTTPException, Query, Header, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Import Flask app and models for database session & model access
from app import create_app
from models import db, User, ConnectedAccount, AnalyticsSnapshot

# Initialize Flask app to provide SQLAlchemy database context
flask_app = create_app()

app = FastAPI(
    title="CreatorIQ Analytics API",
    description="High-performance FastAPI service for CreatorIQ historical audience metrics and creator intelligence.",
    version="1.0.0"
)

# Enable CORS for frontend integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

JWT_SECRET_KEY = os.getenv("JWT_SECRET", os.getenv("SECRET_KEY", "creatoriq-super-secret-jwt-key-2026"))
JWT_ALGORITHM = "HS256"


def get_current_user(authorization: Optional[str] = Header(None)) -> User:
    """
    Authenticate the incoming request Bearer token and enforce session validity.
    Returns the authenticated User model instance.
    """
    if not authorization:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authorization header missing. Please provide a Bearer token."
        )

    parts = authorization.split()
    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authorization format. Must be 'Bearer <token>'."
        )

    token = parts[1]

    try:
        # Decode and verify signature
        payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
        user_id = payload.get("user_id") or payload.get("sub")
        if not user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token does not contain a valid user identity claim."
            )

        with flask_app.app_context():
            user = db.session.get(User, int(user_id)) if hasattr(db.session, 'get') else User.query.get(int(user_id))
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="The user associated with this token could not be found."
                )

            if user.status == "suspended":
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="This account has been suspended by an administrator."
                )

            # Detach user representation for route logic
            return user

    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication token has expired. Please log in again."
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token."
        )


@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "service": "CreatorIQ FastAPI Analytics Backend",
        "version": "1.0.0",
        "framework": "FastAPI"
    }


@app.get("/api/analytics/historical-audience")
def get_historical_audience(
    range: str = Query("30d", regex="^(7d|30d|90d|1y|all)$"),
    platform: Optional[str] = Query(None),
    current_user: User = Depends(get_current_user)
):
    """
    Query dated audience snapshots from the PostgreSQL/SQL database.
    Strictly enforces creator ownership: only queries and returns records
    belonging to the currently authenticated creator (current_user.id) for their
    connected platform accounts.
    """
    # 1. Enforce creator or admin role authorization
    if current_user.role not in ["creator", "admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Access forbidden: User with role '{current_user.role}' is not authorized to access creator audience analytics."
        )

    # 2. Compute date cutoff
    days_map = {"7d": 7, "30d": 30, "90d": 90, "1y": 365, "all": 99999}
    days = days_map.get(range, 30)
    cutoff_date = (datetime.utcnow() - timedelta(days=days)).date()

    with flask_app.app_context():
        # 3. Ownership Enforcement: Query connected accounts belonging strictly to current_user.id
        connected_accounts = ConnectedAccount.query.filter_by(user_id=current_user.id).all()
        connected_data = [acc.to_dict(include_tokens=False) for acc in connected_accounts]

        # 4. Ownership Enforcement: Query historical snapshots belonging strictly to current_user.id
        query = AnalyticsSnapshot.query.filter(
            AnalyticsSnapshot.user_id == current_user.id,
            AnalyticsSnapshot.snapshot_date >= cutoff_date
        )

        if platform and platform.lower() != "all":
            query = query.filter(AnalyticsSnapshot.platform == platform.lower())

        snapshots = query.order_by(AnalyticsSnapshot.snapshot_date.asc()).all()

        snapshots_data = [s.to_dict() for s in snapshots]

        # 5. Compute performance and growth summaries
        latest_subs = snapshots_data[-1]["subscribers"] if snapshots_data else 0
        initial_subs = snapshots_data[0]["subscribers"] if snapshots_data else latest_subs
        net_growth = latest_subs - initial_subs
        pct_growth = round(((net_growth / initial_subs) * 100), 2) if initial_subs > 0 else 0.0

        avg_eng = round(
            sum(s.get("avg_engagement_rate", 0) for s in snapshots_data) / len(snapshots_data), 2
        ) if snapshots_data else 0.0

        creator_handle = current_user.creator_profile.handle if current_user.creator_profile else f"@{current_user.name.lower().replace(' ', '')}"

        return {
            "success": True,
            "creator_id": current_user.id,
            "creator_name": current_user.name,
            "creator_handle": creator_handle,
            "platform": platform or "all",
            "range": range,
            "cutoff_date": cutoff_date.isoformat(),
            "total_snapshots": len(snapshots_data),
            "connected_platforms": connected_data,
            "snapshots": snapshots_data,
            "summary": {
                "latest_subscribers": latest_subs,
                "net_growth": net_growth,
                "percentage_growth": pct_growth,
                "avg_engagement_rate": avg_eng
            }
        }
