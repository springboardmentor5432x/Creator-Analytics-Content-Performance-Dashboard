from flask import Blueprint, request, jsonify
from models import db, User, CreatorProfile, AuditLog
from auth_utils import token_required

creator_bp = Blueprint('creators', __name__, url_prefix='/api/creators')

@creator_bp.route('/me', methods=['GET'])
@token_required
def get_my_creator_profile(current_user: User):
    """Get authenticated user's own creator profile and analytics"""
    profile = current_user.creator_profile
    if not profile:
        # Automatically initialize profile if user is a creator
        profile = CreatorProfile(
            user_id=current_user.id,
            handle=f"@{current_user.name.lower().replace(' ', '')}",
            bio="Passionate content creator sharing authentic perspectives.",
            niche="General / Digital Media",
            contact_email=current_user.email,
            base_rate=1000.0,
            collaboration_status="open"
        )
        db.session.add(profile)
        db.session.commit()

    return jsonify({
        'success': True,
        'profile': profile.to_dict(),
        'user': current_user.to_dict(include_profile=False)
    }), 200


@creator_bp.route('/me', methods=['PUT'])
@token_required
def update_my_creator_profile(current_user: User):
    """Update profile details, social links, bio, and collaboration rates"""
    data = request.get_json() or {}
    profile = current_user.creator_profile
    
    if not profile:
        profile = CreatorProfile(user_id=current_user.id)
        db.session.add(profile)

    # Update basic profile fields
    if 'handle' in data:
        handle = data['handle'].strip()
        profile.handle = handle if handle.startswith('@') else f"@{handle}"
    if 'bio' in data:
        profile.bio = data['bio'].strip()
    if 'niche' in data:
        profile.niche = data['niche'].strip()
    if 'location' in data:
        profile.location = data['location'].strip()
    if 'website' in data:
        profile.website = data['website'].strip()
    if 'contact_email' in data:
        profile.contact_email = data['contact_email'].strip()
    if 'base_rate' in data:
        try:
            profile.base_rate = float(data['base_rate'])
        except (ValueError, TypeError):
            pass
    if 'collaboration_status' in data:
        if data['collaboration_status'] in ['open', 'booked', 'selective']:
            profile.collaboration_status = data['collaboration_status']

    # Update social media handles
    if 'youtube_handle' in data:
        profile.youtube_handle = data['youtube_handle'].strip()
    if 'instagram_handle' in data:
        profile.instagram_handle = data['instagram_handle'].strip()
    if 'tiktok_handle' in data:
        profile.tiktok_handle = data['tiktok_handle'].strip()
    if 'twitter_handle' in data:
        profile.twitter_handle = data['twitter_handle'].strip()

    # Allow updating user name and avatar
    if 'name' in data and data['name'].strip():
        current_user.name = data['name'].strip()
    if 'avatar_url' in data and data['avatar_url'].strip():
        current_user.avatar_url = data['avatar_url'].strip()

    # Audit log
    log = AuditLog(
        user_id=current_user.id,
        action='CREATOR_PROFILE_UPDATE',
        details="Creator updated profile settings and social metrics",
        ip_address=request.remote_addr
    )
    db.session.add(log)
    db.session.commit()

    return jsonify({
        'success': True,
        'message': 'Creator profile updated successfully.',
        'profile': profile.to_dict(),
        'user': current_user.to_dict(include_profile=False)
    }), 200


@creator_bp.route('/<int:user_id>', methods=['GET'])
def get_creator_public_profile(user_id: int):
    """Public creator profile view (preventing exposure of private data if unauthorized)"""
    user = User.query.get(user_id)
    if not user or user.status == 'suspended':
        return jsonify({'success': False, 'message': 'Creator not found.'}), 404

    profile = user.creator_profile
    if not profile:
        return jsonify({'success': False, 'message': 'Creator profile not configured.'}), 404

    # Public-safe payload
    return jsonify({
        'success': True,
        'creator': {
            'id': user.id,
            'name': user.name,
            'avatar_url': user.avatar_url or f"https://api.dicebear.com/7.x/avataaars/svg?seed={user.email}",
            'profile': profile.to_dict()
        }
    }), 200


@creator_bp.route('', methods=['GET'])
def list_creators():
    """List creators for agency discovery and marketing campaigns"""
    niche = request.args.get('niche')
    search = request.args.get('q')

    query = User.query.filter_by(role='creator', status='active')
    
    if search:
        query = query.filter(User.name.ilike(f"%{search}%"))

    users = query.all()
    results = []
    for u in users:
        p = u.creator_profile
        if niche and p and niche.lower() not in p.niche.lower():
            continue
        results.append({
            'user': u.to_dict(include_profile=False),
            'profile': p.to_dict() if p else None
        })

    return jsonify({
        'success': True,
        'count': len(results),
        'creators': results
    }), 200


@creator_bp.route('/analytics/historical-audience', methods=['GET'])
@token_required
def get_historical_audience_flask(current_user: User):
    """
    Query dated audience snapshots for the authenticated creator with strict ownership enforcement.
    """
    from datetime import datetime, timedelta
    from models import ConnectedAccount, AnalyticsSnapshot

    if current_user.role not in ['creator', 'admin']:
        return jsonify({
            'success': False,
            'message': 'Access forbidden: Only authorized creators may query audience analytics.'
        }), 403

    range_param = request.args.get('range', '30d')
    platform_param = request.args.get('platform')

    days_map = {'7d': 7, '30d': 30, '90d': 90, '1y': 365, 'all': 99999}
    days = days_map.get(range_param, 30)
    cutoff_date = (datetime.utcnow() - timedelta(days=days)).date()

    # Enforce ownership: only query connected accounts owned by current_user.id
    connected = ConnectedAccount.query.filter_by(user_id=current_user.id).all()
    connected_data = [acc.to_dict(include_tokens=False) for acc in connected]

    # Enforce ownership: only query snapshots owned by current_user.id
    query = AnalyticsSnapshot.query.filter(
        AnalyticsSnapshot.user_id == current_user.id,
        AnalyticsSnapshot.snapshot_date >= cutoff_date
    )

    if platform_param and platform_param.lower() != 'all':
        query = query.filter(AnalyticsSnapshot.platform == platform_param.lower())

    snapshots = query.order_by(AnalyticsSnapshot.snapshot_date.asc()).all()
    snapshots_data = [s.to_dict() for s in snapshots]

    latest_subs = snapshots_data[-1]['subscribers'] if snapshots_data else 0
    initial_subs = snapshots_data[0]['subscribers'] if snapshots_data else latest_subs
    net_growth = latest_subs - initial_subs
    pct_growth = round(((net_growth / initial_subs) * 100), 2) if initial_subs > 0 else 0.0

    avg_eng = round(
        sum(s.get('avg_engagement_rate', 0) for s in snapshots_data) / len(snapshots_data), 2
    ) if snapshots_data else 0.0

    handle = current_user.creator_profile.handle if current_user.creator_profile else f"@{current_user.name.lower().replace(' ', '')}"

    return jsonify({
        'success': True,
        'creator_id': current_user.id,
        'creator_name': current_user.name,
        'creator_handle': handle,
        'platform': platform_param or 'all',
        'range': range_param,
        'cutoff_date': cutoff_date.isoformat(),
        'total_snapshots': len(snapshots_data),
        'connected_platforms': connected_data,
        'snapshots': snapshots_data,
        'summary': {
            'latest_subscribers': latestSubs,
            'net_growth': net_growth,
            'percentage_growth': pct_growth,
            'avg_engagement_rate': avg_eng
        }
    }), 200

